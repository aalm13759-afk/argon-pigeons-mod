package com.argon.loftpigeons.client;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class ArgonPigeonModel extends GeoModel<ArgonPigeonEntity> {
    @Override
    public ResourceLocation getModelResource(ArgonPigeonEntity entity) {
        return new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "geo/argon_loft_pigeon.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(ArgonPigeonEntity entity) {
        return switch (entity.getBreed()) {
            case GOLDEN_PRINCE -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/golden_prince.png");
            case RED_AGHAR -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/red_aghar.png");
            case ZAJIL_HOMER -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/zajil_homer.png");
        };
    }

    @Override
    public ResourceLocation getAnimationResource(ArgonPigeonEntity entity) {
        return new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "animations/argon_loft_pigeon.animation.json");
    }
}
