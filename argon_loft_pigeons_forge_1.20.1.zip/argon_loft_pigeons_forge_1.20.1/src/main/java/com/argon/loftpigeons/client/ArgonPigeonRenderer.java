package com.argon.loftpigeons.client;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class ArgonPigeonRenderer extends GeoEntityRenderer<ArgonPigeonEntity> {
    public ArgonPigeonRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new ArgonPigeonModel());
        this.shadowRadius = 0.25F;
    }
}
