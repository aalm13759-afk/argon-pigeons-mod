package com.argon.loftpigeons.entity.ai;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.item.Items;

import java.util.EnumSet;
import java.util.List;

/**
 * سلوك الأكل الطبيعي على الأرض: يبحث الطير عن الحبوب الملقاة على الأرض ويلتقطها بهدوء.
 */
public class ForageGrainGoal extends Goal {
    private final ArgonPigeonEntity pigeon;
    private ItemEntity targetGrain;

    public ForageGrainGoal(ArgonPigeonEntity pigeon) {
        this.pigeon = pigeon;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (!pigeon.onGround() || pigeon.isLaunchedByOwner()) return false;
        List<ItemEntity> grains = pigeon.level().getEntitiesOfClass(
                ItemEntity.class,
                pigeon.getBoundingBox().inflate(8.0D),
                item -> item.getItem().is(Items.WHEAT_SEEDS) || item.getItem().is(Items.WHEAT)
        );
        if (grains.isEmpty()) return false;
        this.targetGrain = grains.get(0);
        return true;
    }

    @Override
    public void tick() {
        if (this.targetGrain == null || !this.targetGrain.isAlive()) return;
        pigeon.getLookControl().setLookAt(this.targetGrain, 30.0F, 30.0F);
        pigeon.getNavigation().moveTo(this.targetGrain, 1.0D);

        if (pigeon.distanceToSqr(this.targetGrain) < 1.8D) {
            this.targetGrain.getItem().shrink(1);
            pigeon.setPhase(ArgonPigeonEntity.FlightPhase.EATING_GRAIN);
            pigeon.heal(2.0F);
        }
    }
}
