package com.argon.loftpigeons.entity.ai;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * ذكاء الكولدن برنس (Golden Prince Highflyer AI):
 * - يطير فوق راعيه دائر أو دائرين (1-2 دوائر).
 * - بعدها يبدأ صعوداً دائرياً سريعاً لفوق الغيوم (Y > 215) حتى الاختفاء في النقطة.
 * - يطير ساعات طويلة (10 ساعات ماينكرافت = 10,000 تيك، وقابلة للتمديد) فوق موقع اللوفت.
 * - بعدها ينزل عمودياً تدريجياً عند راعيه ويدخل حالة الاستراحة واللهاث الخفيف.
 */
public class GoldenPrinceHighflyerGoal extends Goal {
    private final ArgonPigeonEntity pigeon;
    private double spiralAngle = 0.0D;
    private double warmupTargetRadians = Math.PI * 4.0D; // دائرين فوق الراعي

    // ارتفاع الغيوم في ماينكرافت 1.20.1 هو 192، فيصعد الكولدن برنس إلى 225 فوق الغيوم حتى يختفي!
    private static final double ABOVE_CLOUDS_Y = 225.0D;
    // 10 ساعات في عالم ماينكرافت = 10,000 تيك
    private static final int TEN_HOURS_ENDURANCE_TICKS = 10000;

    public GoldenPrinceHighflyerGoal(ArgonPigeonEntity pigeon) {
        this.pigeon = pigeon;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return pigeon.getBreed() == ArgonPigeonEntity.Breed.GOLDEN_PRINCE && pigeon.isLaunchedByOwner();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        pigeon.setNoGravity(true);
        this.spiralAngle = 0.0D;
        // دائر أو دائرين فوق الراعي
        int circles = 1 + pigeon.getRandom().nextInt(2);
        this.warmupTargetRadians = circles * (Math.PI * 2.0D);
        pigeon.setPhase(ArgonPigeonEntity.FlightPhase.WARMUP_CIRCLES);
    }

    @Override
    public void tick() {
        BlockPos home = getHomePos();
        Vec3 homeVec = Vec3.atCenterOf(home);

        // المرحلة 1: دائر أو دائرين فوق الراعي على ارتفاع قريب (14 بلوكة)
        if (this.spiralAngle < this.warmupTargetRadians) {
            pigeon.setPhase(ArgonPigeonEntity.FlightPhase.WARMUP_CIRCLES);
            this.spiralAngle += 0.075D;
            double radius = 10.0D;
            double tx = homeVec.x + Math.cos(this.spiralAngle) * radius;
            double tz = homeVec.z + Math.sin(this.spiralAngle) * radius;
            double ty = homeVec.y + 12.0D;
            moveSmooth(new Vec3(tx, ty, tz), 0.34D);
            return;
        }

        // المرحلة 2: صعود دائري (حلزوني) سريع لفوق الغيوم حتى الاختفاء
        if (pigeon.getY() < ABOVE_CLOUDS_Y && pigeon.getFlightTicks() < TEN_HOURS_ENDURANCE_TICKS) {
            pigeon.setPhase(ArgonPigeonEntity.FlightPhase.GOLDEN_SPIRAL_CLIMB);
            this.spiralAngle += 0.14D; // دوران حلزوني سريع
            double tightRadius = 7.5D;
            double tx = homeVec.x + Math.cos(this.spiralAngle) * tightRadius;
            double tz = homeVec.z + Math.sin(this.spiralAngle) * tightRadius;
            double ty = pigeon.getY() + 1.8D; // صعود سريع نحو الغيوم
            moveSmooth(new Vec3(tx, ty, tz), 0.48D);
            return;
        }

        // المرحلة 3: الطيران في النقطة فوق الغيوم لساعات طويلة (10 ساعات)
        if (pigeon.getFlightTicks() < TEN_HOURS_ENDURANCE_TICKS) {
            pigeon.setPhase(ArgonPigeonEntity.FlightPhase.GOLDEN_CLOUD_VANISH);
            this.spiralAngle += 0.04D;
            double hoverRadius = 5.0D;
            double tx = homeVec.x + Math.cos(this.spiralAngle) * hoverRadius;
            double tz = homeVec.z + Math.sin(this.spiralAngle) * hoverRadius;
            moveSmooth(new Vec3(tx, ABOVE_CLOUDS_Y, tz), 0.22D);
            return;
        }

        // المرحلة 4: النزول العمودي التدريجي عند راعيه بعد إتمام الساعات الطويلة
        pigeon.setPhase(ArgonPigeonEntity.FlightPhase.DESCENDING_TO_OWNER);
        this.spiralAngle += 0.08D;
        double descentRadius = Math.max(1.5D, (pigeon.getY() - homeVec.y) * 0.08D);
        double tx = homeVec.x + Math.cos(this.spiralAngle) * descentRadius;
        double tz = homeVec.z + Math.sin(this.spiralAngle) * descentRadius;
        double ty = Math.max(homeVec.y + 0.5D, pigeon.getY() - 1.2D);
        moveSmooth(new Vec3(tx, ty, tz), 0.32D);

        if (pigeon.position().distanceTo(homeVec) < 2.4D || pigeon.onGround()) {
            pigeon.setNoGravity(false);
            pigeon.setLaunchedByOwner(false);
            // يدخل حالة الاستراحة واللهاث الخفيف بعد طيران 10 ساعات
            pigeon.startPostFlightPanting(200);
        }
    }

    private BlockPos getHomePos() {
        if (!pigeon.getHomeLoft().equals(BlockPos.ZERO)) return pigeon.getHomeLoft();
        LivingEntity owner = pigeon.getOwner();
        return owner != null ? owner.blockPosition() : pigeon.blockPosition();
    }

    private void moveSmooth(Vec3 target, double speed) {
        Vec3 delta = target.subtract(pigeon.position());
        if (delta.lengthSqr() > 0.01D) {
            Vec3 vel = delta.normalize().scale(speed);
            pigeon.setDeltaMovement(vel);
            float yaw = (float) (Math.atan2(vel.z, vel.x) * (180D / Math.PI)) - 90.0F;
            pigeon.setYRot(yaw);
            pigeon.yBodyRot = yaw;
        }
    }
}
