package com.argon.loftpigeons.item;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * صفارة وراية الراعي (Fancier Whistle & Flag):
 * تطيّر جميع الطيور القريبة معاً، أو تناديها للنزول عند الراعي (Shift + Right Click).
 */
public class FancierWhistleItem extends Item {
    public FancierWhistleItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide) {
            List<ArgonPigeonEntity> birds = level.getEntitiesOfClass(
                    ArgonPigeonEntity.class,
                    player.getBoundingBox().inflate(256.0D)
            );
            if (player.isShiftKeyDown()) {
                for (ArgonPigeonEntity b : birds) {
                    b.setPhase(ArgonPigeonEntity.FlightPhase.DESCENDING_TO_OWNER);
                }
                player.displayClientMessage(Component.literal("§e[نداء الراعي] §fتم نداء جميع الطيور للنزول إلى اللوفت (" + birds.size() + " طير)."), true);
            } else {
                int count = 0;
                for (ArgonPigeonEntity b : birds) {
                    if (b.distanceTo(player) < 24.0F) {
                        b.launchFlight(player);
                        count++;
                    }
                }
                player.displayClientMessage(Component.literal("§b[تطيير الحمام] §fتم تطيير " + count + " طير حسب سلالته!"), true);
            }
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }
}
