package com.argon.loftpigeons.item;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * موسوعة ورادار الحمام التعليمي:
 * يعرض حالة الطيور الطائرة في السماء حالياً + الزبدة التعليمية حول سلالات الزاجل والأحمر والكولدن برنس.
 */
public class PigeonEncyclopediaItem extends Item {
    public PigeonEncyclopediaItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        if (!level.isClientSide) {
            List<ArgonPigeonEntity> birds = level.getEntitiesOfClass(
                    ArgonPigeonEntity.class,
                    player.getBoundingBox().inflate(300.0D)
            );
            player.sendSystemMessage(Component.literal("§6=== [رادار وموسوعة لوفت Argon] ==="));
            for (ArgonPigeonEntity b : birds) {
                int alt = (int) (b.getY() - player.getY());
                player.sendSystemMessage(Component.literal(
                        "§e• " + b.getBreed().arabicName + " §7| الحالة: §b" + b.getPhase().name() +
                        " §7| الارتفاع عنك: §a+" + alt + "m §7| زمن الطيران: §f" + (b.getFlightTicks() / 20) + "s"
                ));
            }
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§6• الزاجل: §7طير ذكي للسباقات، يعود لراعيه من أي منطقة بطيران ناصي وسريع."));
        tooltip.add(Component.literal("§c• الأحمر: §7يدور فوقك 2-3 دوائر بارتفاع متوسط ثم يستكشف مناطق جديدة ساعة ويعود."));
        tooltip.add(Component.literal("§e• الكولدن برنس: §7يدور 1-2 دائرة ثم يصعد حلزونياً فوق الغيوم حتى الاختفاء لـ 10 ساعات."));
    }
}
