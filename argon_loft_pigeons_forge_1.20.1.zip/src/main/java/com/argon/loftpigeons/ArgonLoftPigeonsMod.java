package com.argon.loftpigeons;

import com.argon.loftpigeons.block.BreedingBoxBlock;
import com.argon.loftpigeons.block.BreedingBoxBlockEntity;
import com.argon.loftpigeons.block.CopperNestBowlBlock;
import com.argon.loftpigeons.block.DukhnPileBlock;
import com.argon.loftpigeons.block.NestActionPacket;
import com.argon.loftpigeons.block.PigeonFeederBlock;
import com.argon.loftpigeons.client.ArgonPigeonRenderer;
import com.argon.loftpigeons.client.FancierVillagerRenderer;
import com.argon.loftpigeons.client.NestControlScreen;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import com.argon.loftpigeons.entity.FancierVillagerEntity;
import com.argon.loftpigeons.item.*;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.screens.inventory.BookViewScreen;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.core.BlockPos;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.valueproviders.UniformInt;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.entity.npc.VillagerProfession;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.DropExperienceBlock;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.common.MinecraftForge;
import net.minecraft.world.entity.npc.Villager;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.entity.EntityJoinLevelEvent;
import net.minecraftforge.event.village.VillagerTradesEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.network.NetworkRegistry;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import software.bernie.geckolib.GeckoLib;

import java.util.ArrayList;
import java.util.List;

@Mod(ArgonLoftPigeonsMod.MOD_ID)
public class ArgonLoftPigeonsMod {
    public static final String MOD_ID = "argonloftpigeons";

    private static final String PROTOCOL_VERSION = "1";
    public static final SimpleChannel NETWORK = NetworkRegistry.newSimpleChannel(
            new ResourceLocation(MOD_ID, "main"),
            () -> PROTOCOL_VERSION,
            PROTOCOL_VERSION::equals,
            PROTOCOL_VERSION::equals
    );

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);
    public static final DeferredRegister<Block> BLOCKS =
            DeferredRegister.create(ForgeRegistries.BLOCKS, MOD_ID);
    public static final DeferredRegister<BlockEntityType<?>> BLOCK_ENTITIES =
            DeferredRegister.create(ForgeRegistries.BLOCK_ENTITY_TYPES, MOD_ID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final RegistryObject<EntityType<ArgonPigeonEntity>> LOFT_PIGEON =
            ENTITIES.register("loft_pigeon", () -> EntityType.Builder.of(ArgonPigeonEntity::new, MobCategory.CREATURE)
                    .sized(0.5F, 0.65F)
                    .clientTrackingRange(128)
                    .build("loft_pigeon"));

    public static final RegistryObject<EntityType<FancierVillagerEntity>> FANCIER_VILLAGER =
            ENTITIES.register("fancier_villager", () -> EntityType.Builder.of(FancierVillagerEntity::new, MobCategory.CREATURE)
                    .sized(0.6F, 1.95F)
                    .clientTrackingRange(64)
                    .build("fancier_villager"));

    public static final RegistryObject<Block> PIGEON_ORE =
            BLOCKS.register("pigeon_ore", () -> new DropExperienceBlock(
                    BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(3.0F, 3.0F).requiresCorrectToolForDrops(),
                    UniformInt.of(3, 7)));

    public static final RegistryObject<Block> BREEDING_BOX =
            BLOCKS.register("breeding_box", () -> new BreedingBoxBlock(
                    BlockBehaviour.Properties.of().mapColor(MapColor.QUARTZ).strength(2.0F).sound(SoundType.STONE).noOcclusion()));

    public static final RegistryObject<Block> COPPER_NEST_BOWL =
            BLOCKS.register("copper_nest_bowl", () -> new CopperNestBowlBlock(
                    BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_ORANGE).strength(1.5F).sound(SoundType.BAMBOO).noOcclusion()));

    public static final RegistryObject<Block> PIGEON_FEEDER =
            BLOCKS.register("pigeon_feeder", () -> new PigeonFeederBlock(
                    BlockBehaviour.Properties.of().mapColor(MapColor.WOOD).strength(1.5F).sound(SoundType.WOOD).noOcclusion()));

    public static final RegistryObject<Block> DYNAMI_BLOCK =
            BLOCKS.register("dynami_block", () -> new Block(
                    BlockBehaviour.Properties.of().mapColor(MapColor.DIAMOND).strength(4.0F, 6.0F).sound(SoundType.METAL)));

    public static final RegistryObject<Block> DUKHN_PILE =
            BLOCKS.register("dukhn_pile", () -> new DukhnPileBlock(
                    BlockBehaviour.Properties.of().mapColor(MapColor.GOLD).instabreak().sound(SoundType.SAND).noOcclusion().noCollission()));

    // ربط الكيان البرمجي للتزاوج والأزرار بكلا البلوكتين: العش الكبير 3D وخانة الكوارتز!
    public static final RegistryObject<BlockEntityType<BreedingBoxBlockEntity>> BREEDING_BOX_ENTITY =
            BLOCK_ENTITIES.register("breeding_box", () ->
                    BlockEntityType.Builder.of(BreedingBoxBlockEntity::new, BREEDING_BOX.get(), COPPER_NEST_BOWL.get()).build(null));

    public static final RegistryObject<Item> PIGEON_ORE_ITEM =
            ITEMS.register("pigeon_ore", () -> new BlockItem(PIGEON_ORE.get(), new Item.Properties()));
    public static final RegistryObject<Item> BREEDING_BOX_ITEM =
            ITEMS.register("breeding_box", () -> new BlockItem(BREEDING_BOX.get(), new Item.Properties()));
    public static final RegistryObject<Item> COPPER_NEST_BOWL_ITEM =
            ITEMS.register("copper_nest_bowl", () -> new BlockItem(COPPER_NEST_BOWL.get(), new Item.Properties()));
    public static final RegistryObject<Item> PIGEON_FEEDER_ITEM =
            ITEMS.register("pigeon_feeder", () -> new BlockItem(PIGEON_FEEDER.get(), new Item.Properties()));
    public static final RegistryObject<Item> DYNAMI_BLOCK_ITEM =
            ITEMS.register("dynami_block", () -> new BlockItem(DYNAMI_BLOCK.get(), new Item.Properties()));
    public static final RegistryObject<Item> FANCIER_VILLAGER_EGG =
            ITEMS.register("fancier_villager_spawn_egg", () -> new ForgeSpawnEggItem(FANCIER_VILLAGER, 0x0E7490, 0xF59E0B, new Item.Properties()));

    public static final RegistryObject<Item> RAW_PIGEON_GEM =
            ITEMS.register("raw_pigeon_gem", () -> new Item(new Item.Properties()));

    public static final RegistryObject<Item> M7_GRAIN_HANDFUL =
            ITEMS.register("m7_grain_handful", () -> new M7GrainHandfulItem(new Item.Properties().stacksTo(64)));

    public static final RegistryObject<Item> M7_FEED_BAG =
            ITEMS.register("m7_feed_bag", () -> new M7FeedBagItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> CERTIFICATE_ITEM =
            ITEMS.register("pigeon_certificate", () -> new CertificateItem(new Item.Properties().stacksTo(16)));

    public static final RegistryObject<Item> PIGEON_SCISSORS =
            ITEMS.register("pigeon_scissors", () -> new PigeonScissorsItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> CATCH_NET =
            ITEMS.register("catch_net", () -> new CatchNetItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> BLACK_CLOTH =
            ITEMS.register("black_cloth", () -> new BlackClothItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> LOFT_BUILDER_20X10 =
            ITEMS.register("loft_builder", () -> new LoftStructureBuilderItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> MARWAN_GUIDE_BOOK =
            ITEMS.register("marwan_guide_book", () -> new MarwanGuideBookItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> ZAJIL_EGG =
            ITEMS.register("zajil_egg", () -> new BreedEggItem(ArgonPigeonEntity.Breed.ZAJIL, 0x7B8D9E, 0x1E6B5E, new Item.Properties()));
    public static final RegistryObject<Item> RED_EGG =
            ITEMS.register("red_egg", () -> new BreedEggItem(ArgonPigeonEntity.Breed.RED, 0x853126, 0xFFFFFF, new Item.Properties()));
    public static final RegistryObject<Item> TEDDY_EGG =
            ITEMS.register("teddy_egg", () -> new BreedEggItem(ArgonPigeonEntity.Breed.TEDDY, 0x1E293B, 0x10B981, new Item.Properties()));
    public static final RegistryObject<Item> KADHMAWI_EGG =
            ITEMS.register("kadhmawi_egg", () -> new BreedEggItem(ArgonPigeonEntity.Breed.KADHMAWI, 0xFFFFFF, 0xE2E8F0, new Item.Properties()));
    public static final RegistryObject<Item> GOLDEN_EGG =
            ITEMS.register("golden_egg", () -> new BreedEggItem(ArgonPigeonEntity.Breed.GOLDEN, 0xF8FAFC, 0xD97706, new Item.Properties()));

    public static final RegistryObject<Item> HYBRID_TEDDY_KADHMAWI_EGG =
            ITEMS.register("hybrid_teddy_kadhmawi_egg", () -> new BreedEggItem(ArgonPigeonEntity.Breed.HYBRID_TEDDY_KADHMAWI, 0xF1F5F9, 0x047857, new Item.Properties()));
    public static final RegistryObject<Item> HYBRID_KADHMAWI_GOLDEN_EGG =
            ITEMS.register("hybrid_kadhmawi_golden_egg", () -> new BreedEggItem(ArgonPigeonEntity.Breed.HYBRID_KADHMAWI_GOLDEN, 0xFFFBEB, 0xB45309, new Item.Properties()));
    public static final RegistryObject<Item> HYBRID_TEDDY_GOLDEN_EGG =
            ITEMS.register("hybrid_teddy_golden_egg", () -> new BreedEggItem(ArgonPigeonEntity.Breed.HYBRID_TEDDY_GOLDEN, 0x334155, 0xF59E0B, new Item.Properties()));

    public static final List<RegistryObject<Item>> LEG_RINGS = new ArrayList<>();
    public static final String[] RING_COLOR_NAMES = {
            "red", "pink", "orange", "yellow", "lime", "green", "emerald", "cyan", "light_blue", "blue",
            "navy", "purple", "magenta", "violet", "white", "silver", "gray", "black", "gold", "bronze"
    };
    public static final String[] RING_ARABIC_NAMES = {
            "أحمر", "وردي", "برتقالي", "أصفر", "ليموني فسفوري", "أخضر", "زمردي", "سماوي", "أزرق فاتح", "أزرق",
            "كحلي", "بنفسجي", "أرجواني", "نيلي", "أبيض", "فضي", "رمادي", "أسود", "ذهبي", "برونزي"
    };

    static {
        for (int i = 0; i < RING_COLOR_NAMES.length; i++) {
            final int colorIdx = i;
            final String cName = RING_COLOR_NAMES[i];
            LEG_RINGS.add(ITEMS.register("leg_ring_" + cName,
                    () -> new ColoredLegRingItem(colorIdx, RING_ARABIC_NAMES[colorIdx], new Item.Properties().stacksTo(64))));
        }
    }

    public static final RegistryObject<CreativeModeTab> ARGON_BIRDS_TAB =
            CREATIVE_TABS.register("argon_pigeons_tab", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.argonloftpigeons"))
                    .icon(() -> new ItemStack(GOLDEN_EGG.get()))
                    .displayItems((params, output) -> {
                        output.accept(MARWAN_GUIDE_BOOK.get());
                        output.accept(FANCIER_VILLAGER_EGG.get());
                        output.accept(ZAJIL_EGG.get());
                        output.accept(RED_EGG.get());
                        output.accept(TEDDY_EGG.get());
                        output.accept(KADHMAWI_EGG.get());
                        output.accept(GOLDEN_EGG.get());
                        output.accept(HYBRID_TEDDY_KADHMAWI_EGG.get());
                        output.accept(HYBRID_KADHMAWI_GOLDEN_EGG.get());
                        output.accept(HYBRID_TEDDY_GOLDEN_EGG.get());
                    }).build());

    public static final RegistryObject<CreativeModeTab> ARGON_TOOLS_TAB =
            CREATIVE_TABS.register("argon_tools_tab", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.argonloftpigeons_tools"))
                    .icon(() -> new ItemStack(MARWAN_GUIDE_BOOK.get()))
                    .displayItems((params, output) -> {
                        output.accept(MARWAN_GUIDE_BOOK.get());
                        output.accept(M7_FEED_BAG.get());
                        output.accept(M7_GRAIN_HANDFUL.get());
                        output.accept(CERTIFICATE_ITEM.get());
                        output.accept(PIGEON_SCISSORS.get());
                        output.accept(CATCH_NET.get());
                        output.accept(BLACK_CLOTH.get());
                        for (RegistryObject<Item> ring : LEG_RINGS) {
                            output.accept(ring.get());
                        }
                    }).build());

    public static final RegistryObject<CreativeModeTab> ARGON_LOFT_TAB =
            CREATIVE_TABS.register("argon_loft_tab", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.argonloftpigeons_loft"))
                    .icon(() -> new ItemStack(LOFT_BUILDER_20X10.get()))
                    .displayItems((params, output) -> {
                        output.accept(LOFT_BUILDER_20X10.get());
                        output.accept(COPPER_NEST_BOWL_ITEM.get());
                        output.accept(BREEDING_BOX_ITEM.get());
                        output.accept(PIGEON_FEEDER_ITEM.get());
                        output.accept(PIGEON_ORE_ITEM.get());
                        output.accept(RAW_PIGEON_GEM.get());
                        output.accept(DYNAMI_BLOCK_ITEM.get());
                        output.accept(FANCIER_VILLAGER_EGG.get());
                    }).build());

    public ArgonLoftPigeonsMod() {
        GeckoLib.initialize();
        NETWORK.registerMessage(0, NestActionPacket.class, NestActionPacket::encode, NestActionPacket::decode, NestActionPacket::handle);

        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(modEventBus);
        BLOCKS.register(modEventBus);
        BLOCK_ENTITIES.register(modEventBus);
        ITEMS.register(modEventBus);
        CREATIVE_TABS.register(modEventBus);
        modEventBus.addListener(this::registerAttributes);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(LOFT_PIGEON.get(), ArgonPigeonEntity.createAttributes().build());
        event.put(FANCIER_VILLAGER.get(), FancierVillagerEntity.createAttributes().build());
    }

    /**
     * حل جذري ومضمون 100% لتواجد قروي الطيور (FancierVillagerEntity) في جميع القرى:
     * بمجرد أن يتم تحميل أي قروي ماينكرافت عادي في قرية لا يوجد فيها قروي الطيور ضمن 60 بلوكة،
     * يترسبن قروي الطيور تلقائياً بجانبه داخل القرية!
     */
    @SubscribeEvent
    public void onVillageLoadedEnsureFancier(EntityJoinLevelEvent event) {
        if (event.getLevel().isClientSide()) return;
        if (event.getEntity() instanceof Villager vanillaVillager) {
            List<FancierVillagerEntity> existing = event.getLevel().getEntitiesOfClass(
                    FancierVillagerEntity.class,
                    vanillaVillager.getBoundingBox().inflate(64.0D)
            );
            if (existing.isEmpty()) {
                FancierVillagerEntity fancier = FANCIER_VILLAGER.get().create(event.getLevel());
                if (fancier != null) {
                    fancier.setPos(vanillaVillager.getX() + 1.5D, vanillaVillager.getY(), vanillaVillager.getZ() + 1.5D);
                    event.getLevel().addFreshEntity(fancier);
                }
            }
        }
    }

    /**
     * حل جذري ومضمون 100% لتواجد أور الدينمي (PIGEON_ORE) في جدران الكهوف:
     * بالإضافة إلى توليد الـ Worldgen، يفحص السيرفر جدران الكهوف العميقة حول اللاعب ويزرع عروق أور الدينمي
     * في الصخور الملاصقة لهواء الكهف حتى في العوالم المنشأة مسبقاً!
     */
    @SubscribeEvent
    public void onPlayerCaveExploreSeedDynami(TickEvent.PlayerTickEvent event) {
        if (event.phase != TickEvent.Phase.END || event.player.level().isClientSide()) return;
        if (event.player.tickCount % 60 != 0) return;

        var level = event.player.level();
        BlockPos playerPos = event.player.blockPosition();
        for (int attempt = 0; attempt < 6; attempt++) {
            int dx = level.random.nextInt(32) - 16;
            int dz = level.random.nextInt(32) - 16;
            int targetY = -50 + level.random.nextInt(92); // من Y = -50 إلى Y = 42 في الكهوف
            BlockPos checkPos = new BlockPos(playerPos.getX() + dx, targetY, playerPos.getZ() + dz);
            if (!level.isLoaded(checkPos)) continue;

            BlockState st = level.getBlockState(checkPos);
            if (st.is(Blocks.STONE) || st.is(Blocks.DEEPSLATE)) {
                // التأكد أن البلوكة في جدار كهف (ملاصقة لهواء كهف ومظلمة تحت الأرض)
                boolean touchesCaveAir = level.getBlockState(checkPos.above()).isAir()
                        || level.getBlockState(checkPos.north()).isAir()
                        || level.getBlockState(checkPos.south()).isAir()
                        || level.getBlockState(checkPos.east()).isAir()
                        || level.getBlockState(checkPos.west()).isAir();

                if (touchesCaveAir && !level.canSeeSky(checkPos)) {
                    // عدم التكرار إذا كان هناك أور دينمي قريب جداً
                    boolean alreadyHasOre = false;
                    for (BlockPos near : BlockPos.betweenClosed(checkPos.offset(-6, -4, -6), checkPos.offset(6, 4, 6))) {
                        if (level.getBlockState(near).is(PIGEON_ORE.get())) {
                            alreadyHasOre = true;
                            break;
                        }
                    }
                    if (!alreadyHasOre) {
                        level.setBlock(checkPos, PIGEON_ORE.get().defaultBlockState(), 2);
                        // إضافة حبتين إضافيتين في العرق
                        BlockPos n2 = checkPos.offset(level.random.nextInt(3) - 1, 0, level.random.nextInt(3) - 1);
                        if (level.getBlockState(n2).is(Blocks.STONE) || level.getBlockState(n2).is(Blocks.DEEPSLATE)) {
                            level.setBlock(n2, PIGEON_ORE.get().defaultBlockState(), 2);
                        }
                        break;
                    }
                }
            }
        }
    }

    @SubscribeEvent
    public void onVillagerTrades(VillagerTradesEvent event) {
        if (event.getType() == VillagerProfession.FARMER || event.getType() == VillagerProfession.SHEPHERD) {
            var trades = event.getTrades().get(1);
            trades.add((trader, rand) -> new MerchantOffer(
                    new ItemStack(Items.IRON_INGOT, 1),
                    new ItemStack(M7_FEED_BAG.get(), 2), 16, 2, 0.05F));
            trades.add((trader, rand) -> new MerchantOffer(
                    new ItemStack(RAW_PIGEON_GEM.get(), 1),
                    new ItemStack(ZAJIL_EGG.get(), 1), 12, 5, 0.05F));
            trades.add((trader, rand) -> new MerchantOffer(
                    new ItemStack(RAW_PIGEON_GEM.get(), 1),
                    new ItemStack(RED_EGG.get(), 1), 12, 5, 0.05F));
            trades.add((trader, rand) -> new MerchantOffer(
                    new ItemStack(RAW_PIGEON_GEM.get(), 1),
                    new ItemStack(TEDDY_EGG.get(), 1), 12, 5, 0.05F));
            trades.add((trader, rand) -> new MerchantOffer(
                    new ItemStack(RAW_PIGEON_GEM.get(), 1),
                    new ItemStack(KADHMAWI_EGG.get(), 1), 12, 5, 0.05F));
            trades.add((trader, rand) -> new MerchantOffer(
                    new ItemStack(RAW_PIGEON_GEM.get(), 1),
                    new ItemStack(GOLDEN_EGG.get(), 1), 12, 5, 0.05F));
        }
    }

    @Mod.EventBusSubscriber(modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
            EntityRenderers.register(LOFT_PIGEON.get(), ArgonPigeonRenderer::new);
            EntityRenderers.register(FANCIER_VILLAGER.get(), FancierVillagerRenderer::new);
        }

        public static void openMarwanGuideBook(ItemStack stack) {
            Minecraft.getInstance().setScreen(new BookViewScreen(new BookViewScreen.WrittenBookAccess(stack)));
        }

        public static void openNestControlScreen(BlockPos pos) {
            Minecraft.getInstance().setScreen(new NestControlScreen(pos));
        }
    }
}
