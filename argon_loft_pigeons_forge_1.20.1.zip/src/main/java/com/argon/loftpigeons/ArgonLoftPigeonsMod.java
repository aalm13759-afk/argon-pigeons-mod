package com.argon.loftpigeons;

import com.argon.loftpigeons.client.ArgonPigeonRenderer;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import com.argon.loftpigeons.item.BreedSpawnEggItem;
import com.argon.loftpigeons.item.FancierWhistleItem;
import com.argon.loftpigeons.item.LoftCageItem;
import com.argon.loftpigeons.item.PigeonEncyclopediaItem;
import net.minecraft.client.renderer.entity.EntityRenderers;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;
import software.bernie.geckolib.GeckoLib;

@Mod(ArgonLoftPigeonsMod.MOD_ID)
public class ArgonLoftPigeonsMod {
    public static final String MOD_ID = "argonloftpigeons";

    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, MOD_ID);
    public static final DeferredRegister<Item> ITEMS =
            DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> CREATIVE_TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    public static final RegistryObject<EntityType<ArgonPigeonEntity>> LOFT_PIGEON =
            ENTITIES.register("loft_pigeon", () -> EntityType.Builder.of(ArgonPigeonEntity::new, MobCategory.CREATURE)
                    .sized(0.5F, 0.65F)
                    .clientTrackingRange(128)
                    .build("loft_pigeon"));

    // 3 بيضات رسمنة منفصلة لكل سلالة حتى تظهر جميع الطيور الثلاثة في قائمة الإبداعي بشكل مستقل!
    public static final RegistryObject<Item> GOLDEN_PRINCE_EGG =
            ITEMS.register("golden_prince_spawn_egg", () -> new BreedSpawnEggItem(
                    LOFT_PIGEON, ArgonPigeonEntity.Breed.GOLDEN_PRINCE, 0xF8FAFC, 0x334155, new Item.Properties()));

    public static final RegistryObject<Item> RED_AGHAR_EGG =
            ITEMS.register("red_aghar_spawn_egg", () -> new BreedSpawnEggItem(
                    LOFT_PIGEON, ArgonPigeonEntity.Breed.RED_AGHAR, 0x853126, 0xFFFFFF, new Item.Properties()));

    public static final RegistryObject<Item> ZAJIL_HOMER_EGG =
            ITEMS.register("zajil_homer_spawn_egg", () -> new BreedSpawnEggItem(
                    LOFT_PIGEON, ArgonPigeonEntity.Breed.ZAJIL_HOMER, 0x7B8D9E, 0x1E6B5E, new Item.Properties()));

    public static final RegistryObject<Item> LOFT_CAGE =
            ITEMS.register("loft_cage", () -> new LoftCageItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> FANCIER_WHISTLE =
            ITEMS.register("fancier_whistle", () -> new FancierWhistleItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<Item> PIGEON_ENCYCLOPEDIA =
            ITEMS.register("pigeon_encyclopedia", () -> new PigeonEncyclopediaItem(new Item.Properties().stacksTo(1)));

    public static final RegistryObject<CreativeModeTab> ARGON_TAB =
            CREATIVE_TABS.register("argon_pigeons_tab", () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.argonloftpigeons"))
                    .icon(() -> new ItemStack(FANCIER_WHISTLE.get()))
                    .displayItems((params, output) -> {
                        output.accept(GOLDEN_PRINCE_EGG.get());
                        output.accept(RED_AGHAR_EGG.get());
                        output.accept(ZAJIL_HOMER_EGG.get());
                        output.accept(LOFT_CAGE.get());
                        output.accept(FANCIER_WHISTLE.get());
                        output.accept(PIGEON_ENCYCLOPEDIA.get());
                    }).build());

    public ArgonLoftPigeonsMod() {
        GeckoLib.initialize();
        IEventBus modEventBus = FMLJavaModLoadingContext.get().getModEventBus();
        ENTITIES.register(modEventBus);
        ITEMS.register(modEventBus);
        CREATIVE_TABS.register(modEventBus);
        modEventBus.addListener(this::registerAttributes);
        MinecraftForge.EVENT_BUS.register(this);
    }

    private void registerAttributes(EntityAttributeCreationEvent event) {
        event.put(LOFT_PIGEON.get(), ArgonPigeonEntity.createAttributes().build());
    }

    @Mod.EventBusSubscriber(modid = MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
    public static class ClientModEvents {
        @SubscribeEvent
        public static void onClientSetup(FMLClientSetupEvent event) {
            EntityRenderers.register(LOFT_PIGEON.get(), ArgonPigeonRenderer::new);
        }
    }
}
