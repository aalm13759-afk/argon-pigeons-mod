package com.argon.loftpigeons.block;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import org.jetbrains.annotations.Nullable;

/**
 * خانة التزاوج الكوارتزية المربوطة بالعش (Quartz Breeding Box):
 * عند وضعها تُجهز تلقائياً بالعش الكبير، وتفتح واجهة أزرار العش عند الضغط عليها.
 */
public class BreedingBoxBlock extends BaseEntityBlock {
    public BreedingBoxBlock(Properties props) {
        super(props);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        BreedingBoxBlockEntity be = new BreedingBoxBlockEntity(pos, state);
        be.preEquipForLoft();
        return be;
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        super.setPlacedBy(level, pos, state, placer, stack);
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof BreedingBoxBlockEntity box) {
            box.preEquipForLoft();
            // بناء إطار خانة الكوارتز الماينكرافتية المربوطة بالعش إذا كان اللاعب يضغط Shift
            if (placer != null && placer.isShiftKeyDown()) {
                box.buildLinkedQuartzEnclosure(level, pos);
            }
        }
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        super.entityInside(state, level, pos, entity);
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof BreedingBoxBlockEntity box) {
            box.tryAcceptWalkingPigeon(entity);
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof BreedingBoxBlockEntity box) {
            if (!player.getItemInHand(hand).isEmpty()) {
                if (!level.isClientSide) {
                    return box.handleRightClick(player, player.getItemInHand(hand), hand);
                }
                return InteractionResult.SUCCESS;
            } else {
                if (level.isClientSide) {
                    DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ArgonLoftPigeonsMod.ClientModEvents.openNestControlScreen(pos));
                } else {
                    box.executeButtonAction(player, 1);
                }
                return InteractionResult.SUCCESS;
            }
        }
        return InteractionResult.PASS;
    }

    @Override
    public void attack(BlockState state, Level level, BlockPos pos, Player player) {
        if (!level.isClientSide) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof BreedingBoxBlockEntity box) {
                box.extractContentsToPlayer(player);
            }
        }
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, ArgonLoftPigeonsMod.BREEDING_BOX_ENTITY.get(), BreedingBoxBlockEntity::serverTick);
    }
}
