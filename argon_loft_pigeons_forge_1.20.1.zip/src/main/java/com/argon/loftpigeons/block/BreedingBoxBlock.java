package com.argon.loftpigeons.block;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import org.jetbrains.annotations.Nullable;

/**
 * خانة التزاوج (Breeding Box):
 * - كلك يمين: إدخال الفحل والأنثى، وضع الفخار النحاسي (عش البيض)، وضع المعلف وتعبئته بأكل m7.
 * - كلك يسار (ضربة واحدة): فتح/سحب محتويات الخانة (الأبوين أو الفراخ أو المعلف) إلى الإنفنتوري.
 */
public class BreedingBoxBlock extends BaseEntityBlock {
    public BreedingBoxBlock(Properties props) {
        super(props);
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new BreedingBoxBlockEntity(pos, state);
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof BreedingBoxBlockEntity box) {
            return box.handleRightClick(player, player.getItemInHand(hand));
        }
        return InteractionResult.PASS;
    }

    @Override
    public void attack(BlockState state, Level level, BlockPos pos, Player player) {
        if (!level.isClientSide) {
            BlockEntity be = level.getBlockEntity(pos);
            if (be instanceof BreedingBoxBlockEntity box) {
                box.extractContentsToPlayer(player);
            }
        }
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, ArgonLoftPigeonsMod.BREEDING_BOX_ENTITY.get(), BreedingBoxBlockEntity::serverTick);
    }
}
