package com.argon.loftpigeons.block;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import com.argon.loftpigeons.item.BreedEggItem;
import com.argon.loftpigeons.item.CatchNetItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * الكيان البرمجي الموحد للعش الكبير وخانة التزاوج الكوارتزية:
 * - يستقبل طيرين للتزاوج (سواء دخلا العش مشياً أو أدخلهما اللاعب بالشبكة).
 * - إذا حاول اللاعب مزاوجة ذكر بذكر (أو أنثى بأنثى) ونسي فحصهما بالبطاقة، تخرج رسالة ERROR حمراء في الشات!
 * - ينفذ أزرار واجهة العش:
 *   1) رؤية ما بداخل العش
 *   2) إخراج الفراخ إذا فقسوا وكبروا
 *   3) إخراج البيضة من العش (لتفقس وتنكسر على الأرض)
 *   4) إخراج الأبوين / بناء خانة الكوارتز المربوطة بالعش
 */
public class BreedingBoxBlockEntity extends BlockEntity {
    private boolean hasCopperBowl = true;
    private boolean hasFeeder = true;
    private int m7FoodUnits = 20;

    private CompoundTag firstBirdData = null;
    private CompoundTag secondBirdData = null;
    private int eggCount = 0;
    private int squabCount = 0;
    private int cycleTicks = 0;
    private int errorCooldownTicks = 0;

    public BreedingBoxBlockEntity(BlockPos pos, BlockState state) {
        super(ArgonLoftPigeonsMod.BREEDING_BOX_ENTITY.get(), pos, state);
    }

    public void preEquipForLoft() {
        this.hasCopperBowl = true;
        this.hasFeeder = true;
        if (this.m7FoodUnits < 20) this.m7FoodUnits = 20;
        syncToClient();
    }

    public void syncToClient() {
        setChanged();
        if (this.level != null && !this.level.isClientSide) {
            BlockState st = getBlockState();
            this.level.sendBlockUpdated(this.worldPosition, st, st, 3);
        }
    }

    /**
     * عندما يدخل طير إلى العش مشياً (أو يقترب طيران من العش) يتزاوجان،
     * وإذا كانا ذكرين (ذكر بذكر) تظهر رسالة ERROR في الشات!
     */
    public void tryAcceptWalkingPigeon(Entity entity) {
        if (!(entity instanceof ArgonPigeonEntity pigeon) || this.level == null || this.level.isClientSide) return;
        if (pigeon.getSquabDay() > 0 || !pigeon.isAlive()) return;
        if (this.firstBirdData != null && this.secondBirdData != null) return;

        // فحص إذا كان هناك طير أول في العش بالفعل
        if (this.firstBirdData != null) {
            boolean firstIsMale = this.firstBirdData.getBoolean("IsMale");
            boolean secondIsMale = pigeon.isMale();

            if (firstIsMale == secondIsMale) {
                if (this.errorCooldownTicks <= 0) {
                    this.errorCooldownTicks = 80;
                    Player nearest = this.level.getNearestPlayer(this.worldPosition.getX(), this.worldPosition.getY(), this.worldPosition.getZ(), 16.0D, false);
                    if (nearest != null) {
                        if (firstIsMale) {
                            nearest.sendSystemMessage(Component.literal("§4§l[ERROR - خطأ في التزاوج!] §cلا يمكن مزاوجة ذكر بذكر (فحل ♂ مع فحل ♂) داخل العش! لقد نسيت فحص الطيور ببطاقة المعلومات (Certificate)!"));
                        } else {
                            nearest.sendSystemMessage(Component.literal("§4§l[ERROR - خطأ في التزاوج!] §cلا يمكن مزاوجة أنثى بأنثى (♀ مع ♀) داخل العش! افحص الجنس ببطاقة المعلومات أولاً."));
                        }
                        this.level.playSound(null, this.worldPosition, SoundEvents.VILLAGER_NO, SoundSource.BLOCKS, 1.0F, 0.8F);
                    }
                }
                // إبعاد الطير الثاني من العش لأنه من نفس الجنس
                pigeon.setDeltaMovement((this.level.random.nextDouble() - 0.5D) * 0.4D, 0.25D, (this.level.random.nextDouble() - 0.5D) * 0.4D);
                return;
            }
        }

        // قبول الطير داخل العش
        CompoundTag tag = new CompoundTag();
        pigeon.addAdditionalSaveData(tag);
        if (this.firstBirdData == null) {
            this.firstBirdData = tag;
        } else {
            this.secondBirdData = tag;
            if (this.level instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.HEART, this.worldPosition.getX() + 0.5D, this.worldPosition.getY() + 0.6D, this.worldPosition.getZ() + 0.5D, 12, 0.3D, 0.25D, 0.3D, 0.02D);
            }
            Player nearest = this.level.getNearestPlayer(this.worldPosition.getX(), this.worldPosition.getY(), this.worldPosition.getZ(), 16.0D, false);
            if (nearest != null) {
                nearest.sendSystemMessage(Component.literal("§a§l[العش الكبير] §fدخل الفحل ♂ والأنثى ♀ إلى العش وبدأ التزاوج بنجاح!"));
            }
        }
        pigeon.discard();
        syncToClient();
    }

    public InteractionResult handleRightClick(Player player, ItemStack stack, InteractionHand hand) {
        // 1. تعبئة الدخن في العش/الخانة
        if (stack.is(ArgonLoftPigeonsMod.M7_GRAIN_HANDFUL.get()) || stack.is(ArgonLoftPigeonsMod.M7_FEED_BAG.get())) {
            this.hasFeeder = true;
            this.m7FoodUnits += 15;
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.displayClientMessage(Component.literal("§a[عش التزاوج] §fتم وضع الدخن داخل العش (الرصيد: " + this.m7FoodUnits + ")."), true);
            syncToClient();
            return InteractionResult.SUCCESS;
        }

        // 2. إدخال طير ممسوك بالشبكة (مع فحص خطأ ذكر × ذكر!)
        if (stack.is(ArgonLoftPigeonsMod.CATCH_NET.get()) && CatchNetItem.hasCapturedPigeon(stack)) {
            CompoundTag pTag = stack.getTag().getCompound("CapturedPigeon").copy();
            boolean incomingMale = pTag.getBoolean("IsMale");
            String breedAr = ArgonPigeonEntity.Breed.fromId(pTag.getString("Breed")).arabicName;

            if (this.firstBirdData == null) {
                this.firstBirdData = pTag;
                CatchNetItem.clearCapturedPigeon(stack);
                player.setItemInHand(hand, stack);
                player.inventoryMenu.broadcastChanges();
                player.sendSystemMessage(Component.literal("§b[عش التزاوج] §fتم إدخال الطير الأول في العش: §e" + breedAr + " (" + (incomingMale ? "فحل ♂" : "أنثى ♀") + ")"));
                syncToClient();
                return InteractionResult.SUCCESS;
            } else if (this.secondBirdData == null) {
                boolean firstMale = this.firstBirdData.getBoolean("IsMale");
                if (firstMale == incomingMale) {
                    // رسالة الخطأ الحمراء المطلوبة عندما يزاوج اللاعب ذكر بذكر وينسى فحصهما بالبطاقة!
                    if (incomingMale) {
                        player.sendSystemMessage(Component.literal("§4§l[ERROR - خطأ في التزاوج!] §cلا يمكن مزاوجة ذكر مع ذكر (فحل ♂ مع فحل ♂)! لقد نسيت فحص الطيور ببطاقة المعلومات (Certificate) قبل وضعها في العش!"));
                    } else {
                        player.sendSystemMessage(Component.literal("§4§l[ERROR - خطأ في التزاوج!] §cلا يمكن مزاوجة أنثى مع أنثى (♀ مع ♀)! لقد نسيت فحص الطيور ببطاقة المعلومات (Certificate)!"));
                    }
                    if (this.level != null) {
                        this.level.playSound(null, this.worldPosition, SoundEvents.VILLAGER_NO, SoundSource.BLOCKS, 1.0F, 0.75F);
                    }
                    return InteractionResult.FAIL;
                }

                this.secondBirdData = pTag;
                CatchNetItem.clearCapturedPigeon(stack);
                player.setItemInHand(hand, stack);
                player.inventoryMenu.broadcastChanges();
                if (this.level instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.HEART, this.worldPosition.getX() + 0.5D, this.worldPosition.getY() + 0.6D, this.worldPosition.getZ() + 0.5D, 14, 0.3D, 0.25D, 0.3D, 0.02D);
                }
                player.sendSystemMessage(Component.literal("§a§l[نجاح التزاوج!] §fاجتمع الفحل ♂ والأنثى ♀ داخل العش الكبير وبدأت دورة إنتاج البيض!"));
                syncToClient();
                return InteractionResult.SUCCESS;
            } else {
                player.sendSystemMessage(Component.literal("§e[عش التزاوج] §fالعش يتسع لطيرين فقط وهو ممتلئ حالياً!"));
                return InteractionResult.FAIL;
            }
        }

        // 3. فتح واجهة الأزرار عند الضغط بأي أداة أخرى
        executeButtonAction(player, 1);
        return InteractionResult.SUCCESS;
    }

    /**
     * تنفيذ أوامر الأزرار في واجهة العش (NestControlScreen):
     * 1 = يرى اللاعب ما بداخل العش
     * 2 = الفراخ إذا كبروا وفقسوا يخرجهم اللاعب من العش
     * 3 = إخراج البيضة من العش (وعند وضعها بالأرض تفقس وتنكسر وحدها)
     * 4 = إخراج الأبوين من العش
     * 5 = بناء خانة التزاوج ببلوكات الكوارتز المربوطة بالعش
     */
    public void executeButtonAction(Player player, int actionId) {
        if (this.level == null || this.level.isClientSide) return;

        switch (actionId) {
            case 1 -> {
                player.sendSystemMessage(Component.literal("§3§l=== [محتويات عش التزاوج وخانة الكوارتز] ==="));
                player.sendSystemMessage(Component.literal("§f• الطير الأول: " + formatBirdTag(this.firstBirdData)));
                player.sendSystemMessage(Component.literal("§f• الطير الثاني: " + formatBirdTag(this.secondBirdData)));
                player.sendSystemMessage(Component.literal("§f• البيض داخل العش: §e" + this.eggCount + " بيضة §7| §fالفراخ الفاقسة: §a" + this.squabCount + " فرخ"));
            }
            case 2 -> {
                if (this.squabCount <= 0) {
                    player.sendSystemMessage(Component.literal("§c[العش] §fلا توجد فراخ فاقسة جاهزة للإخراج حالياً! (البيض الحالي: " + this.eggCount + ")"));
                    return;
                }
                spawnSquabsFromNest(this.level, this.worldPosition, player);
                this.squabCount = 0;
                this.cycleTicks = 0;
                syncToClient();
            }
            case 3 -> {
                if (this.eggCount <= 0) {
                    player.sendSystemMessage(Component.literal("§c[العش] §fلا يوجد بيض داخل العش حالياً لإخراجه!"));
                    return;
                }
                ArgonPigeonEntity.Breed eggBreed = getOffspringBreed();
                Item eggItem = getEggItemForBreed(eggBreed);
                ItemStack eggStack = new ItemStack(eggItem, 1);
                player.getInventory().placeItemBackInInventory(eggStack);
                this.eggCount--;
                syncToClient();
                player.sendSystemMessage(Component.literal("§e§l[إخراج البيضة] §fأخرجت بيضة §b" + eggBreed.arabicName + " §fمن العش! ضعها أو ارمها على الأرض لتفقس وتنكسر وحدها!"));
            }
            case 4 -> extractContentsToPlayer(player);
            case 5 -> {
                buildLinkedQuartzEnclosure(this.level, this.worldPosition);
                player.sendSystemMessage(Component.literal("§b[خانة الكوارتز] §fتم بناء خانة تزاوج ببلوكات الكوارتز الماينكرافتية وربطها بالعش!"));
            }
        }
    }

    /**
     * بناء خانة تزاوج ببلوكات الكوارتز الماينكرافتية (Quartz Blocks, Pillars, Smooth Quartz Slabs, Iron Bars) مربوطة حول العش!
     */
    public void buildLinkedQuartzEnclosure(Level level, BlockPos nestPos) {
        // أرضية وسقف وجوانب من الكوارتز حول موقع العش (3×3×3) مع الإبقاء على العش الكبير في المنتصف
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                level.setBlock(nestPos.offset(dx, -1, dz), Blocks.QUARTZ_BLOCK.defaultBlockState(), 3);
                level.setBlock(nestPos.offset(dx, 2, dz), Blocks.SMOOTH_QUARTZ_SLAB.defaultBlockState(), 3);
            }
        }
        // جدران الكوارتز الخلفية والجانبية
        for (int dy = 0; dy <= 1; dy++) {
            for (int dx = -1; dx <= 1; dx++) {
                level.setBlock(nestPos.offset(dx, dy, 1), Blocks.QUARTZ_PILLAR.defaultBlockState(), 3);
            }
            level.setBlock(nestPos.offset(-1, dy, 0), Blocks.QUARTZ_BLOCK.defaultBlockState(), 3);
            level.setBlock(nestPos.offset(1, dy, 0), Blocks.QUARTZ_BLOCK.defaultBlockState(), 3);
            level.setBlock(nestPos.offset(-1, dy, -1), Blocks.QUARTZ_PILLAR.defaultBlockState(), 3);
            level.setBlock(nestPos.offset(1, dy, -1), Blocks.QUARTZ_PILLAR.defaultBlockState(), 3);
        }
        // واجهة قضبان حديد فوق المدخل الأمامي للعش
        level.setBlock(nestPos.offset(0, 1, -1), Blocks.IRON_BARS.defaultBlockState(), 3);
        // معلف بجانب العش داخل خانة الكوارتز
        if (level.getBlockState(nestPos.offset(0, 0, -1)).isAir()) {
            level.setBlock(nestPos.offset(0, 0, -1), ArgonLoftPigeonsMod.DUKHN_PILE.get().defaultBlockState(), 3);
        }
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, BreedingBoxBlockEntity box) {
        if (box.errorCooldownTicks > 0) box.errorCooldownTicks--;

        // فحص تلقائي للطيور الواقفة فوق العش مباشرة للدخول والتزاوج
        if (level.getGameTime() % 20 == 0 && (box.firstBirdData == null || box.secondBirdData == null)) {
            List<ArgonPigeonEntity> nearby = level.getEntitiesOfClass(
                    ArgonPigeonEntity.class,
                    new net.minecraft.world.phys.AABB(pos).inflate(0.85D),
                    p -> !p.isFlightActive() && p.getSquabDay() == 0
            );
            for (ArgonPigeonEntity p : nearby) {
                box.tryAcceptWalkingPigeon(p);
                if (box.firstBirdData != null && box.secondBirdData != null) break;
            }
        }

        if (box.firstBirdData == null || box.secondBirdData == null) return;

        box.cycleTicks += 20;

        // قلوب تزاوج دورية فوق العش عندما يكون الزوج بالداخل
        if (box.cycleTicks % 200 == 0 && level instanceof ServerLevel sl) {
            sl.sendParticles(ParticleTypes.HEART, pos.getX() + 0.5D, pos.getY() + 0.5D, pos.getZ() + 0.5D, 3, 0.25D, 0.15D, 0.25D, 0.01D);
        }

        // إنتاج البيضة الأولى سريعاً (بعد 600 تيك = 30 ثانية للمتعة الفورية أو يوم تزاوج) والبيضة الثانية (1200 تيك)
        if (box.cycleTicks >= 600 && box.eggCount == 0 && box.squabCount == 0) {
            box.eggCount = 1;
            box.syncToClient();
        } else if (box.cycleTicks >= 1200 && box.eggCount == 1 && box.squabCount == 0) {
            box.eggCount = 2;
            box.syncToClient();
        }
        // فقس البيض داخل العش إلى فراخ (بعد 2400 تيك) إذا لم يخرجه اللاعب بيده
        else if (box.cycleTicks >= 2400 && box.eggCount > 0) {
            box.squabCount += box.eggCount;
            box.eggCount = 0;
            level.playSound(null, pos, SoundEvents.TURTLE_EGG_HATCH, SoundSource.BLOCKS, 1.0F, 1.1F);
            box.syncToClient();
        }
    }

    private ArgonPigeonEntity.Breed getOffspringBreed() {
        if (this.firstBirdData != null && this.secondBirdData != null) {
            ArgonPigeonEntity.Breed b1 = ArgonPigeonEntity.Breed.fromId(this.firstBirdData.getString("Breed"));
            ArgonPigeonEntity.Breed b2 = ArgonPigeonEntity.Breed.fromId(this.secondBirdData.getString("Breed"));
            return ArgonPigeonEntity.computeOffspringBreed(b1, b2);
        }
        if (this.firstBirdData != null) {
            return ArgonPigeonEntity.Breed.fromId(this.firstBirdData.getString("Breed"));
        }
        return ArgonPigeonEntity.Breed.ZAJIL;
    }

    public static Item getEggItemForBreed(ArgonPigeonEntity.Breed breed) {
        return switch (breed) {
            case ZAJIL -> ArgonLoftPigeonsMod.ZAJIL_EGG.get();
            case RED -> ArgonLoftPigeonsMod.RED_EGG.get();
            case TEDDY -> ArgonLoftPigeonsMod.TEDDY_EGG.get();
            case KADHMAWI -> ArgonLoftPigeonsMod.KADHMAWI_EGG.get();
            case GOLDEN -> ArgonLoftPigeonsMod.GOLDEN_EGG.get();
            case HYBRID_TEDDY_KADHMAWI -> ArgonLoftPigeonsMod.HYBRID_TEDDY_KADHMAWI_EGG.get();
            case HYBRID_KADHMAWI_GOLDEN -> ArgonLoftPigeonsMod.HYBRID_KADHMAWI_GOLDEN_EGG.get();
            case HYBRID_TEDDY_GOLDEN -> ArgonLoftPigeonsMod.HYBRID_TEDDY_GOLDEN_EGG.get();
        };
    }

    private void spawnSquabsFromNest(Level level, BlockPos pos, @Nullable Player player) {
        ArgonPigeonEntity.Breed offspringBreed = getOffspringBreed();
        int count = Math.max(1, this.squabCount);
        for (int i = 0; i < count; i++) {
            ArgonPigeonEntity squab = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(level);
            if (squab != null) {
                squab.rollStatsForBreed(offspringBreed);
                squab.startAsNewbornSquab(); // يبدأ في اليوم 1 ويكبر على مدار 5 أيام ماينكرافتية!
                squab.setPos(pos.getX() + 0.5D + (i * 0.25D), pos.getY() + 0.6D, pos.getZ() + 0.5D);
                squab.setHomeRoof(pos);
                if (player != null) squab.tame(player);
                level.addFreshEntity(squab);
            }
        }
        if (player != null) {
            player.sendSystemMessage(Component.literal("§a§l[إخراج الفراخ] §fتم إخراج §e" + count + " فرخ (" + offspringBreed.arabicName + ") §fمن العش! سيكبر حجمه وشكله تدريجياً كل يوم لمدة 5 أيام ماينكرافتية."));
        }
    }

    public void extractContentsToPlayer(Player player) {
        if (this.level == null) return;
        if (this.squabCount > 0) {
            spawnSquabsFromNest(this.level, this.worldPosition, player);
            this.squabCount = 0;
            syncToClient();
            return;
        }
        if (this.firstBirdData != null) {
            ArgonPigeonEntity b1 = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(this.level);
            if (b1 != null) {
                b1.readAdditionalSaveData(this.firstBirdData);
                b1.setPos(this.worldPosition.getX() + 0.5D, this.worldPosition.getY() + 0.6D, this.worldPosition.getZ() + 0.5D);
                this.level.addFreshEntity(b1);
            }
            this.firstBirdData = null;
        }
        if (this.secondBirdData != null) {
            ArgonPigeonEntity b2 = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(this.level);
            if (b2 != null) {
                b2.readAdditionalSaveData(this.secondBirdData);
                b2.setPos(this.worldPosition.getX() + 0.5D, this.worldPosition.getY() + 0.6D, this.worldPosition.getZ() + 0.5D);
                this.level.addFreshEntity(b2);
            }
            this.secondBirdData = null;
        }
        syncToClient();
        player.sendSystemMessage(Component.literal("§6[العش] §fتم إخراج الأبوين من العش."));
    }

    private String formatBirdTag(@Nullable CompoundTag tag) {
        if (tag == null) return "§7(فارغ)";
        String br = ArgonPigeonEntity.Breed.fromId(tag.getString("Breed")).arabicName;
        boolean male = tag.getBoolean("IsMale");
        return (male ? "§bفحل ♂ " : "§dأنثى ♀ ") + "§f" + br + " §7(ذكاء " + tag.getInt("Mentally") + "%)";
    }

    public String getGuiLine1() {
        return "الطير 1: " + formatBirdTag(this.firstBirdData);
    }

    public String getGuiLine2() {
        return "الطير 2: " + formatBirdTag(this.secondBirdData);
    }

    public String getGuiLine3() {
        return "البيض في العش: " + this.eggCount + " | الفراخ الجاهزة: " + this.squabCount;
    }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = super.getUpdateTag();
        saveAdditional(tag);
        return tag;
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putBoolean("HasBowl", this.hasCopperBowl);
        tag.putBoolean("HasFeeder", this.hasFeeder);
        tag.putInt("M7Food", this.m7FoodUnits);
        tag.putInt("Eggs", this.eggCount);
        tag.putInt("Squabs", this.squabCount);
        tag.putInt("CycleTicks", this.cycleTicks);
        if (this.firstBirdData != null) tag.put("FirstBird", this.firstBirdData);
        if (this.secondBirdData != null) tag.put("SecondBird", this.secondBirdData);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.hasCopperBowl = tag.getBoolean("HasBowl");
        this.hasFeeder = tag.getBoolean("HasFeeder");
        this.m7FoodUnits = tag.getInt("M7Food");
        this.eggCount = tag.getInt("Eggs");
        this.squabCount = tag.getInt("Squabs");
        this.cycleTicks = tag.getInt("CycleTicks");
        this.firstBirdData = tag.contains("FirstBird") ? tag.getCompound("FirstBird") : (tag.contains("Male") ? tag.getCompound("Male") : null);
        this.secondBirdData = tag.contains("SecondBird") ? tag.getCompound("SecondBird") : (tag.contains("Female") ? tag.getCompound("Female") : null);
    }
}
