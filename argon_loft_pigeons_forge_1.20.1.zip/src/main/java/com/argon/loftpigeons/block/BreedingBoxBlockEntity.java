package com.argon.loftpigeons.block;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import com.argon.loftpigeons.item.BreedEggItem;
import com.argon.loftpigeons.item.CatchNetItem;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;

/**
 * منطق خانة التزاوج ودورة البيض والفراخ الكاملة:
 * - لا تبيض الأنثى أبداً بدون الفخار النحاسي (hasCopperBowl).
 * - تبيض البيضة الأولى بعد يوم ماينكرافتي (Day 1)، والثانية في اليوم الثالث (Day 3).
 * - ترقد عليهما 5 أيام حتى يفقس فرخان صغيران.
 * - يزق الأبوان الفراخ من المعلف المعبأ بـ m7 لمدة 5 أيام، وفي اليوم السادس يدخل الفرخ الريشة الأولى ويصبح جاهزاً للخروج!
 */
public class BreedingBoxBlockEntity extends BlockEntity {
    private boolean hasCopperBowl = false;
    private boolean hasFeeder = false;
    private int m7FoodUnits = 0;

    private CompoundTag maleData = null;
    private CompoundTag femaleData = null;
    private int eggCount = 0;
    private int squabCount = 0;
    private int cycleTicks = 0;

    public BreedingBoxBlockEntity(BlockPos pos, BlockState state) {
        super(ArgonLoftPigeonsMod.BREEDING_BOX_ENTITY.get(), pos, state);
    }

    public void preEquipForLoft() {
        this.hasCopperBowl = true;
        this.hasFeeder = true;
        this.m7FoodUnits = 20;
        setChanged();
    }

    public InteractionResult handleRightClick(Player player, ItemStack stack) {
        // 1. وضع الفخار النحاسي (عش البيض)
        if (stack.is(ArgonLoftPigeonsMod.COPPER_NEST_BOWL_ITEM.get()) && !this.hasCopperBowl) {
            this.hasCopperBowl = true;
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.displayClientMessage(Component.literal("§a[خانة التزاوج] §fتم وضع الفخار النحاسي داخل الخانة."), true);
            setChanged();
            return InteractionResult.SUCCESS;
        }

        // 2. وضع المعلف
        if (stack.is(ArgonLoftPigeonsMod.PIGEON_FEEDER_ITEM.get()) && !this.hasFeeder) {
            this.hasFeeder = true;
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.displayClientMessage(Component.literal("§a[خانة التزاوج] §fتم وضع المعلف داخل الخانة. عبّئه الآن بأكل m7!"), true);
            setChanged();
            return InteractionResult.SUCCESS;
        }

        // 3. تعبئة المعلف بأكل m7
        if (stack.is(ArgonLoftPigeonsMod.M7_GRAIN_HANDFUL.get()) || stack.is(ArgonLoftPigeonsMod.M7_FEED_BAG.get())) {
            if (!this.hasFeeder) {
                player.displayClientMessage(Component.literal("§c[تنبيه] §fضع المعلف أولاً داخل الخانة!"), true);
                return InteractionResult.FAIL;
            }
            this.m7FoodUnits += 10;
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.displayClientMessage(Component.literal("§a[المعلف] §fتم تعبئة المعلف بأكل m7 (الرصيد: " + this.m7FoodUnits + ")."), true);
            setChanged();
            return InteractionResult.SUCCESS;
        }

        // 4. إدخال طير ممسوك بالشبكة (فحل أو أنثى)
        if (stack.is(ArgonLoftPigeonsMod.CATCH_NET.get()) && CatchNetItem.hasCapturedPigeon(stack)) {
            CompoundTag pTag = stack.getTag().getCompound("CapturedPigeon");
            boolean isMale = pTag.getBoolean("IsMale");
            if (isMale && this.maleData == null) {
                this.maleData = pTag.copy();
                CatchNetItem.clearCapturedPigeon(stack);
                player.displayClientMessage(Component.literal("§b[خانة التزاوج] §fتم إدخال الفحل ♂ في الخانة."), true);
                setChanged();
                return InteractionResult.SUCCESS;
            } else if (!isMale && this.femaleData == null) {
                this.femaleData = pTag.copy();
                CatchNetItem.clearCapturedPigeon(stack);
                player.displayClientMessage(Component.literal("§d[خانة التزاوج] §fتم إدخال الأنثى ♀ في الخانة."), true);
                setChanged();
                return InteractionResult.SUCCESS;
            } else {
                player.displayClientMessage(Component.literal("§c[خانة التزاوج] §fيوجد طير من نفس الجنس داخل الخانة بالفعل!"), true);
                return InteractionResult.FAIL;
            }
        }

        // 5. وضع بيضة مشتراة من القروي داخل الخانة لترسبن الطير
        if (stack.getItem() instanceof BreedEggItem eggItem && this.level != null) {
            eggItem.spawnPigeonAt(this.level, this.worldPosition.above(), player);
            if (!player.getAbilities().instabuild) stack.shrink(1);
            return InteractionResult.SUCCESS;
        }

        // عرض حالة الخانة عند الضغط بيد فارغة
        player.displayClientMessage(Component.literal(
                "§6[خانة التزاوج] §fفخار: " + (hasCopperBowl ? "§aموجود" : "§cمفقود") +
                " §7| §fمعلف m7: §e" + m7FoodUnits +
                " §7| §fالزوج: " + (maleData != null ? "§b♂" : "-") + "/" + (femaleData != null ? "§d♀" : "-") +
                " §7| §fالبيض: §f" + eggCount + " §7| §fالفراخ: §a" + squabCount
        ), true);
        return InteractionResult.SUCCESS;
    }

    public static void serverTick(Level level, BlockPos pos, BlockState state, BreedingBoxBlockEntity box) {
        if (box.maleData == null || box.femaleData == null) return;
        if (!box.hasCopperBowl) return; // لا تبيض الأنثى أبداً بدون الفخار النحاسي!
        if (box.m7FoodUnits <= 0) return;

        box.cycleTicks += 20; // تقدم دورة التزاوج والفقس والزق

        // استهلاك علف m7 دوري
        if (box.cycleTicks % 6000 == 0 && box.m7FoodUnits > 0) {
            box.m7FoodUnits--;
        }

        // اليوم الأول (24,000): البيضة الأولى
        if (box.cycleTicks == 24000 && box.eggCount == 0) {
            box.eggCount = 1;
            box.setChanged();
        }
        // اليوم الثالث (72,000): البيضة الثانية
        else if (box.cycleTicks == 72000 && box.eggCount == 1) {
            box.eggCount = 2;
            box.setChanged();
        }
        // بعد 5 أيام من الرقود (192,000): يفقس فرخان صغيران!
        else if (box.cycleTicks == 192000 && box.eggCount == 2) {
            box.eggCount = 0;
            box.squabCount = 2;
            box.setChanged();
        }
        // بعد 5 أيام من الزق (اليوم السادس للفراخ = 312,000): يدخل الفرخان الريشة الأولى ويخرجان!
        else if (box.cycleTicks >= 312000 && box.squabCount > 0) {
            box.spawnGrownSquabs(level, pos);
            box.squabCount = 0;
            box.cycleTicks = 0;
            box.setChanged();
        }
    }

    private void spawnGrownSquabs(Level level, BlockPos pos) {
        ArgonPigeonEntity.Breed b1 = ArgonPigeonEntity.Breed.fromId(maleData.getString("Breed"));
        ArgonPigeonEntity.Breed b2 = ArgonPigeonEntity.Breed.fromId(femaleData.getString("Breed"));
        ArgonPigeonEntity.Breed offspringBreed = ArgonPigeonEntity.computeOffspringBreed(b1, b2);

        for (int i = 0; i < 2; i++) {
            ArgonPigeonEntity squab = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(level);
            if (squab != null) {
                squab.rollStatsForBreed(offspringBreed);
                squab.setFeatherStage(1); // يدخل الريشة الأولى في اليوم السادس
                squab.setSquabDay(0);
                squab.setPos(pos.getX() + 0.5D, pos.getY() + 1.1D, pos.getZ() + 0.5D);
                level.addFreshEntity(squab);
            }
        }
    }

    /**
     * كلك يسار (ضربة واحدة) على الخانة لسحب الأبوين أو الفراخ أو المعلف إلى الإنفنتوري
     */
    public void extractContentsToPlayer(Player player) {
        if (this.level == null) return;
        if (this.squabCount > 0) {
            spawnGrownSquabs(this.level, this.worldPosition);
            this.squabCount = 0;
            player.displayClientMessage(Component.literal("§a[خانة التزاوج] §fتم إخراج الفراخ من الخانة!"), true);
            return;
        }
        if (this.maleData != null) {
            ArgonPigeonEntity male = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(this.level);
            if (male != null) {
                male.readAdditionalSaveData(this.maleData);
                male.setPos(player.getX(), player.getY() + 0.5D, player.getZ());
                this.level.addFreshEntity(male);
            }
            this.maleData = null;
            player.displayClientMessage(Component.literal("§b[خانة التزاوج] §fتم استخراج الفحل ♂ من الخانة."), true);
            return;
        }
        if (this.femaleData != null) {
            ArgonPigeonEntity female = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(this.level);
            if (female != null) {
                female.readAdditionalSaveData(this.femaleData);
                female.setPos(player.getX(), player.getY() + 0.5D, player.getZ());
                this.level.addFreshEntity(female);
            }
            this.femaleData = null;
            player.displayClientMessage(Component.literal("§d[خانة التزاوج] §fتم استخراج الأنثى ♀ من الخانة."), true);
            return;
        }
        if (this.hasFeeder) {
            this.hasFeeder = false;
            player.getInventory().placeItemBackInInventory(new ItemStack(ArgonLoftPigeonsMod.PIGEON_FEEDER_ITEM.get()));
            player.displayClientMessage(Component.literal("§e[خانة التزاوج] §fتم سحب المعلف إلى الإنفنتوري."), true);
            return;
        }
        if (this.hasCopperBowl) {
            this.hasCopperBowl = false;
            player.getInventory().placeItemBackInInventory(new ItemStack(ArgonLoftPigeonsMod.COPPER_NEST_BOWL_ITEM.get()));
            player.displayClientMessage(Component.literal("§e[خانة التزاوج] §fتم سحب الفخار النحاسي إلى الإنفنتوري."), true);
        }
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putBoolean("HasBowl", this.hasCopperBowl);
        tag.putBoolean("HasFeeder", this.hasFeeder);
        tag.putInt("M7Food", this.m7FoodUnits);
        tag.putInt("Eggs", this.eggCount);
        tag.putInt("Squabs", this.squabCount);
        tag.putInt("CycleTicks", this.cycleTicks);
        if (this.maleData != null) tag.put("Male", this.maleData);
        if (this.femaleData != null) tag.put("Female", this.femaleData);
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.hasCopperBowl = tag.getBoolean("HasBowl");
        this.hasFeeder = tag.getBoolean("HasFeeder");
        this.m7FoodUnits = tag.getInt("M7Food");
        this.eggCount = tag.getInt("Eggs");
        this.squabCount = tag.getInt("Squabs");
        this.cycleTicks = tag.getInt("CycleTicks");
        this.maleData = tag.contains("Male") ? tag.getCompound("Male") : null;
        this.femaleData = tag.contains("Female") ? tag.getCompound("Female") : null;
    }
}
