package com.argon.loftpigeons.block;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.entity.BlockEntityTicker;
import net.minecraft.world.level.block.entity.BlockEntityType;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import org.jetbrains.annotations.Nullable;

/**
 * عش الطيور الكبير 3D (يتسع لطيرين ومربوط بخانة التزاوج الكوارتزية):
 * - إذا دخل طيران للعش يتزاوجان تلقائياً (وتظهر رسالة ERROR بالشات إذا حاول اللاعب مزاوجة ذكر بذكر ونسي فحصهما بالبطاقة).
 * - كلك يمين يفتح واجهة أزرار العش (رؤية ما بداخل العش، إخراج الفراخ، إخراج البيضة، وبناء خانة الكوارتز).
 */
public class CopperNestBowlBlock extends BaseEntityBlock {
    // حجم مكبر (من 1 إلى 15) ليتسع لطيرين معاً بوضوح
    private static final VoxelShape SHAPE = Block.box(1.0D, 0.0D, 1.0D, 15.0D, 5.8D, 15.0D);

    public CopperNestBowlBlock(Properties props) {
        super(props);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        BreedingBoxBlockEntity be = new BreedingBoxBlockEntity(pos, state);
        be.preEquipForLoft();
        return be;
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        super.entityInside(state, level, pos, entity);
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof BreedingBoxBlockEntity nest) {
            nest.tryAcceptWalkingPigeon(entity);
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof BreedingBoxBlockEntity nest) {
            if (!player.getItemInHand(hand).isEmpty()) {
                if (!level.isClientSide) {
                    return nest.handleRightClick(player, player.getItemInHand(hand), hand);
                }
                return InteractionResult.SUCCESS;
            } else {
                // يد فارغة -> فتح نافذة أزرار العش التفاعلية + إظهار الملخص
                if (level.isClientSide) {
                    DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ArgonLoftPigeonsMod.ClientModEvents.openNestControlScreen(pos));
                } else {
                    nest.executeButtonAction(player, 1);
                }
                return InteractionResult.SUCCESS;
            }
        }
        return InteractionResult.PASS;
    }

    @Nullable
    @Override
    public <T extends BlockEntity> BlockEntityTicker<T> getTicker(Level level, BlockState state, BlockEntityType<T> type) {
        return createTickerHelper(type, ArgonLoftPigeonsMod.BREEDING_BOX_ENTITY.get(), BreedingBoxBlockEntity::serverTick);
    }
}
