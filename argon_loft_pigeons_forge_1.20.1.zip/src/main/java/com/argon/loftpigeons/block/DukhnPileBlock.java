package com.argon.loftpigeons.block;

import net.minecraft.core.BlockPos;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

/**
 * جزيئات الدخن الثلاثية الأبعاد على الأرض (3D Dukhn Grain Particles):
 * ليست بلوكة مربعة، بل حبيبات دخن صغيرة متناثرة يراها الطير ويأتي ليأكلها!
 */
public class DukhnPileBlock extends Block {
    private static final VoxelShape SHAPE = Block.box(2.0D, 0.0D, 2.0D, 14.0D, 1.2D, 14.0D);

    public DukhnPileBlock(Properties props) {
        super(props);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }
}
