package com.argon.loftpigeons.block;

import net.minecraft.core.BlockPos;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraftforge.network.NetworkEvent;

import java.util.function.Supplier;

public class NestActionPacket {
    public final BlockPos pos;
    public final int actionId; // 1 = رؤية المحتوى، 2 = إخراج الفراخ، 3 = إخراج البيضة، 4 = إخراج الأبوين، 5 = بناء خانة الكوارتز حول العش

    public NestActionPacket(BlockPos pos, int actionId) {
        this.pos = pos;
        this.actionId = actionId;
    }

    public static void encode(NestActionPacket msg, FriendlyByteBuf buf) {
        buf.writeBlockPos(msg.pos);
        buf.writeInt(msg.actionId);
    }

    public static NestActionPacket decode(FriendlyByteBuf buf) {
        return new NestActionPacket(buf.readBlockPos(), buf.readInt());
    }

    public static void handle(NestActionPacket msg, Supplier<NetworkEvent.Context> ctxSupplier) {
        NetworkEvent.Context ctx = ctxSupplier.get();
        ctx.enqueueWork(() -> {
            ServerPlayer player = ctx.getSender();
            if (player == null) return;
            Level level = player.level();
            if (!level.isLoaded(msg.pos)) return;
            BlockEntity be = level.getBlockEntity(msg.pos);
            if (be instanceof BreedingBoxBlockEntity nest) {
                nest.executeButtonAction(player, msg.actionId);
            }
        });
        ctx.setPacketHandled(true);
    }
}
