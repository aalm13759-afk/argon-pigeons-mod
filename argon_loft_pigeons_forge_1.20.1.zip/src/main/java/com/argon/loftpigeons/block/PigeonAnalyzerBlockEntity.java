package com.argon.loftpigeons.block;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import com.argon.loftpigeons.item.CatchNetItem;
import com.argon.loftpigeons.item.RedDiagnosticCardItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.protocol.Packet;
import net.minecraft.network.protocol.game.ClientGamePacketListener;
import net.minecraft.network.protocol.game.ClientboundBlockEntityDataPacket;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import org.jetbrains.annotations.Nullable;

/**
 * الكيان البرمجي لبلوكة مجسم الطير (Pigeon Analyzer Block Entity):
 * يقرأ البطاقة الحمراء أو يأخذ الطير بداخله لدراسة حالته النفسية والجسدية ورغباته وهل يريد الطيران أم لا،
 * ويتيح للاعب عبر الأزرار:
 * 1) طباعة التقرير التفصيلي الكامل في الشاشة والشات
 * 2) تلبية رغبات الطير وعلاج حالته النفسية والجسدية (يرفع شبعه وصحته ونفسيته إلى 100%)
 * 3) إخراج الطير من البلوكة (أو إطلاقه للطيران مباشرة إذا كان يريد الطيران!)
 */
public class PigeonAnalyzerBlockEntity extends BlockEntity {
    private CompoundTag activeScanData = null;
    private boolean holdsPhysicalBird = false;

    public PigeonAnalyzerBlockEntity(BlockPos pos, BlockState state) {
        super(ArgonLoftPigeonsMod.PIGEON_ANALYZER_ENTITY.get(), pos, state);
    }

    public void syncToClient() {
        setChanged();
        if (this.level != null && !this.level.isClientSide) {
            BlockState st = getBlockState();
            this.level.sendBlockUpdated(this.worldPosition, st, st, 3);
        }
    }

    public void tryScanOrHoldWalkingPigeon(Entity entity) {
        if (!(entity instanceof ArgonPigeonEntity pigeon) || this.level == null || this.level.isClientSide) return;
        if (!pigeon.isAlive() || this.holdsPhysicalBird) return;

        this.activeScanData = RedDiagnosticCardItem.buildCompleteBioPsychProfile(pigeon);
        this.holdsPhysicalBird = true;
        pigeon.discard();
        this.level.playSound(null, this.worldPosition, SoundEvents.BEACON_ACTIVATE, SoundSource.BLOCKS, 0.8F, 1.4F);
        syncToClient();
    }

    public void handleInteraction(Player player, ItemStack stack, InteractionHand hand) {
        // 1. إذا ضغط اللاعب بالبطاقة الحمراء المسجل فيها معلومات طير -> تقرؤها البلوكة وتعرض كل شيء!
        if (stack.getItem() instanceof RedDiagnosticCardItem && RedDiagnosticCardItem.hasScannedPigeon(stack)) {
            this.activeScanData = stack.getTag().getCompound("BioScanData").copy();
            if (this.level != null) {
                this.level.playSound(null, this.worldPosition, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.BLOCKS, 1.0F, 1.2F);
            }
            syncToClient();
            printFullDiagnosticReportToChat(player);
            return;
        }

        // 2. إذا ضغط اللاعب بالشبكة وبداخلها طير -> تأخذ البلوكة الطير لدراسة حالته النفسية والجسدية مباشرة!
        if (stack.getItem() instanceof CatchNetItem && CatchNetItem.hasCapturedPigeon(stack) && !this.holdsPhysicalBird) {
            CompoundTag birdTag = stack.getTag().getCompound("CapturedPigeon").copy();
            if (this.level != null) {
                ArgonPigeonEntity temp = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(this.level);
                if (temp != null) {
                    temp.readAdditionalSaveData(birdTag);
                    this.activeScanData = RedDiagnosticCardItem.buildCompleteBioPsychProfile(temp);
                    this.holdsPhysicalBird = true;
                }
            }
            CatchNetItem.clearCapturedPigeon(stack);
            player.setItemInHand(hand, stack);
            player.inventoryMenu.broadcastChanges();
            syncToClient();
            player.sendSystemMessage(Component.literal("§a§l[بلوكة دراسة الطير] §fتم وضع الطير داخل مجسم الفحص لدراسة حالته النفسية والجسدية!"));
            printFullDiagnosticReportToChat(player);
            return;
        }

        // 3. إذا ضغط ببطاقة حمراء فارغة وكان هناك طير/بيانات في البلوكة -> ينسخ التقرير إلى البطاقة الحمراء!
        if (stack.getItem() instanceof RedDiagnosticCardItem && !RedDiagnosticCardItem.hasScannedPigeon(stack) && this.activeScanData != null) {
            stack.getOrCreateTag().put("BioScanData", this.activeScanData.copy());
            player.setItemInHand(hand, stack);
            player.inventoryMenu.broadcastChanges();
            player.sendSystemMessage(Component.literal("§c[البطاقة الحمراء] §fتم نسخ تقرير الفحص من البلوكة إلى البطاقة الحمراء!"));
            return;
        }

        if (this.activeScanData != null) {
            printFullDiagnosticReportToChat(player);
        } else {
            player.sendSystemMessage(Component.literal("§e[بلوكة مجسم الطير للفحص] §fاضغط بالبطاقة الحمراء على أي طير ثم ضعها هنا (أو أدخل الطير بالشبكة) لدراسة حالته النفسية والجسدية ورغباته وهل يريد الطيران أم لا!"));
        }
    }

    public void executeAnalyzerButton(Player player, int buttonId) {
        if (this.level == null || this.level.isClientSide) return;

        if (this.activeScanData == null) {
            player.sendSystemMessage(Component.literal("§c[بلوكة دراسة الطير] §fلا توجد بيانات طير حالياً! امسح طيراً بالبطاقة الحمراء أولاً ثم اضغط بها على البلوكة."));
            return;
        }

        switch (buttonId) {
            case 10 -> printFullDiagnosticReportToChat(player);
            case 11 -> {
                // تلبية رغبة الطير وتحسين حالته النفسية والجسدية إلى 100%
                this.activeScanData.putInt("TicksWithoutFood", 0);
                this.activeScanData.putString("PhysicalStatus", "§aممتازة 100% (تمت التغذية بالدخن والفيتامينات وفحص الريش بالكامل)");
                this.activeScanData.putString("PsychStatus", "§aمطمئن وسعيد جداً (تمت تهدئة الطير ورفع روحه المعنوية 100%)");
                this.activeScanData.putString("DesireStatus", "§aجميع رغباته ملباة ومستعد تماماً للتحليق أو التزاوج");
                int clipped = this.activeScanData.getInt("ClippedFeathers");
                if (clipped < 3) {
                    this.activeScanData.putString("WantsToFlyStatus", "§a§l[نعم! متشوق جداً للطيران] §fفي قمة نشاطه النفسي والجسدي ويريد التحليق الآن!");
                    this.activeScanData.putBoolean("CanAndWantsFly", true);
                }
                if (this.level instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.HEART, this.worldPosition.getX() + 0.5D, this.worldPosition.getY() + 1.1D, this.worldPosition.getZ() + 0.5D, 12, 0.3D, 0.3D, 0.3D, 0.02D);
                }
                this.level.playSound(null, this.worldPosition, SoundEvents.PLAYER_LEVELUP, SoundSource.BLOCKS, 0.9F, 1.3F);
                syncToClient();
                player.sendSystemMessage(Component.literal("§a§l[رعاية الطير الشاملة] §fتمت تلبية رغبات الطير ورفع حالته النفسية والجسدية إلى 100%!"));
            }
            case 12 -> {
                // إخراج الطير من البلوكة (وإطلاقه للطيران إذا كان يريد الطيران!)
                if (!this.holdsPhysicalBird) {
                    player.sendSystemMessage(Component.literal("§e[ملاحظة] §fهذه قراءة عبر البطاقة الحمراء (الطير نفسه موجود في البرج/السطح). يمكنك إدخال الطير نفسه بالشبكة لإخراجه أو تطييره من هنا!"));
                    return;
                }
                ArgonPigeonEntity pigeon = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(this.level);
                if (pigeon != null) {
                    pigeon.readAdditionalSaveData(this.activeScanData);
                    pigeon.feedM7();
                    pigeon.setPos(this.worldPosition.getX() + 0.5D, this.worldPosition.getY() + 1.1D, this.worldPosition.getZ() + 0.5D);
                    pigeon.tame(player);
                    this.level.addFreshEntity(pigeon);
                    if (this.activeScanData.getBoolean("CanAndWantsFly")) {
                        pigeon.launchPigeonFlight(player);
                        player.sendSystemMessage(Component.literal("§b§l[انطلاق الطير!] §fلأن الطير يريد الطيران، انطلق من فوق مجسم الطير مباشرة نحو السماء!"));
                    } else {
                        player.sendSystemMessage(Component.literal("§a[إخراج الطير] §fتم إخراج الطير من بلوكة الفحص بسلام."));
                    }
                }
                this.holdsPhysicalBird = false;
                syncToClient();
            }
        }
    }

    public void printFullDiagnosticReportToChat(Player player) {
        if (this.activeScanData == null) return;
        player.sendSystemMessage(Component.literal("§4§l============================================="));
        player.sendSystemMessage(Component.literal("§c§l   [تقرير بلوكة مجسم الطير والبطاقة الحمراء الشامل]"));
        player.sendSystemMessage(Component.literal("§f• §lالطير والسلالة: §e" + this.activeScanData.getString("SummaryTitle")));
        player.sendSystemMessage(Component.literal("§f• §lالجينات والقدرات: §b" + this.activeScanData.getString("StatsLine")));
        player.sendSystemMessage(Component.literal("§f• §lالحالة الجسدية: " + this.activeScanData.getString("PhysicalStatus")));
        player.sendSystemMessage(Component.literal("§f• §lالحالة النفسية: " + this.activeScanData.getString("PsychStatus")));
        player.sendSystemMessage(Component.literal("§f• §lرغبات الطير الآن: " + this.activeScanData.getString("DesireStatus")));
        player.sendSystemMessage(Component.literal("§f• §lهل يريد الطيران؟ " + this.activeScanData.getString("WantsToFlyStatus")));
        player.sendSystemMessage(Component.literal("§4§l============================================="));
    }

    public boolean hasScanData() { return this.activeScanData != null; }
    public String getTitleLine() { return hasScanData() ? this.activeScanData.getString("SummaryTitle") : "لا توجد بطاقة حمراء أو طير مفحوص حالياً"; }
    public String getStatsLine() { return hasScanData() ? this.activeScanData.getString("StatsLine") : "امسح أي طير بالبطاقة الحمراء ثم اضغط هنا"; }
    public String getPhysicalLine() { return hasScanData() ? this.activeScanData.getString("PhysicalStatus") : "-"; }
    public String getPsychLine() { return hasScanData() ? this.activeScanData.getString("PsychStatus") : "-"; }
    public String getDesireLine() { return hasScanData() ? this.activeScanData.getString("DesireStatus") : "-"; }
    public String getFlyLine() { return hasScanData() ? this.activeScanData.getString("WantsToFlyStatus") : "-"; }

    @Override
    public CompoundTag getUpdateTag() {
        CompoundTag tag = super.getUpdateTag();
        saveAdditional(tag);
        return tag;
    }

    @Nullable
    @Override
    public Packet<ClientGamePacketListener> getUpdatePacket() {
        return ClientboundBlockEntityDataPacket.create(this);
    }

    @Override
    protected void saveAdditional(CompoundTag tag) {
        super.saveAdditional(tag);
        tag.putBoolean("HoldsBird", this.holdsPhysicalBird);
        if (this.activeScanData != null) {
            tag.put("ActiveScan", this.activeScanData);
        }
    }

    @Override
    public void load(CompoundTag tag) {
        super.load(tag);
        this.holdsPhysicalBird = tag.getBoolean("HoldsBird");
        this.activeScanData = tag.contains("ActiveScan") ? tag.getCompound("ActiveScan") : null;
    }
}
