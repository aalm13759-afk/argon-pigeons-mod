package com.argon.loftpigeons.block;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import net.minecraft.core.BlockPos;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.BaseEntityBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.RenderShape;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import org.jetbrains.annotations.Nullable;

/**
 * بلوكة مجسم الطير 3D لدراسة الحالة النفسية والجسدية ورغبات الطير (Pigeon Analyzer Statue Block):
 * - شكلها على شكل طير ثلاثي الأبعاد يقف على قاعدة فحص ذكية.
 * - تستقبل البطاقة الحمراء (أو تستقبل الطير نفسه عبر الشبكة أو المشي عليها) وتظهر كل شيء عن حالته النفسية والجسدية ورغباته وهل يريد الطيران أم لا!
 */
public class PigeonAnalyzerStatueBlock extends BaseEntityBlock {
    private static final VoxelShape SHAPE = Block.box(1.5D, 0.0D, 1.5D, 14.5D, 15.8D, 14.5D);

    public PigeonAnalyzerStatueBlock(Properties props) {
        super(props);
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return SHAPE;
    }

    @Override
    public RenderShape getRenderShape(BlockState state) {
        return RenderShape.MODEL;
    }

    @Nullable
    @Override
    public BlockEntity newBlockEntity(BlockPos pos, BlockState state) {
        return new PigeonAnalyzerBlockEntity(pos, state);
    }

    @Override
    public void entityInside(BlockState state, Level level, BlockPos pos, Entity entity) {
        super.entityInside(state, level, pos, entity);
        if (!level.isClientSide && level.getBlockEntity(pos) instanceof PigeonAnalyzerBlockEntity analyzer) {
            analyzer.tryScanOrHoldWalkingPigeon(entity);
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        BlockEntity be = level.getBlockEntity(pos);
        if (be instanceof PigeonAnalyzerBlockEntity analyzer) {
            if (!level.isClientSide) {
                analyzer.handleInteraction(player, player.getItemInHand(hand), hand);
            } else {
                DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ArgonLoftPigeonsMod.ClientModEvents.openPigeonAnalyzerScreen(pos));
            }
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.PASS;
    }
}
