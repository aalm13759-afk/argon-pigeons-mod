package com.argon.loftpigeons.client;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class ArgonPigeonModel extends GeoModel<ArgonPigeonEntity> {
    @Override
    public ResourceLocation getModelResource(ArgonPigeonEntity entity) {
        int squabDay = entity.getSquabDay();
        if (squabDay == 1 || squabDay == 2) {
            return new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "geo/squab_stage_1.geo.json");
        } else if (squabDay >= 3 && squabDay <= 5) {
            return new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "geo/squab_stage_2.geo.json");
        }

        return switch (entity.getBreed()) {
            case ZAJIL -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "geo/zajil_homer.geo.json");
            case RED -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "geo/red_aghar.geo.json");
            case TEDDY, HYBRID_TEDDY_KADHMAWI, HYBRID_TEDDY_GOLDEN -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "geo/teddy_pakistani.geo.json");
            case KADHMAWI -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "geo/white_kadhmawi.geo.json");
            case GOLDEN, HYBRID_KADHMAWI_GOLDEN -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "geo/golden_prince.geo.json");
        };
    }

    @Override
    public ResourceLocation getTextureResource(ArgonPigeonEntity entity) {
        if (entity.getSquabDay() > 0 && entity.getSquabDay() <= 4) {
            return new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/squab_chick.png");
        }

        return switch (entity.getBreed()) {
            case ZAJIL -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/zajil_homer.png");
            case RED -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/red_aghar.png");
            case TEDDY -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/teddy_pakistani.png");
            case KADHMAWI -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/white_kadhmawi.png");
            case GOLDEN -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/golden_prince.png");
            case HYBRID_TEDDY_KADHMAWI -> {
                int v = entity.getHybridSkinVariant();
                if (v == 1) yield new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/white_kadhmawi.png");
                if (v == 2) yield new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/teddy_pakistani.png");
                yield new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/hybrid_teddy_kadhmawi.png");
            }
            case HYBRID_KADHMAWI_GOLDEN -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/hybrid_kadhmawi_golden.png");
            case HYBRID_TEDDY_GOLDEN -> (entity.getHybridSkinVariant() == 0)
                    ? new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/hybrid_teddy_golden_a.png")
                    : new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/hybrid_teddy_golden_b.png");
        };
    }

    @Override
    public ResourceLocation getAnimationResource(ArgonPigeonEntity entity) {
        return new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "animations/argon_loft_pigeon.animation.json");
    }
}
