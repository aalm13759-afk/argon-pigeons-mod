package com.argon.loftpigeons.client;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.model.HierarchicalModel;
import net.minecraft.client.model.geom.ModelLayerLocation;
import net.minecraft.client.model.geom.ModelPart;
import net.minecraft.client.model.geom.PartPose;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

public class ArgonPigeonModel extends HierarchicalModel<ArgonPigeonEntity> {
    public static final ModelLayerLocation LAYER_LOCATION =
            new ModelLayerLocation(new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "loft_pigeon"), "main");

    private final ModelPart root;
    private final ModelPart bodyTilt;
    private final ModelPart rootBody;
    private final ModelPart chest;
    private final ModelPart neck;
    private final ModelPart head;
    private final ModelPart beakUpper;
    private final ModelPart jawLower;
    private final ModelPart tailBase;

    private final ModelPart wingLInner, wingLMid, wingLTip;
    private final ModelPart wingRInner, wingRMid, wingRTip;
    private final ModelPart[] feathersL = new ModelPart[10];
    private final ModelPart[] feathersR = new ModelPart[10];

    private final ModelPart legLThigh, legLShank, legLFoot, legRing;
    private final ModelPart legRThigh, legRShank, legRFoot;

    public ArgonPigeonModel(ModelPart root) {
        this.root = root;
        this.bodyTilt = root.getChild("body_tilt");
        this.rootBody = this.bodyTilt.getChild("root_body");
        this.chest = this.rootBody.getChild("chest");
        this.neck = this.chest.getChild("neck");
        this.head = this.neck.getChild("head");
        this.beakUpper = this.head.getChild("beak_upper");
        this.jawLower = this.head.getChild("jaw_lower");
        this.tailBase = this.rootBody.getChild("tail_base");

        this.wingLInner = this.rootBody.getChild("wing_left_inner");
        this.wingLMid = this.wingLInner.getChild("wing_left_mid");
        this.wingLTip = this.wingLMid.getChild("wing_left_tip");

        this.wingRInner = this.rootBody.getChild("wing_right_inner");
        this.wingRMid = this.wingRInner.getChild("wing_right_mid");
        this.wingRTip = this.wingRMid.getChild("wing_right_tip");

        for (int i = 0; i < 10; i++) {
            this.feathersL[i] = this.wingLTip.getChild("feather_L_" + (i + 1));
            this.feathersR[i] = this.wingRTip.getChild("feather_R_" + (i + 1));
        }

        this.legLThigh = this.rootBody.getChild("leg_left_thigh");
        this.legLShank = this.legLThigh.getChild("leg_left_shank");
        this.legLFoot = this.legLShank.getChild("leg_left_foot");
        this.legRing = this.legLShank.getChild("leg_ring");

        this.legRThigh = this.rootBody.getChild("leg_right_thigh");
        this.legRShank = this.legRThigh.getChild("leg_right_shank");
        this.legRFoot = this.legRShank.getChild("leg_right_foot");
    }

    public static LayerDefinition createBodyLayer() {
        MeshDefinition mesh = new MeshDefinition();
        PartDefinition partRoot = mesh.getRoot();

        // 1. مفصل دوران الجسم لقلب الجناح (body_tilt)
        PartDefinition bodyTilt = partRoot.addOrReplaceChild("body_tilt", CubeListBuilder.create(), PartPose.offset(0.0F, 16.5F, 0.0F));

        // 2. الجسم الرئيسي (root_body)
        PartDefinition rootBody = bodyTilt.addOrReplaceChild("root_body",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-3.0F, -2.5F, -3.5F, 6.0F, 5.0F, 7.0F)
                        .texOffs(16, 0).addBox(-2.5F, 2.0F, -2.8F, 5.0F, 1.0F, 6.0F)
                        .texOffs(0, 0).addBox(-2.0F, -2.0F, 3.2F, 4.0F, 3.5F, 3.0F),
                PartPose.offset(0.0F, 0.0F, 0.0F));

        // 3. عضلة الصدر البارزة (chest)
        PartDefinition chest = rootBody.addOrReplaceChild("chest",
                CubeListBuilder.create()
                        .texOffs(32, 0).addBox(-3.2F, -2.6F, -2.6F, 6.4F, 5.2F, 3.2F)
                        .texOffs(32, 0).addBox(-2.6F, -2.1F, -3.3F, 5.2F, 4.2F, 1.0F),
                PartPose.offset(0.0F, 0.0F, -3.0F));

        // 4. الرقبة المنقوشة (neck)
        PartDefinition neck = chest.addOrReplaceChild("neck",
                CubeListBuilder.create()
                        .texOffs(48, 0).addBox(-2.2F, -4.2F, -1.6F, 4.4F, 4.4F, 3.4F),
                PartPose.offset(0.0F, -2.2F, -1.2F));

        // 5. الرأس مع العيون ثلاثية الأبعاد البارزة على الجانبين (head)
        PartDefinition head = neck.addOrReplaceChild("head",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-1.8F, -3.0F, -2.0F, 3.6F, 3.0F, 3.8F)
                        .texOffs(0, 0).addBox(-1.4F, -3.6F, -1.5F, 2.8F, 1.0F, 3.0F)
                        // جفن العين + القزحية + البؤبؤ الأسود (بارزة بوضوح على جانبي الرأس!)
                        .texOffs(0, 32).addBox(1.65F, -2.3F, -1.2F, 0.35F, 1.2F, 1.2F)
                        .texOffs(0, 32).addBox(-2.00F, -2.3F, -1.2F, 0.35F, 1.2F, 1.2F)
                        .texOffs(16, 32).addBox(1.75F, -2.1F, -1.0F, 0.35F, 0.8F, 0.8F)
                        .texOffs(16, 32).addBox(-2.10F, -2.1F, -1.0F, 0.35F, 0.8F, 0.8F),
                PartPose.offset(0.0F, -3.8F, 0.0F));

        // 6. المنقار العلوي وكير الأنف الأبيض (beak_upper) والفك السفلي (jaw_lower)
        head.addOrReplaceChild("beak_upper",
                CubeListBuilder.create()
                        .texOffs(40, 32).addBox(-0.8F, -0.8F, -1.0F, 1.6F, 0.8F, 1.0F)
                        .texOffs(32, 32).addBox(-0.6F, -0.4F, -2.6F, 1.2F, 0.7F, 2.2F),
                PartPose.offset(0.0F, -1.2F, -1.8F));

        head.addOrReplaceChild("jaw_lower",
                CubeListBuilder.create()
                        .texOffs(32, 32).addBox(-0.5F, 0.0F, -2.2F, 1.0F, 0.4F, 2.0F),
                PartPose.offset(0.0F, -0.8F, -1.8F));

        // 7. الذيل (tail_base)
        rootBody.addOrReplaceChild("tail_base",
                CubeListBuilder.create()
                        .texOffs(0, 0).addBox(-1.9F, -0.5F, 0.0F, 3.8F, 1.0F, 5.0F)
                        .texOffs(48, 16).addBox(-2.0F, -0.55F, 4.5F, 4.0F, 1.1F, 2.0F),
                PartPose.offset(0.0F, -0.8F, 5.5F));

        // 8. الجناح الأيسر والأيمن + الـ 10 ريشات القابلة للقص (feather_L_1..10 & feather_R_1..10)
        PartDefinition wingLInner = rootBody.addOrReplaceChild("wing_left_inner",
                CubeListBuilder.create()
                        .texOffs(0, 16).addBox(0.0F, -0.5F, -0.5F, 1.2F, 4.0F, 5.0F)
                        .texOffs(16, 16).addBox(0.05F, -0.4F, 3.2F, 1.2F, 3.8F, 1.0F),
                PartPose.offset(2.8F, -2.0F, -2.8F));

        PartDefinition wingLMid = wingLInner.addOrReplaceChild("wing_left_mid",
                CubeListBuilder.create()
                        .texOffs(0, 16).addBox(0.0F, -0.4F, 0.0F, 1.0F, 3.2F, 4.0F)
                        .texOffs(16, 16).addBox(0.05F, -0.3F, 2.4F, 1.0F, 3.0F, 1.0F),
                PartPose.offset(0.1F, 0.2F, 4.2F));

        PartDefinition wingLTip = wingLMid.addOrReplaceChild("wing_left_tip",
                CubeListBuilder.create(), PartPose.offset(0.0F, 0.2F, 3.6F));

        PartDefinition wingRInner = rootBody.addOrReplaceChild("wing_right_inner",
                CubeListBuilder.create()
                        .texOffs(0, 16).addBox(-1.2F, -0.5F, -0.5F, 1.2F, 4.0F, 5.0F)
                        .texOffs(16, 16).addBox(-1.25F, -0.4F, 3.2F, 1.2F, 3.8F, 1.0F),
                PartPose.offset(-2.8F, -2.0F, -2.8F));

        PartDefinition wingRMid = wingRInner.addOrReplaceChild("wing_right_mid",
                CubeListBuilder.create()
                        .texOffs(0, 16).addBox(-1.0F, -0.4F, 0.0F, 1.0F, 3.2F, 4.0F)
                        .texOffs(16, 16).addBox(-1.05F, -0.3F, 2.4F, 1.0F, 3.0F, 1.0F),
                PartPose.offset(-0.1F, 0.2F, 4.2F));

        PartDefinition wingRTip = wingRMid.addOrReplaceChild("wing_right_tip",
                CubeListBuilder.create(), PartPose.offset(0.0F, 0.2F, 3.6F));

        for (int i = 1; i <= 10; i++) {
            float yOff = (i - 1) * 0.22F;
            float zOff = (i - 1) * 0.28F;
            wingLTip.addOrReplaceChild("feather_L_" + i,
                    CubeListBuilder.create().texOffs(32, 16).addBox(0.0F, yOff, zOff, 0.7F, 0.6F, 4.0F),
                    PartPose.ZERO);
            wingRTip.addOrReplaceChild("feather_R_" + i,
                    CubeListBuilder.create().texOffs(32, 16).addBox(-0.7F, yOff, zOff, 0.7F, 0.6F, 4.0F),
                    PartPose.ZERO);
        }

        // 9. الأرجل وحلقة الرجل المخفية افتراضياً (leg_ring)
        PartDefinition legLThigh = rootBody.addOrReplaceChild("leg_left_thigh",
                CubeListBuilder.create().texOffs(16, 0).addBox(-0.7F, 0.0F, -0.8F, 1.4F, 2.5F, 1.6F),
                PartPose.offset(1.5F, 2.2F, 0.0F));

        PartDefinition legLShank = legLThigh.addOrReplaceChild("leg_left_shank",
                CubeListBuilder.create().texOffs(48, 32).addBox(-0.4F, 0.0F, -0.4F, 0.8F, 2.2F, 0.8F),
                PartPose.offset(0.0F, 2.4F, 0.0F));

        legLShank.addOrReplaceChild("leg_ring",
                CubeListBuilder.create().texOffs(0, 40).addBox(-0.6F, 0.9F, -0.6F, 1.2F, 0.7F, 1.2F),
                PartPose.ZERO);

        legLShank.addOrReplaceChild("leg_left_foot",
                CubeListBuilder.create().texOffs(48, 32).addBox(-0.8F, 0.0F, -1.8F, 1.6F, 0.4F, 2.4F),
                PartPose.offset(0.0F, 2.1F, 0.0F));

        PartDefinition legRThigh = rootBody.addOrReplaceChild("leg_right_thigh",
                CubeListBuilder.create().texOffs(16, 0).addBox(-0.7F, 0.0F, -0.8F, 1.4F, 2.5F, 1.6F),
                PartPose.offset(-1.5F, 2.2F, 0.0F));

        PartDefinition legRShank = legRThigh.addOrReplaceChild("leg_right_shank",
                CubeListBuilder.create().texOffs(48, 32).addBox(-0.4F, 0.0F, -0.4F, 0.8F, 2.2F, 0.8F),
                PartPose.offset(0.0F, 2.4F, 0.0F));

        legRShank.addOrReplaceChild("leg_right_foot",
                CubeListBuilder.create().texOffs(48, 32).addBox(-0.8F, 0.0F, -1.8F, 1.6F, 0.4F, 2.4F),
                PartPose.offset(0.0F, 2.1F, 0.0F));

        return LayerDefinition.create(mesh, 64, 64);
    }

    @Override
    public ModelPart root() {
        return this.root;
    }

    @Override
    public void setupAnim(ArgonPigeonEntity entity, float limbSwing, float limbSwingAmount, float ageInTicks, float netHeadYaw, float headPitch) {
        this.root().getAllParts().forEach(ModelPart::resetPose);

        // 1. إخفاء حلقة الرجل افتراضياً وإظهارها فقط عند إلباس الطير الحلقة
        this.legRing.visible = (entity.getLegRingColorIndex() >= 0);

        // 2. إخفاء ريشات الجناح المقصوصة بالمقص (1 إلى 10)
        int clipped = entity.getClippedFeathers();
        for (int i = 0; i < 10; i++) {
            boolean show = (i >= clipped);
            this.feathersL[i].visible = show;
            this.feathersR[i].visible = show;
        }

        ArgonPigeonEntity.AnimState st = entity.getAnimState();

        // وقفة السلالة الافتراضية
        this.rootBody.xRot = -0.42F;
        this.neck.xRot = 0.42F;
        this.legLThigh.xRot = 0.42F;
        this.legRThigh.xRot = 0.42F;

        if (st == ArgonPigeonEntity.AnimState.STARVE_DEATH) {
            this.bodyTilt.zRot = 1.52F;
            this.bodyTilt.y = 20.5F;
            return;
        }

        if (st == ArgonPigeonEntity.AnimState.INCUBATE_EGGS) {
            // وضعية الرقود على البيض داخل الفخار مع طي الأرجل
            this.rootBody.y = 2.8F;
            this.rootBody.xRot = -0.12F;
            this.legLThigh.xRot = 1.35F;
            this.legRThigh.xRot = 1.35F;
            return;
        }

        if (!entity.onGround()) {
            // حركات الطيران + ضم الأرجل للخلف تحت الذيل
            float flap = Mth.sin(ageInTicks * 0.85F);
            this.rootBody.xRot = (st == ArgonPigeonEntity.AnimState.FLIGHT_BAND_CLIMB) ? -0.38F : 0.14F;
            this.neck.xRot = -this.rootBody.xRot;

            // حركة قلب الجناح يميناً ويساراً (body_tilt) للزاجل والأحمر
            if (st == ArgonPigeonEntity.AnimState.FLIGHT_WING_FLIP) {
                this.bodyTilt.zRot = Mth.sin(ageInTicks * 0.22F) * 0.68F;
            }

            this.wingLInner.yRot = 1.25F;
            this.wingLInner.zRot = flap * 0.95F;
            this.wingLMid.zRot = Mth.sin(ageInTicks * 0.85F - 0.5F) * 0.55F;

            this.wingRInner.yRot = -1.25F;
            this.wingRInner.zRot = -flap * 0.95F;
            this.wingRMid.zRot = -Mth.sin(ageInTicks * 0.85F - 0.5F) * 0.55F;

            // طيّ الأرجل بالكامل للخلف تحت الذيل أثناء الطيران
            this.legLThigh.xRot = 1.35F;
            this.legLShank.xRot = 0.45F;
            this.legLFoot.xRot = 0.85F;
            this.legRThigh.xRot = 1.35F;
            this.legRShank.xRot = 0.45F;
            this.legRFoot.xRot = 0.85F;
        } else if (st == ArgonPigeonEntity.AnimState.EAT_M7 || st == ArgonPigeonEntity.AnimState.FEED_SQUAB_ZAQQ) {
            // حركة الأكل أو زقّ الفراخ مع فتح المنقار
            float peck = Mth.abs(Mth.sin(ageInTicks * 0.55F));
            this.rootBody.xRot = 0.35F;
            this.neck.xRot = 0.45F + peck * 0.55F;
            this.jawLower.xRot = peck * 0.40F;
            this.legLThigh.xRot = -0.35F;
            this.legRThigh.xRot = -0.35F;
        } else {
            // المشي على السطح والالتفات يميناً ويساراً وللأعلى لحفظ المعالم
            this.head.yRot = netHeadYaw * ((float) Math.PI / 180F) + Mth.sin(ageInTicks * 0.09F) * 0.25F;
            this.head.xRot = headPitch * ((float) Math.PI / 180F) - 0.15F + Mth.cos(ageInTicks * 0.07F) * 0.18F;
            this.legLThigh.xRot = 0.42F + Mth.cos(limbSwing * 0.6662F) * 1.2F * limbSwingAmount;
            this.legRThigh.xRot = 0.42F + Mth.cos(limbSwing * 0.6662F + (float) Math.PI) * 1.2F * limbSwingAmount;
        }
    }

    @Override
    public void renderToBuffer(PoseStack poseStack, VertexConsumer buffer, int packedLight, int packedOverlay,
                               float red, float green, float blue, float alpha) {
        this.root.render(poseStack, buffer, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
