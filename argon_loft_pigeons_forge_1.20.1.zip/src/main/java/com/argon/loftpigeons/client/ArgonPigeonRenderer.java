package com.argon.loftpigeons.client;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/**
 * العارض الثلاثي الأبعاد:
 * - يخفي عظمة `leg_ring` افتراضياً، ويظهرها فقط عند إلباس الطير الحلقة.
 * - يخفي الريشات المقصوصة بالمقص (`feather_L_1..N` و `feather_R_1..N`) برمجياً من الجناح!
 */
public class ArgonPigeonRenderer extends GeoEntityRenderer<ArgonPigeonEntity> {
    public ArgonPigeonRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new ArgonPigeonModel());
        this.shadowRadius = 0.28F;
    }

    @Override
    public void preRender(PoseStack poseStack, ArgonPigeonEntity animatable, BakedGeoModel model,
                          MultiBufferSource bufferSource, VertexConsumer buffer, boolean isReRender,
                          float partialTick, int packedLight, int packedOverlay,
                          float red, float green, float blue, float alpha) {
        // 1. إخفاء حلقة الرجل افتراضياً وإظهارها فقط إذا ألبسه اللاعب حلقة!
        model.getBone("leg_ring").ifPresent(ringBone -> {
            ringBone.setHidden(animatable.getLegRingColorIndex() < 0);
        });

        // 2. إخفاء عدد ريشات الجناح المقصوصة بالمقص (من 1 إلى 10)
        int clipped = animatable.getClippedFeathers();
        for (int i = 1; i <= 10; i++) {
            final boolean hide = (i <= clipped);
            model.getBone("feather_L_" + i).ifPresent(b -> b.setHidden(hide));
            model.getBone("feather_R_" + i).ifPresent(b -> b.setHidden(hide));
        }

        // 3. تصغير حجم الفرخ حديث الولادة (0.28x) ويكبر تدريجياً كل يوم حتى الريشة الأولى!
        int squabDay = animatable.getSquabDay();
        if (squabDay > 0) {
            float s = 0.28F + (squabDay * 0.12F);
            poseStack.scale(s, s, s);
        }

        super.preRender(poseStack, animatable, model, bufferSource, buffer, isReRender,
                partialTick, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
