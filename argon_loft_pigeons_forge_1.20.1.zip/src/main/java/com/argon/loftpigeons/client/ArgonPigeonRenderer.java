package com.argon.loftpigeons.client;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.MobRenderer;
import net.minecraft.resources.ResourceLocation;

public class ArgonPigeonRenderer extends MobRenderer<ArgonPigeonEntity, ArgonPigeonModel> {
    public ArgonPigeonRenderer(EntityRendererProvider.Context context) {
        super(context, new ArgonPigeonModel(context.bakeLayer(ArgonPigeonModel.LAYER_LOCATION)), 0.28F);
    }

    @Override
    protected void scale(ArgonPigeonEntity entity, PoseStack poseStack, float partialTickTime) {
        int squabDay = entity.getSquabDay();
        if (squabDay > 0) {
            // يكبر الفرخ تدريجياً كل يوم من اليوم 1 إلى اليوم 5
            float s = 0.35F + (squabDay * 0.12F);
            poseStack.scale(s, s, s);
        }
    }

    @Override
    public ResourceLocation getTextureLocation(ArgonPigeonEntity entity) {
        if (entity.getSquabDay() > 0 && entity.getSquabDay() <= 4) {
            return new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/squab_chick.png");
        }
        return switch (entity.getBreed()) {
            case ZAJIL -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/zajil_homer.png");
            case RED -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/red_aghar.png");
            case TEDDY -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/teddy_pakistani.png");
            case KADHMAWI -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/white_kadhmawi.png");
            case GOLDEN -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/golden_prince.png");
            case HYBRID_TEDDY_KADHMAWI -> {
                int v = entity.getHybridSkinVariant();
                if (v == 1) yield new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/white_kadhmawi.png");
                if (v == 2) yield new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/teddy_pakistani.png");
                yield new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/hybrid_teddy_kadhmawi.png");
            }
            case HYBRID_KADHMAWI_GOLDEN -> new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/hybrid_kadhmawi_golden.png");
            case HYBRID_TEDDY_GOLDEN -> (entity.getHybridSkinVariant() == 0)
                    ? new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/hybrid_teddy_golden_a.png")
                    : new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/hybrid_teddy_golden_b.png");
        };
    }
}
