package com.argon.loftpigeons.client;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.cache.object.BakedGeoModel;
import software.bernie.geckolib.cache.object.GeoBone;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

/**
 * العارض الثلاثي الأبعاد المطور:
 * 1. يلون عظمة حلقة الرجل 3D (leg_ring) بألوان الـ 20 حلقة بدقة عالية عند إلباسها للطير!
 * 2. يطبق مراحل النمو الـ 5: يكبر حجم وشكل الطير كل يوم على مدار 5 أيام ماينكرافتية!
 * 3. يخفي الريشات المقصوصة بالمقص من الجناح.
 */
public class ArgonPigeonRenderer extends GeoEntityRenderer<ArgonPigeonEntity> {

    private static final float[][] RING_RGB_PALETTE = {
        {0.86F, 0.15F, 0.15F}, // 0: أحمر
        {0.93F, 0.28F, 0.60F}, // 1: وردي
        {0.98F, 0.45F, 0.09F}, // 2: برتقالي
        {0.92F, 0.70F, 0.03F}, // 3: أصفر
        {0.52F, 0.80F, 0.09F}, // 4: ليموني فسفوري
        {0.09F, 0.64F, 0.29F}, // 5: أخضر
        {0.06F, 0.73F, 0.51F}, // 6: زمردي
        {0.02F, 0.71F, 0.83F}, // 7: سماوي
        {0.22F, 0.74F, 0.97F}, // 8: أزرق فاتح
        {0.15F, 0.39F, 0.92F}, // 9: أزرق
        {0.12F, 0.16F, 0.35F}, // 10: كحلي
        {0.58F, 0.20F, 0.92F}, // 11: بنفسجي
        {0.85F, 0.27F, 0.94F}, // 12: أرجواني
        {0.49F, 0.23F, 0.93F}, // 13: نيلي
        {0.98F, 0.98F, 0.99F}, // 14: أبيض
        {0.75F, 0.80F, 0.86F}, // 15: فضي
        {0.45F, 0.52F, 0.60F}, // 16: رمادي
        {0.12F, 0.12F, 0.15F}, // 17: أسود
        {0.96F, 0.62F, 0.04F}, // 18: ذهبي
        {0.71F, 0.33F, 0.04F}  // 19: برونزي
    };

    public ArgonPigeonRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new ArgonPigeonModel());
        this.shadowRadius = 0.28F;
    }

    @Override
    public void preRender(PoseStack poseStack, ArgonPigeonEntity animatable, BakedGeoModel model,
                          MultiBufferSource bufferSource, VertexConsumer buffer, boolean isReRender,
                          float partialTick, int packedLight, int packedOverlay,
                          float red, float green, float blue, float alpha) {
        // 1. إظهار حلقة الرجل 3D فقط عندما يلبسها الطير (0..19)
        model.getBone("leg_ring").ifPresent(ringBone -> {
            ringBone.setHidden(animatable.getLegRingColorIndex() < 0);
        });

        // 2. إخفاء الريشات المقصوصة بالمقص (1..10)
        int clipped = animatable.getClippedFeathers();
        for (int i = 1; i <= 10; i++) {
            final boolean hide = (i <= clipped);
            model.getBone("feather_L_" + i).ifPresent(b -> b.setHidden(hide));
            model.getBone("feather_R_" + i).ifPresent(b -> b.setHidden(hide));
        }

        // 3. تدرج حجم الطير كل يوم على مدار 5 أيام ماينكرافتية (اليوم 1 -> 2 -> 3 -> 4 -> 5 -> بالغ)
        int squabDay = animatable.getSquabDay();
        if (squabDay > 0) {
            float scale = switch (squabDay) {
                case 1 -> 0.30F;
                case 2 -> 0.45F;
                case 3 -> 0.62F;
                case 4 -> 0.78F;
                default -> 0.92F;
            };
            poseStack.scale(scale, scale, scale);
        }

        super.preRender(poseStack, animatable, model, bufferSource, buffer, isReRender,
                partialTick, packedLight, packedOverlay, red, green, blue, alpha);
    }

    @Override
    public void renderRecursively(PoseStack poseStack, ArgonPigeonEntity animatable, GeoBone bone,
                                  RenderType renderType, MultiBufferSource bufferSource, VertexConsumer buffer,
                                  boolean isReRender, float partialTick, int packedLight, int packedOverlay,
                                  float red, float green, float blue, float alpha) {
        if ("leg_ring".equals(bone.getName())) {
            int idx = animatable.getLegRingColorIndex();
            if (idx >= 0 && idx < RING_RGB_PALETTE.length) {
                float[] rgb = RING_RGB_PALETTE[idx];
                super.renderRecursively(poseStack, animatable, bone, renderType, bufferSource, buffer,
                        isReRender, partialTick, packedLight, packedOverlay, rgb[0], rgb[1], rgb[2], alpha);
                return;
            }
        }
        super.renderRecursively(poseStack, animatable, bone, renderType, bufferSource, buffer,
                isReRender, partialTick, packedLight, packedOverlay, red, green, blue, alpha);
    }
}
