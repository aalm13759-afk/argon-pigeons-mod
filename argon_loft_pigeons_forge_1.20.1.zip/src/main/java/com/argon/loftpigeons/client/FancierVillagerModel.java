package com.argon.loftpigeons.client;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.FancierVillagerEntity;
import net.minecraft.resources.ResourceLocation;
import software.bernie.geckolib.model.GeoModel;

public class FancierVillagerModel extends GeoModel<FancierVillagerEntity> {
    @Override
    public ResourceLocation getModelResource(FancierVillagerEntity entity) {
        return new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "geo/fancier_villager.geo.json");
    }

    @Override
    public ResourceLocation getTextureResource(FancierVillagerEntity entity) {
        return new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "textures/entity/fancier_villager.png");
    }

    @Override
    public ResourceLocation getAnimationResource(FancierVillagerEntity entity) {
        return new ResourceLocation(ArgonLoftPigeonsMod.MOD_ID, "animations/fancier_villager.animation.json");
    }
}
