package com.argon.loftpigeons.client;

import com.argon.loftpigeons.entity.FancierVillagerEntity;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import software.bernie.geckolib.renderer.GeoEntityRenderer;

public class FancierVillagerRenderer extends GeoEntityRenderer<FancierVillagerEntity> {
    public FancierVillagerRenderer(EntityRendererProvider.Context renderManager) {
        super(renderManager, new FancierVillagerModel());
        this.shadowRadius = 0.5F;
    }
}
