package com.argon.loftpigeons.client;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.block.BreedingBoxBlockEntity;
import com.argon.loftpigeons.block.NestActionPacket;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * واجهة التحكم بالعش وخانة التزاوج الكوارتزية (تحتوي على الأزرار التي طلبها اللاعب):
 * 1- زر رؤية ما بداخل العش بالتفصيل
 * 2- زر إخراج الفراخ إذا فقسوا وكبروا من العش
 * 3- زر إخراج البيضة من العش (لتفقس وتنكسر على الأرض)
 * 4- زر بناء/ربط خانة الكوارتز الماينكرافتية حول العش أو إخراج الأبوين
 */
public class NestControlScreen extends Screen {
    private final BlockPos nestPos;
    private String statusLine1 = "";
    private String statusLine2 = "";
    private String statusLine3 = "";

    public NestControlScreen(BlockPos nestPos) {
        super(Component.literal("واجهة عش الطيور وخانة التزاوج الكوارتزية"));
        this.nestPos = nestPos;
    }

    @Override
    protected void init() {
        super.init();
        refreshLocalSummary();

        int centerX = this.width / 2;
        int startY = this.height / 2 - 42;

        // الزر 1: يرى اللاعب ما بداخل العش
        this.addRenderableWidget(Button.builder(
                Component.literal("§b[1] فحص ورؤية ما بداخل العش بالتفصيل"),
                btn -> {
                    ArgonLoftPigeonsMod.NETWORK.sendToServer(new NestActionPacket(this.nestPos, 1));
                    refreshLocalSummary();
                }
        ).bounds(centerX - 115, startY, 230, 22).build());

        // الزر 2: الفراخ إذا كبروا وفقسوا يخرجهم اللاعب من العش
        this.addRenderableWidget(Button.builder(
                Component.literal("§a[2] إخراج الفراخ من العش (بعد الفقس)"),
                btn -> {
                    ArgonLoftPigeonsMod.NETWORK.sendToServer(new NestActionPacket(this.nestPos, 2));
                    this.onClose();
                }
        ).bounds(centerX - 115, startY + 26, 230, 22).build());

        // الزر 3: إخراج البيضة من العش (عند وضعها بالأرض تفقس وتنكسر وحدها)
        this.addRenderableWidget(Button.builder(
                Component.literal("§e[3] إخراج البيضة من العش إلى يدك"),
                btn -> {
                    ArgonLoftPigeonsMod.NETWORK.sendToServer(new NestActionPacket(this.nestPos, 3));
                    this.onClose();
                }
        ).bounds(centerX - 115, startY + 52, 230, 22).build());

        // الزر 4: بناء خانة التزاوج ببلوكات الكوارتز المربوطة بالعش
        this.addRenderableWidget(Button.builder(
                Component.literal("§f[4] ربط وبناء خانة كوارتز حول العش"),
                btn -> {
                    ArgonLoftPigeonsMod.NETWORK.sendToServer(new NestActionPacket(this.nestPos, 5));
                    this.onClose();
                }
        ).bounds(centerX - 115, startY + 78, 112, 22).build());

        // الزر 5: إخراج الأبوين من العش
        this.addRenderableWidget(Button.builder(
                Component.literal("§6[5] إخراج الأبوين"),
                btn -> {
                    ArgonLoftPigeonsMod.NETWORK.sendToServer(new NestActionPacket(this.nestPos, 4));
                    this.onClose();
                }
        ).bounds(centerX + 3, startY + 78, 112, 22).build());
    }

    private void refreshLocalSummary() {
        if (Minecraft.getInstance().level == null) return;
        BlockEntity be = Minecraft.getInstance().level.getBlockEntity(this.nestPos);
        if (be instanceof BreedingBoxBlockEntity box) {
            this.statusLine1 = box.getGuiLine1();
            this.statusLine2 = box.getGuiLine2();
            this.statusLine3 = box.getGuiLine3();
        }
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);
        refreshLocalSummary();

        int centerX = this.width / 2;
        int boxTop = this.height / 2 - 102;
        graphics.fill(centerX - 130, boxTop, centerX + 130, boxTop + 215, 0xDD0F172A);
        graphics.renderOutline(centerX - 130, boxTop, 260, 215, 0xFF38BDF8);

        graphics.drawCenteredString(this.font, "§3§lعش التزاوج الكبير وخانة الكوارتز", centerX, boxTop + 8, 0xFFFFFF);
        graphics.drawCenteredString(this.font, this.statusLine1, centerX, boxTop + 24, 0xE2E8F0);
        graphics.drawCenteredString(this.font, this.statusLine2, centerX, boxTop + 36, 0xFDE68A);
        graphics.drawCenteredString(this.font, this.statusLine3, centerX, boxTop + 48, 0x86EFAC);

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
