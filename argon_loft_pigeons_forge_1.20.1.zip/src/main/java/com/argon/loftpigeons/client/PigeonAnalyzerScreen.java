package com.argon.loftpigeons.client;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.block.NestActionPacket;
import com.argon.loftpigeons.block.PigeonAnalyzerBlockEntity;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.level.block.entity.BlockEntity;

/**
 * شاشة بلوكة مجسم الطير والبطاقة الحمراء (Pigeon Analyzer Screen):
 * تعرض بشكل بصري كامل:
 * - السلالة والجنس والذكاء والحدة
 * - الحالة الجسدية (الصحة، شبع الحوصلة، الريش)
 * - الحالة النفسية (الاطمئنان، حفظ السطح، المزاج)
 * - رغبات الطير الحالية
 * - قرار الطيران: هل يريد الطيران أم لا ولماذا؟
 */
public class PigeonAnalyzerScreen extends Screen {
    private final BlockPos blockPos;

    public PigeonAnalyzerScreen(BlockPos pos) {
        super(Component.literal("مختبر ومجسم دراسة حالة الطير النفسية والجسدية"));
        this.blockPos = pos;
    }

    @Override
    protected void init() {
        super.init();
        int cx = this.width / 2;
        int btnY = this.height / 2 + 52;

        // زر 1: طباعة التقرير الكامل في الشات
        this.addRenderableWidget(Button.builder(
                Component.literal("§c[1] طباعة التقرير الكامل بالشات"),
                b -> ArgonLoftPigeonsMod.NETWORK.sendToServer(new NestActionPacket(this.blockPos, 10))
        ).bounds(cx - 145, btnY, 142, 22).build());

        // زر 2: تلبية رغبات الطير ورفع حالته النفسية والجسدية 100%
        this.addRenderableWidget(Button.builder(
                Component.literal("§a[2] تلبية رغبته وعلاج نفسيته 100%"),
                b -> ArgonLoftPigeonsMod.NETWORK.sendToServer(new NestActionPacket(this.blockPos, 11))
        ).bounds(cx + 3, btnY, 142, 22).build());

        // زر 3: إخراج الطير / إطلاقه للطيران إذا كان يريد الطيران
        this.addRenderableWidget(Button.builder(
                Component.literal("§b[3] إخراج الطير من المجسم / إطلاقه للطيران إذا كان راغباً"),
                b -> {
                    ArgonLoftPigeonsMod.NETWORK.sendToServer(new NestActionPacket(this.blockPos, 12));
                    this.onClose();
                }
        ).bounds(cx - 145, btnY + 26, 290, 22).build());
    }

    @Override
    public void render(GuiGraphics graphics, int mouseX, int mouseY, float partialTick) {
        this.renderBackground(graphics);

        int cx = this.width / 2;
        int top = this.height / 2 - 110;

        graphics.fill(cx - 155, top, cx + 155, top + 220, 0xE6111827);
        graphics.renderOutline(cx - 155, top, 310, 220, 0xFFEF4444);
        graphics.renderOutline(cx - 153, top + 2, 306, 216, 0xFFF59E0B);

        graphics.drawCenteredString(this.font, "§c§l[ بلوكة مجسم الطير - قارئ البطاقة الحمراء الشامل ]", cx, top + 8, 0xFFFFFF);

        if (Minecraft.getInstance().level != null) {
            BlockEntity be = Minecraft.getInstance().level.getBlockEntity(this.blockPos);
            if (be instanceof PigeonAnalyzerBlockEntity analyzer) {
                graphics.drawCenteredString(this.font, "§e" + analyzer.getTitleLine(), cx, top + 26, 0xFDE68A);
                graphics.drawCenteredString(this.font, "§b" + analyzer.getStatsLine(), cx, top + 40, 0x93C5FD);

                graphics.drawString(this.font, "§f• الحالة الجسدية: " + analyzer.getPhysicalLine(), cx - 145, top + 62, 0xE2E8F0);
                graphics.drawString(this.font, "§f• الحالة النفسية: " + analyzer.getPsychLine(), cx - 145, top + 82, 0xE2E8F0);
                graphics.drawString(this.font, "§f• رغبات الطير: " + analyzer.getDesireLine(), cx - 145, top + 102, 0xE2E8F0);
                graphics.drawString(this.font, "§f• هل يريد الطيران؟ " + analyzer.getFlyLine(), cx - 145, top + 124, 0xFFFFFF);
            }
        }

        super.render(graphics, mouseX, mouseY, partialTick);
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }
}
