package com.argon.loftpigeons.entity;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ai.ForageGrainGoal;
import com.argon.loftpigeons.entity.ai.GoldenPrinceHighflyerGoal;
import com.argon.loftpigeons.entity.ai.RedFlockExploreGoal;
import com.argon.loftpigeons.entity.ai.ZajilHomingRaceGoal;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.animal.FlyingAnimal;
import net.minecraft.world.entity.animal.ShoulderRidingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;

public class ArgonPigeonEntity extends ShoulderRidingEntity implements GeoEntity, FlyingAnimal {

    public enum Breed {
        GOLDEN_PRINCE("golden_prince", "الكولدن برنس (Golden Prince)"),
        RED_AGHAR("red_aghar", "الأحمر الأغر المسرول (Red Aghar)"),
        ZAJIL_HOMER("zajil_homer", "الزاجل الرياضي (Zajil Racing Homer)");

        public final String id;
        public final String arabicName;

        Breed(String id, String arabicName) {
            this.id = id;
            this.arabicName = arabicName;
        }

        public static Breed fromId(String id) {
            for (Breed b : values()) {
                if (b.id.equalsIgnoreCase(id)) return b;
            }
            return GOLDEN_PRINCE;
        }
    }

    public enum FlightPhase {
        GROUND_IDLE,
        EATING_GRAIN,
        WARMUP_CIRCLES,
        ZAJIL_LOW_SPRINT,
        RED_FLock_EXPLORING,
        GOLDEN_SPIRAL_CLIMB,
        GOLDEN_CLOUD_VANISH,
        DESCENDING_TO_OWNER,
        POST_FLIGHT_PANTING
    }

    private static final EntityDataAccessor<String> DATA_BREED =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> DATA_PHASE =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<BlockPos> DATA_HOME_LOFT =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.BLOCK_POS);
    private static final EntityDataAccessor<Integer> DATA_FLIGHT_TICKS =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT);

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);
    private int eatingTimer = 0;
    private int pantingTimer = 0;
    private boolean launchedByOwner = false;
    private boolean breedAssigned = false;
    public Vec3 exploreWaypointShared = null;

    public ArgonPigeonEntity(EntityType<? extends ShoulderRidingEntity> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 20, false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return ShoulderRidingEntity.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 14.0D)
                .add(Attributes.FLYING_SPEED, 1.15D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 256.0D);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
        nav.setCanOpenDoors(false);
        nav.setCanFloat(true);
        nav.setCanPassDoors(true);
        return nav;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_BREED, Breed.GOLDEN_PRINCE.id);
        this.entityData.define(DATA_PHASE, FlightPhase.GROUND_IDLE.name());
        this.entityData.define(DATA_HOME_LOFT, BlockPos.ZERO);
        this.entityData.define(DATA_FLIGHT_TICKS, 0);
    }

    @Nullable
    @Override
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData spawnData, @Nullable CompoundTag dataTag) {
        if (!this.breedAssigned) {
            Breed[] all = Breed.values();
            this.setBreed(all[this.random.nextInt(all.length)]);
        }
        return super.finalizeSpawn(level, difficulty, reason, spawnData, dataTag);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new ZajilHomingRaceGoal(this));
        this.goalSelector.addGoal(2, new RedFlockExploreGoal(this));
        this.goalSelector.addGoal(3, new GoldenPrinceHighflyerGoal(this));
        this.goalSelector.addGoal(4, new ForageGrainGoal(this));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 1.0D));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0F));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
    }

    @Override
    public void tick() {
        super.tick();

        if (!this.level().isClientSide) {
            if (this.eatingTimer > 0) {
                this.eatingTimer--;
                if (this.eatingTimer == 0 && this.getPhase() == FlightPhase.EATING_GRAIN) {
                    this.setPhase(FlightPhase.GROUND_IDLE);
                }
            }
            if (this.pantingTimer > 0) {
                this.pantingTimer--;
                if (this.pantingTimer == 0 && this.getPhase() == FlightPhase.POST_FLIGHT_PANTING) {
                    this.setPhase(FlightPhase.GROUND_IDLE);
                }
            }
            if (!this.onGround()) {
                this.setFlightTicks(this.getFlightTicks() + 1);
            }
        }
    }

    public void launchFlight(@Nullable Player owner) {
        if (owner != null) {
            if (!this.isTame()) {
                this.tame(owner);
            }
            if (this.getHomeLoft().equals(BlockPos.ZERO)) {
                this.setHomeLoft(owner.blockPosition());
            }
        }
        this.launchedByOwner = true;
        this.setFlightTicks(0);
        this.setPhase(FlightPhase.WARMUP_CIRCLES);

        List<ArgonPigeonEntity> nearbyFlock = this.level().getEntitiesOfClass(
                ArgonPigeonEntity.class,
                this.getBoundingBox().inflate(14.0D),
                p -> p != this && p.getBreed() == this.getBreed() && p.onGround()
        );
        for (ArgonPigeonEntity mate : nearbyFlock) {
            mate.launchedByOwner = true;
            mate.setFlightTicks(0);
            mate.setPhase(FlightPhase.WARMUP_CIRCLES);
            if (mate.getHomeLoft().equals(BlockPos.ZERO)) {
                mate.setHomeLoft(this.getHomeLoft());
            }
        }
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        if (stack.is(Items.WHEAT_SEEDS) || stack.is(Items.BEETROOT_SEEDS) || stack.is(Items.WHEAT)) {
            if (!this.level().isClientSide) {
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                if (!this.isTame()) {
                    this.tame(player);
                }
                this.setHomeLoft(this.blockPosition());
                this.eatingTimer = 60;
                this.pantingTimer = 0;
                this.setPhase(FlightPhase.EATING_GRAIN);
                this.heal(4.0F);
                player.displayClientMessage(Component.literal("§a[لوفت Argon] §fتم إطعام " + this.getBreed().arabicName + " وتثبيت اللوفت عند: " + this.getHomeLoft().toShortString()), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        if (stack.isEmpty() && player.isShiftKeyDown()) {
            if (!this.level().isClientSide) {
                Breed next = switch (this.getBreed()) {
                    case GOLDEN_PRINCE -> Breed.RED_AGHAR;
                    case RED_AGHAR -> Breed.ZAJIL_HOMER;
                    case ZAJIL_HOMER -> Breed.GOLDEN_PRINCE;
                };
                this.setBreed(next);
                player.displayClientMessage(Component.literal("§e[تغيير السلالة] §fالسلالة الحالية: " + next.arabicName), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        return super.mobInteract(player, hand);
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "argon_pigeon_controller", 3, state -> {
            FlightPhase phase = this.getPhase();
            if (!this.onGround()) {
                if (phase == FlightPhase.DESCENDING_TO_OWNER) {
                    return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.landing_fan_tail"));
                }
                if (phase == FlightPhase.GOLDEN_CLOUD_VANISH || phase == FlightPhase.GOLDEN_SPIRAL_CLIMB) {
                    return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.highflyer_sky_hover"));
                }
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.flight_flap"));
            }
            if (phase == FlightPhase.EATING_GRAIN) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.eat"));
            }
            if (phase == FlightPhase.POST_FLIGHT_PANTING) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.panting_rest"));
            }
            if (state.isMoving()) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.walk"));
            }
            return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.proud_idle"));
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    public boolean isFlying() {
        return !this.onGround();
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    public Breed getBreed() {
        return Breed.fromId(this.entityData.get(DATA_BREED));
    }

    public void setBreed(Breed breed) {
        this.breedAssigned = true;
        this.entityData.set(DATA_BREED, breed.id);
    }

    public FlightPhase getPhase() {
        try {
            return FlightPhase.valueOf(this.entityData.get(DATA_PHASE));
        } catch (IllegalArgumentException e) {
            return FlightPhase.GROUND_IDLE;
        }
    }

    public void setPhase(FlightPhase phase) {
        this.entityData.set(DATA_PHASE, phase.name());
    }

    public BlockPos getHomeLoft() {
        return this.entityData.get(DATA_HOME_LOFT);
    }

    public void setHomeLoft(BlockPos pos) {
        this.entityData.set(DATA_HOME_LOFT, pos);
    }

    public int getFlightTicks() {
        return this.entityData.get(DATA_FLIGHT_TICKS);
    }

    public void setFlightTicks(int ticks) {
        this.entityData.set(DATA_FLIGHT_TICKS, ticks);
    }

    public boolean isLaunchedByOwner() {
        return this.launchedByOwner;
    }

    public void setLaunchedByOwner(boolean launched) {
        this.launchedByOwner = launched;
    }

    public void startPostFlightPanting(int ticks) {
        this.pantingTimer = ticks;
        this.setPhase(FlightPhase.POST_FLIGHT_PANTING);
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob mate) {
        ArgonPigeonEntity child = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(level);
        if (child != null && mate instanceof ArgonPigeonEntity other) {
            child.setBreed(this.random.nextBoolean() ? this.getBreed() : other.getBreed());
            child.setHomeLoft(this.getHomeLoft());
            if (this.getOwnerUUID() != null) {
                child.setOwnerUUID(this.getOwnerUUID());
                child.setTame(true);
            }
        }
        return child;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("Breed", this.getBreed().id);
        tag.putBoolean("BreedAssigned", this.breedAssigned);
        tag.putString("FlightPhase", this.getPhase().name());
        tag.putInt("HomeX", this.getHomeLoft().getX());
        tag.putInt("HomeY", this.getHomeLoft().getY());
        tag.putInt("HomeZ", this.getHomeLoft().getZ());
        tag.putInt("FlightTicks", this.getFlightTicks());
        tag.putBoolean("LaunchedByOwner", this.launchedByOwner);
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Breed")) this.setBreed(Breed.fromId(tag.getString("Breed")));
        if (tag.contains("BreedAssigned")) this.breedAssigned = tag.getBoolean("BreedAssigned");
        if (tag.contains("FlightPhase")) this.setPhase(FlightPhase.valueOf(tag.getString("FlightPhase")));
        if (tag.contains("HomeX")) {
            this.setHomeLoft(new BlockPos(tag.getInt("HomeX"), tag.getInt("HomeY"), tag.getInt("HomeZ")));
        }
        this.setFlightTicks(tag.getInt("FlightTicks"));
        this.launchedByOwner = tag.getBoolean("LaunchedByOwner");
    }
}
