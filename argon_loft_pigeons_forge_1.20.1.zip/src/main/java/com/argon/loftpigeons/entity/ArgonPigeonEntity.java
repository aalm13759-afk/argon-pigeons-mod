package com.argon.loftpigeons.entity;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ai.EatDukhnGoal;
import com.argon.loftpigeons.entity.ai.LoftIndoorLifeGoal;
import com.argon.loftpigeons.entity.ai.PigeonMasterFlightGoal;
import com.argon.loftpigeons.entity.ai.RoofExploreAndMemorizeGoal;
import com.argon.loftpigeons.item.CatchNetItem;
import com.argon.loftpigeons.item.CertificateItem;
import com.argon.loftpigeons.item.ColoredLegRingItem;
import com.argon.loftpigeons.item.PigeonScissorsItem;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.animal.FlyingAnimal;
import net.minecraft.world.entity.animal.ShoulderRidingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;

public class ArgonPigeonEntity extends ShoulderRidingEntity implements GeoEntity, FlyingAnimal {

    public enum Breed {
        ZAJIL("zajil", "الزاجل (Zajil)"),
        RED("red", "الأحمر (Red)"),
        TEDDY("teddy", "التيدي (Teddy)"),
        KADHMAWI("kadhmawi", "الأبيض الكظماوي (White Kadhmawi)"),
        GOLDEN("golden", "الكولدن (Golden)"),
        HYBRID_TEDDY_KADHMAWI("hybrid_teddy_kadhmawi", "هجين: تيدي × كظماوي"),
        HYBRID_KADHMAWI_GOLDEN("hybrid_kadhmawi_golden", "هجين: كظماوي × كولدن"),
        HYBRID_TEDDY_GOLDEN("hybrid_teddy_golden", "هجين: تيدي × كولدن");

        public final String id;
        public final String arabicName;

        Breed(String id, String arabicName) {
            this.id = id;
            this.arabicName = arabicName;
        }

        public static Breed fromId(String id) {
            for (Breed b : values()) {
                if (b.id.equalsIgnoreCase(id)) return b;
            }
            return ZAJIL;
        }

        public boolean hasLimitStat() {
            return this == TEDDY || this == GOLDEN || this == HYBRID_TEDDY_GOLDEN || this == HYBRID_TEDDY_KADHMAWI || this == HYBRID_KADHMAWI_GOLDEN;
        }
    }

    public enum AnimState {
        IDLE,
        ROOF_EXPLORE,
        FLIGHT_NORMAL,
        FLIGHT_WING_FLIP,
        FLIGHT_BAND_CLIMB,
        THERMAL_GLIDE,
        SPIRAL_DIVE,
        LANDING_FAN_TAIL,
        EAT_M7,
        COURTSHIP_COO,
        PREEN_FEATHERS,
        FEED_SQUAB_ZAQQ,
        INCUBATE_EGGS,
        STARVE_DEATH
    }

    // أسماء الـ 20 ميكانيكية طيران متغيرة يومياً للأحمر والزاجل
    public static final String[] RED_ZAJIL_20_MECHANICS = {
        "1. الدوامة التصاعدية الكلاسيكية (15->40 بلوكة مع تعلية تدريجية)",
        "2. الطوق الضيق السريع ثم التوسع المفاجئ (Tight Ring -> Wide Burst)",
        "3. الدوران المزدوج المتقاطع (Figure-8 Dual Thermal Loops)",
        "4. السهم الخطي مع قلب الجناح المزدوج (Linear Sweep + Wing-Flip)",
        "5. الصعود اللولبي العكسي (Counter-Clockwise Thermal Spiral)",
        "6. الغطسة الهوائية ثم التعلية الشاهقة (Air-Pocket Dive & Climb)",
        "7. الحوم العالي الثابت فوق التيارات (High-Altitude Static Gliding)",
        "8. المراوغة الجانبية المتزامنة للطائف (Synchronized Flock Weave)",
        "9. الاستطلاع البعيد والرجوع الخاطف (Long-Range Recon & Dash)",
        "10. الدوائر المتداخلة الثلاثية (Triple Cloverleaf Orbit)",
        "11. خفقان الجناح السريع المتقطع مع الانزلاق (Burst-Flap & Coast)",
        "12. طيران المطاردة والالتفاف الحاد (High-Speed Banking Turn)",
        "13. التعلية العمودية المتدرجة على 3 طبقات (Stepped Tiered Climb)",
        "14. المسح البيضاوي الواسع للسطوح (Wide Elliptical Sweep)",
        "15. الانقضاض المموه والارتفاع المفاجئ (Feint Descent & Pull-Up)",
        "16. طيران النسق المثلثي المتماسك (V-Formation Cohesive Flock)",
        "17. قلب الجناح اليميني واليساري المتناوب (Alternating Wing-Flip)",
        "18. الطواف الحلزوني الواسع مع التيارات الدافئة (Wide Drift Thermal)",
        "19. مناورة المناوشة والاندماج العالي (High-Sky Skirmish & Merge)",
        "20. الطيران الاستعراضي المتموج (Sine-Wave Show Flight)"
    };

    private static final EntityDataAccessor<String> DATA_BREED =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> DATA_ANIM_STATE =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> DATA_IS_MALE =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_MENTALLY =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_THE_LIMIT =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_FEATHER_STAGE =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_SQUAB_DAY =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT); // 0 = بالغ، 1..5 = مراحل نمو الطير على 5 أيام ماينكرافتية!
    private static final EntityDataAccessor<Integer> DATA_CLIPPED_FEATHERS =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_LEG_RING_COLOR =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_HYBRID_SKIN_VARIANT =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<BlockPos> DATA_HOME_ROOF =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.BLOCK_POS);
    private static final EntityDataAccessor<Integer> DATA_FLIGHT_MECHANIC =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT); // 0..19 ميكانيكية الطيران اليومية

    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    private int ageTicks = 24000 * 5; // البالغ الافتراضي عمره 5+ أيام
    private int roofMemorizedTicks = 0;
    private int ticksWithoutFood = 0;
    private int visitedNewRegionsCount = 0;
    private int actionAnimTimer = 0;
    private boolean flightActive = false;
    private boolean recallDescending = false; // محفز النزول والرجوع الحلزوني (على الصافرة أو الإشارة/الخشاش)
    private int currentFlightTicks = 0;
    private int targetFlightDurationTicks = 2400;

    public ArgonPigeonEntity(EntityType<? extends ShoulderRidingEntity> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 20, false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return ShoulderRidingEntity.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 14.0D)
                .add(Attributes.FLYING_SPEED, 1.15D)
                .add(Attributes.MOVEMENT_SPEED, 0.25D)
                .add(Attributes.FOLLOW_RANGE, 256.0D);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
        nav.setCanOpenDoors(true);
        nav.setCanFloat(true);
        nav.setCanPassDoors(true);
        return nav;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_BREED, Breed.ZAJIL.id);
        this.entityData.define(DATA_ANIM_STATE, AnimState.IDLE.name());
        this.entityData.define(DATA_IS_MALE, true);
        this.entityData.define(DATA_MENTALLY, 88);
        this.entityData.define(DATA_THE_LIMIT, 0);
        this.entityData.define(DATA_FEATHER_STAGE, 1);
        this.entityData.define(DATA_SQUAB_DAY, 0);
        this.entityData.define(DATA_CLIPPED_FEATHERS, 0);
        this.entityData.define(DATA_LEG_RING_COLOR, -1);
        this.entityData.define(DATA_HYBRID_SKIN_VARIANT, 0);
        this.entityData.define(DATA_HOME_ROOF, BlockPos.ZERO);
        this.entityData.define(DATA_FLIGHT_MECHANIC, 0);
    }

    /**
     * يبدأ الطير كفرخ حديث الولادة (اليوم 1) ويكبر شكله وحجمه كل يوم على مدار 5 أيام ماينكرافتية!
     */
    public void startAsNewbornSquab() {
        this.ageTicks = 0;
        this.setSquabDay(1);
        this.setFeatherStage(0);
    }

    public void rollStatsForBreed(Breed breed) {
        this.setBreed(breed);
        this.setMale(this.random.nextBoolean());
        this.setLegRingColorIndex(-1);

        switch (breed) {
            case ZAJIL -> {
                int m = (this.random.nextFloat() < 0.75F) ? (85 + this.random.nextInt(16)) : (65 + this.random.nextInt(20));
                this.setMentally(m);
                this.setTheLimit(0);
            }
            case RED -> {
                this.setMentally(72 + this.random.nextInt(27));
                this.setTheLimit(0);
            }
            case TEDDY, GOLDEN -> {
                this.setMentally(90 + this.random.nextInt(11));
                float r = this.random.nextFloat();
                int limit = (r < 0.65F) ? (85 + this.random.nextInt(16)) : ((r < 0.90F) ? (75 + this.random.nextInt(10)) : (60 + this.random.nextInt(15)));
                this.setTheLimit(limit);
            }
            case KADHMAWI -> {
                this.setMentally(86 + this.random.nextInt(13));
                this.setTheLimit(0);
            }
            case HYBRID_TEDDY_KADHMAWI -> {
                this.setMentally(94 + this.random.nextInt(7));
                this.setTheLimit(65 + this.random.nextInt(18));
                this.entityData.set(DATA_HYBRID_SKIN_VARIANT, this.random.nextInt(3));
            }
            case HYBRID_KADHMAWI_GOLDEN -> {
                this.setMentally(92 + this.random.nextInt(9));
                this.setTheLimit(78 + this.random.nextInt(14));
            }
            case HYBRID_TEDDY_GOLDEN -> {
                this.setMentally(92 + this.random.nextInt(9));
                this.setTheLimit(82 + this.random.nextInt(18));
                this.entityData.set(DATA_HYBRID_SKIN_VARIANT, this.random.nextInt(2));
            }
        }
    }

    /**
     * إصلاح جذري لتفاعل الأدوات والحلقات والشبكة والبطاقة والمقص والدخن مع الطير!
     * يمنع TamableAnimal.mobInteract من ابتلاع ضغطة الكلك يمين.
     */
    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);

        // 1. تلبيس الحلقات الـ 20 الملونة (إصلاح مشكلة عدم عمل الحلقات!)
        if (stack.getItem() instanceof ColoredLegRingItem ringItem) {
            if (!this.level().isClientSide) {
                this.setLegRingColorIndex(ringItem.colorIndex);
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
                this.level().playSound(null, this.blockPosition(), SoundEvents.ARMOR_EQUIP_GOLD, SoundSource.PLAYERS, 1.0F, 1.3F);
                player.displayClientMessage(Component.literal("§a§l[حلقة الرجل 3D] §fتم تلبيس الطير حلقة رجل ثلاثية الأبعاد بلون: §e" + ringItem.arabicColorName), true);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // 2. إمساك الطير بالشبكة (إصلاح اختفاء الطير وعدم القدرة على رسبنته!)
        if (stack.getItem() instanceof CatchNetItem) {
            return CatchNetItem.capturePigeonIntoStack(stack, player, this, hand);
        }

        // 3. إطعام الطير بالدخن مباشرة (ويسرع نمو الفرخ الصغير أيضاً!)
        if (stack.is(ArgonLoftPigeonsMod.M7_GRAIN_HANDFUL.get()) || stack.is(ArgonLoftPigeonsMod.M7_FEED_BAG.get())) {
            if (!this.level().isClientSide) {
                this.feedM7();
                if (this.getSquabDay() > 0) {
                    // إطعام الفرخ يسرع نموه بمقدار نصف يوم ماينكرافتي!
                    this.ageTicks += 12000;
                    updateFiveDayGrowthStage();
                    player.displayClientMessage(Component.literal("§a[تغذية ونمو الفرخ] §fأكل الفرخ الدخن ونما! (المرحلة الحالية: اليوم " + (this.getSquabDay() == 0 ? "5 - بالغ" : this.getSquabDay() + " من 5") + ")"), true);
                } else {
                    player.displayClientMessage(Component.literal("§a[إطعام الدخن] §fأكل " + this.getBreed().arabicName + " حبيبات الدخن وشبع!"), true);
                }
                if (!player.getAbilities().instabuild) {
                    stack.shrink(1);
                }
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }

        // 4. فحص الطير ببطاقة المعلومات (Certificate) أو قص الجناح بالمقص (Scissors)
        if (stack.getItem() instanceof CertificateItem || stack.getItem() instanceof PigeonScissorsItem) {
            return stack.getItem().interactLivingEntity(stack, player, this, hand);
        }

        return InteractionResult.PASS;
    }

    public int getRequiredRoofDays() {
        return switch (this.getBreed()) {
            case ZAJIL -> 15;
            case RED -> 8;
            case TEDDY -> (this.getTheLimit() >= 85) ? 15 : 20;
            case KADHMAWI -> 10;
            case GOLDEN -> 20;
            case HYBRID_TEDDY_KADHMAWI -> 12;
            case HYBRID_KADHMAWI_GOLDEN -> 15;
            case HYBRID_TEDDY_GOLDEN -> 25;
        };
    }

    public int getMemorizedRoofDays() {
        return this.roofMemorizedTicks / 24000;
    }

    public boolean hasCompletedRoofMemory() {
        return getMemorizedRoofDays() >= getRequiredRoofDays();
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PigeonMasterFlightGoal(this));
        this.goalSelector.addGoal(1, new EatDukhnGoal(this)); // أولوية قصوى لرؤية وأكل الدخن على الأرض!
        this.goalSelector.addGoal(2, new RoofExploreAndMemorizeGoal(this));
        this.goalSelector.addGoal(3, new LoftIndoorLifeGoal(this));
        this.goalSelector.addGoal(4, new LookAtPlayerGoal(this, Player.class, 8.0F));
    }

    /**
     * نظام النمو التدريجي على مدار 5 أيام ماينكرافتية (كل يوم يكبر شكله وحجمه!):
     * اليوم 1 (0..23999 تيك): SquabDay = 1 (حجم 0.30x)
     * اليوم 2 (24000..47999 تيك): SquabDay = 2 (حجم 0.45x)
     * اليوم 3 (48000..71999 تيك): SquabDay = 3 (حجم 0.62x)
     * اليوم 4 (72000..95999 تيك): SquabDay = 4 (حجم 0.78x)
     * اليوم 5 (96000..119999 تيك): SquabDay = 5 (حجم 0.92x)
     * بعد إتمام 5 أيام ماينكرافتية (120000+ تيك): يصبح طيراً كاملاً (SquabDay = 0, FeatherStage = 1..10)!
     */
    private void updateFiveDayGrowthStage() {
        int dayIndex = this.ageTicks / 24000; // 0, 1, 2, 3, 4 -> الأيام 1 إلى 5
        if (dayIndex < 5) {
            int newSquabDay = dayIndex + 1; // 1 .. 5
            if (this.getSquabDay() != newSquabDay) {
                this.setSquabDay(newSquabDay);
                if (this.level() instanceof ServerLevel sl) {
                    sl.sendParticles(ParticleTypes.HAPPY_VILLAGER, this.getX(), this.getY() + 0.35D, this.getZ(), 8, 0.2D, 0.2D, 0.2D, 0.02D);
                }
            }
            this.setFeatherStage(0);
        } else {
            if (this.getSquabDay() != 0 && this.level() instanceof ServerLevel sl) {
                sl.sendParticles(ParticleTypes.HEART, this.getX(), this.getY() + 0.5D, this.getZ(), 6, 0.25D, 0.25D, 0.25D, 0.02D);
            }
            this.setSquabDay(0);
            int feather = Math.min(10, 1 + ((dayIndex - 5) / 2));
            this.setFeatherStage(feather);
        }
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;

        this.ageTicks++;
        if (this.tickCount % 20 == 0) {
            updateFiveDayGrowthStage();
        }

        // نظام الجوع
        this.ticksWithoutFood++;
        if (this.ticksWithoutFood >= 72000) {
            this.setAnimState(AnimState.STARVE_DEATH);
            this.hurt(this.damageSources().starve(), 100.0F);
            return;
        }

        // التقاط حبوب الدخن المرمية كـ ItemEntity على الأرض أيضاً
        if (this.onGround() && !this.flightActive && this.tickCount % 15 == 0) {
            List<ItemEntity> m7Drops = this.level().getEntitiesOfClass(
                    ItemEntity.class,
                    this.getBoundingBox().inflate(6.0D),
                    item -> item.getItem().is(ArgonLoftPigeonsMod.M7_GRAIN_HANDFUL.get())
            );
            if (!m7Drops.isEmpty()) {
                ItemEntity drop = m7Drops.get(0);
                this.getNavigation().moveTo(drop, 1.05D);
                if (this.distanceToSqr(drop) < 2.2D) {
                    drop.getItem().shrink(1);
                    this.feedM7();
                }
            }
        }

        // حفظ السطح تحت السماء المفتوحة
        if (this.onGround() && !this.flightActive && this.level().canSeeSky(this.blockPosition())) {
            this.roofMemorizedTicks += 20;
            if (this.getHomeRoof().equals(BlockPos.ZERO)) {
                this.setHomeRoof(this.blockPosition());
            }
        }

        if (this.actionAnimTimer > 0) {
            this.actionAnimTimer--;
            if (this.actionAnimTimer == 0 && !this.flightActive) {
                this.setAnimState(AnimState.IDLE);
            }
        }
    }

    public void feedM7() {
        this.ticksWithoutFood = 0;
        this.heal(4.0F);
        this.actionAnimTimer = 45;
        this.setAnimState(AnimState.EAT_M7);
        this.level().playSound(null, this.blockPosition(), SoundEvents.PARROT_EAT, SoundSource.NEUTRAL, 0.8F, 1.1F);
    }

    /**
     * إطلاق الطير للطيران مع اختيار إحدى الـ 20 ميكانيكية طيران متغيرة للأحمر والزاجل!
     */
    public void launchPigeonFlight(@Nullable Player player) {
        if (this.getClippedFeathers() >= 3) {
            if (player != null && !this.level().isClientSide) {
                player.displayClientMessage(Component.literal("§c[مقصوص الجناح] §fهذا الطير مقصوص منه " + this.getClippedFeathers() + " ريشات ولا يستطيع الطيران!"), true);
            }
            return;
        }
        if (this.getSquabDay() > 0) {
            if (player != null && !this.level().isClientSide) {
                player.displayClientMessage(Component.literal("§e[فرخ صغير - اليوم " + this.getSquabDay() + "/5] §fالفرخ لم يكمل 5 أيام من النمو بعد ولا يطير!"), true);
            }
            return;
        }

        if (this.getHomeRoof().equals(BlockPos.ZERO)) {
            this.setHomeRoof(this.blockPosition());
        }

        this.flightActive = true;
        this.recallDescending = false;
        this.currentFlightTicks = 0;

        // اختيار ميكانيكية الطيران اليومية (من 0 إلى 19) للأحمر والزاجل بحيث يختلف طيرانهم كل يوم مثل الحقيقة!
        long worldDay = this.level().getDayTime() / 24000L;
        int mechId = (int) ((worldDay * 7L + this.random.nextInt(20)) % 20);
        this.setFlightMechanicId(mechId);

        int hours = switch (this.getBreed()) {
            case ZAJIL -> (this.getMentally() >= 85) ? (2 + this.random.nextInt(2)) : 1;
            case RED -> (this.getMentally() >= 80) ? 3 : 2;
            case TEDDY -> (this.getTheLimit() >= 85) ? (13 + this.random.nextInt(2)) : (7 + this.random.nextInt(6));
            case KADHMAWI -> 4 + this.random.nextInt(6);
            case GOLDEN -> 10 + this.random.nextInt(4);
            case HYBRID_TEDDY_KADHMAWI -> 6 + this.random.nextInt(3);
            case HYBRID_KADHMAWI_GOLDEN -> 11 + this.random.nextInt(3);
            case HYBRID_TEDDY_GOLDEN -> 15;
        };
        this.targetFlightDurationTicks = hours * 1000;
    }

    /**
     * تفعيل محفز النزول والرجوع (الهبوط الحلزوني على الإشارة / الصافرة / الخشّاش)
     */
    public void triggerRecallSpiralDescent(BlockPos targetLoftAnchor) {
        if (!this.flightActive) return;
        this.recallDescending = true;
        if (!targetLoftAnchor.equals(BlockPos.ZERO)) {
            this.setHomeRoof(targetLoftAnchor);
        }
    }

    public boolean checkShouldGetLost(@Nullable Player owner) {
        Breed b = this.getBreed();
        if (b == Breed.ZAJIL) return false;

        if (!this.hasCompletedRoofMemory()) {
            notifyOwner(owner, "§c[ضياع طير!] §fطار " + b.arabicName + " قبل إتمام أيام حفظ السطح (" + getMemorizedRoofDays() + "/" + getRequiredRoofDays() + " يوم) وضاع!");
            return true;
        }

        double distFromRoof = Math.sqrt(this.blockPosition().distSqr(this.getHomeRoof()));
        if ((b == Breed.RED || b == Breed.KADHMAWI) && distFromRoof > 140.0D) {
            if (this.visitedNewRegionsCount < 2) {
                this.visitedNewRegionsCount++;
                if (this.random.nextFloat() > 0.35F) {
                    notifyOwner(owner, "§c[ضياع في منطقة جديدة!] §fضاع " + b.arabicName + " لأنه لم يزر هذه المنطقة مرتين سابقاً!");
                    return true;
                }
            } else if (this.random.nextFloat() > 0.80F) {
                notifyOwner(owner, "§c[ضياع!] §fلم يتمكن " + b.arabicName + " من العودة (احتمال الـ 20%).");
                return true;
            }
        }

        if (b == Breed.TEDDY) {
            if (this.getTheLimit() >= 85) {
                notifyOwner(owner, "§c[حدة عالية 85+!] §fطار التيدي 13+ ساعة بسبب حدته (" + getTheLimit() + "%) وأرهق وضاع في البند!");
                return true;
            }
            if (this.getFeatherStage() < 10 && this.random.nextFloat() < 0.45F) {
                notifyOwner(owner, "§c[جينات حادة!] §fتفعلت طفرة الحدة في التيدي (قبل الريشة 10) فواصل الطيران وضاع!");
                return true;
            }
        } else if (b == Breed.GOLDEN) {
            if (this.getFeatherStage() < 10 && this.getTheLimit() >= 85 && this.random.nextFloat() < 0.70F) {
                notifyOwner(owner, "§c[طفرة حدة الكولدن!] §fتفعلت طفرة الحدة في الكولدن (قبل الريشة 10) وضاع في الغيم!");
                return true;
            }
        }
        return false;
    }

    private void notifyOwner(@Nullable Player owner, String msg) {
        if (owner != null && !this.level().isClientSide) {
            owner.sendSystemMessage(Component.literal(msg));
        }
    }

    public static Breed computeOffspringBreed(Breed parentA, Breed parentB) {
        if (parentA == parentB) return parentA;
        if ((parentA == Breed.TEDDY && parentB == Breed.KADHMAWI) || (parentA == Breed.KADHMAWI && parentB == Breed.TEDDY)) {
            return Breed.HYBRID_TEDDY_KADHMAWI;
        }
        if ((parentA == Breed.KADHMAWI && parentB == Breed.GOLDEN) || (parentA == Breed.GOLDEN && parentB == Breed.KADHMAWI)) {
            return Breed.HYBRID_KADHMAWI_GOLDEN;
        }
        if ((parentA == Breed.TEDDY && parentB == Breed.GOLDEN) || (parentA == Breed.GOLDEN && parentB == Breed.TEDDY)) {
            return Breed.HYBRID_TEDDY_GOLDEN;
        }
        return parentA;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "argon_v5_controller", 3, state -> {
            AnimState st = this.getAnimState();
            if (st == AnimState.STARVE_DEATH) {
                return state.setAndContinue(RawAnimation.begin().thenPlayAndHold("animation.argon_pigeon.starve_death"));
            }
            if (st == AnimState.INCUBATE_EGGS) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.incubate_eggs"));
            }
            if (st == AnimState.FEED_SQUAB_ZAQQ) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.feed_squab_zaqq"));
            }
            if (!this.onGround()) {
                if (st == AnimState.FLIGHT_WING_FLIP) {
                    return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.wing_flip_flight"));
                }
                if (st == AnimState.FLIGHT_BAND_CLIMB) {
                    return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.highflyer_band_climb"));
                }
                if (st == AnimState.THERMAL_GLIDE) {
                    return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.thermal_glide"));
                }
                if (st == AnimState.SPIRAL_DIVE) {
                    return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.spiral_dive"));
                }
                if (st == AnimState.LANDING_FAN_TAIL) {
                    return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.landing_fan_tail"));
                }
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.flight_flap"));
            }
            if (st == AnimState.EAT_M7) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.eat_m7"));
            }
            if (st == AnimState.COURTSHIP_COO) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.courtship_coo_bow"));
            }
            if (st == AnimState.PREEN_FEATHERS) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.preen_feathers"));
            }
            if (state.isMoving() || st == AnimState.ROOF_EXPLORE) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.roof_explore_look"));
            }
            return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.proud_idle"));
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    public boolean isFlying() {
        return !this.onGround();
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    // Getters & Setters
    public Breed getBreed() { return Breed.fromId(this.entityData.get(DATA_BREED)); }
    public void setBreed(Breed b) { this.entityData.set(DATA_BREED, b.id); }

    public AnimState getAnimState() {
        try { return AnimState.valueOf(this.entityData.get(DATA_ANIM_STATE)); }
        catch (Exception e) { return AnimState.IDLE; }
    }
    public void setAnimState(AnimState s) { this.entityData.set(DATA_ANIM_STATE, s.name()); }

    public boolean isMale() { return this.entityData.get(DATA_IS_MALE); }
    public void setMale(boolean male) { this.entityData.set(DATA_IS_MALE, male); }

    public int getMentally() { return this.entityData.get(DATA_MENTALLY); }
    public void setMentally(int m) { this.entityData.set(DATA_MENTALLY, m); }

    public int getTheLimit() { return this.entityData.get(DATA_THE_LIMIT); }
    public void setTheLimit(int l) { this.entityData.set(DATA_THE_LIMIT, l); }

    public int getFeatherStage() { return this.entityData.get(DATA_FEATHER_STAGE); }
    public void setFeatherStage(int f) { this.entityData.set(DATA_FEATHER_STAGE, f); }

    public int getSquabDay() { return this.entityData.get(DATA_SQUAB_DAY); }
    public void setSquabDay(int d) { this.entityData.set(DATA_SQUAB_DAY, d); }

    public int getClippedFeathers() { return this.entityData.get(DATA_CLIPPED_FEATHERS); }
    public void setClippedFeathers(int c) { this.entityData.set(DATA_CLIPPED_FEATHERS, Math.max(0, Math.min(10, c))); }

    public int getLegRingColorIndex() { return this.entityData.get(DATA_LEG_RING_COLOR); }
    public void setLegRingColorIndex(int idx) { this.entityData.set(DATA_LEG_RING_COLOR, idx); }

    public int getHybridSkinVariant() { return this.entityData.get(DATA_HYBRID_SKIN_VARIANT); }

    public BlockPos getHomeRoof() { return this.entityData.get(DATA_HOME_ROOF); }
    public void setHomeRoof(BlockPos pos) { this.entityData.set(DATA_HOME_ROOF, pos); }

    public int getFlightMechanicId() { return this.entityData.get(DATA_FLIGHT_MECHANIC); }
    public void setFlightMechanicId(int id) { this.entityData.set(DATA_FLIGHT_MECHANIC, Math.max(0, Math.min(19, id))); }

    public boolean isFlightActive() { return this.flightActive; }
    public void setFlightActive(boolean active) { this.flightActive = active; }
    public boolean isRecallDescending() { return this.recallDescending; }
    public void setRecallDescending(boolean desc) { this.recallDescending = desc; }
    public int getCurrentFlightTicks() { return this.currentFlightTicks; }
    public void incrementFlightTicks() { this.currentFlightTicks++; }
    public int getTargetFlightDurationTicks() { return this.targetFlightDurationTicks; }
    public int getTicksWithoutFood() { return this.ticksWithoutFood; }
    public int getAgeMonths() { return Math.max(1, (this.ageTicks / 24000) / 3); }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob mate) {
        ArgonPigeonEntity child = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(level);
        if (child != null && mate instanceof ArgonPigeonEntity other) {
            Breed offspringBreed = computeOffspringBreed(this.getBreed(), other.getBreed());
            child.rollStatsForBreed(offspringBreed);
            child.startAsNewbornSquab();
        }
        return child;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("Breed", this.getBreed().id);
        tag.putBoolean("IsMale", this.isMale());
        tag.putInt("Mentally", this.getMentally());
        tag.putInt("TheLimit", this.getTheLimit());
        tag.putInt("FeatherStage", this.getFeatherStage());
        tag.putInt("SquabDay", this.getSquabDay());
        tag.putInt("ClippedFeathers", this.getClippedFeathers());
        tag.putInt("LegRingColor", this.getLegRingColorIndex());
        tag.putInt("HybridVariant", this.getHybridSkinVariant());
        tag.putInt("FlightMechanic", this.getFlightMechanicId());
        tag.putInt("AgeTicks", this.ageTicks);
        tag.putInt("RoofMemorizedTicks", this.roofMemorizedTicks);
        tag.putInt("TicksWithoutFood", this.ticksWithoutFood);
        tag.putInt("VisitedRegions", this.visitedNewRegionsCount);
        tag.putInt("RoofX", this.getHomeRoof().getX());
        tag.putInt("RoofY", this.getHomeRoof().getY());
        tag.putInt("RoofZ", this.getHomeRoof().getZ());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Breed")) this.setBreed(Breed.fromId(tag.getString("Breed")));
        if (tag.contains("IsMale")) this.setMale(tag.getBoolean("IsMale"));
        if (tag.contains("Mentally")) this.setMentally(tag.getInt("Mentally"));
        if (tag.contains("TheLimit")) this.setTheLimit(tag.getInt("TheLimit"));
        if (tag.contains("FeatherStage")) this.setFeatherStage(tag.getInt("FeatherStage"));
        if (tag.contains("SquabDay")) this.setSquabDay(tag.getInt("SquabDay"));
        if (tag.contains("ClippedFeathers")) this.setClippedFeathers(tag.getInt("ClippedFeathers"));
        if (tag.contains("LegRingColor")) this.setLegRingColorIndex(tag.getInt("LegRingColor"));
        if (tag.contains("HybridVariant")) this.entityData.set(DATA_HYBRID_SKIN_VARIANT, tag.getInt("HybridVariant"));
        if (tag.contains("FlightMechanic")) this.setFlightMechanicId(tag.getInt("FlightMechanic"));
        this.ageTicks = tag.getInt("AgeTicks");
        this.roofMemorizedTicks = tag.getInt("RoofMemorizedTicks");
        this.ticksWithoutFood = tag.getInt("TicksWithoutFood");
        this.visitedNewRegionsCount = tag.getInt("VisitedRegions");
        if (tag.contains("RoofX")) {
            this.setHomeRoof(new BlockPos(tag.getInt("RoofX"), tag.getInt("RoofY"), tag.getInt("RoofZ")));
        }
    }
}
