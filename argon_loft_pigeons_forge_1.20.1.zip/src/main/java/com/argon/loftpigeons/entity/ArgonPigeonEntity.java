package com.argon.loftpigeons.entity;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ai.PigeonMasterFlightGoal;
import com.argon.loftpigeons.entity.ai.RoofExploreAndMemorizeGoal;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.control.FlyingMoveControl;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.navigation.FlyingPathNavigation;
import net.minecraft.world.entity.ai.navigation.PathNavigation;
import net.minecraft.world.entity.animal.FlyingAnimal;
import net.minecraft.world.entity.animal.ShoulderRidingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

import java.util.List;

public class ArgonPigeonEntity extends ShoulderRidingEntity implements GeoEntity, FlyingAnimal {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public enum Breed {
        ZAJIL("zajil", "الزاجل (Zajil)"),
        RED("red", "الأحمر (Red)"),
        TEDDY("teddy", "التيدي (Teddy)"),
        KADHMAWI("kadhmawi", "الأبيض الكظماوي (White Kadhmawi)"),
        GOLDEN("golden", "الكولدن (Golden)"),
        HYBRID_TEDDY_KADHMAWI("hybrid_teddy_kadhmawi", "هجين: تيدي × كظماوي"),
        HYBRID_KADHMAWI_GOLDEN("hybrid_kadhmawi_golden", "هجين: كظماوي × كولدن"),
        HYBRID_TEDDY_GOLDEN("hybrid_teddy_golden", "هجين: تيدي × كولدن");

        public final String id;
        public final String arabicName;

        Breed(String id, String arabicName) {
            this.id = id;
            this.arabicName = arabicName;
        }

        public static Breed fromId(String id) {
            for (Breed b : values()) {
                if (b.id.equalsIgnoreCase(id)) return b;
            }
            return ZAJIL;
        }

        public boolean hasLimitStat() {
            return this == TEDDY || this == GOLDEN || this == HYBRID_TEDDY_GOLDEN || this == HYBRID_TEDDY_KADHMAWI || this == HYBRID_KADHMAWI_GOLDEN;
        }
    }

    public enum AnimState {
        IDLE,
        ROOF_EXPLORE,
        FLIGHT_NORMAL,
        FLIGHT_WING_FLIP,
        FLIGHT_BAND_CLIMB,
        LANDING_FAN_TAIL,
        EAT_M7,
        FEED_SQUAB_ZAQQ,
        INCUBATE_EGGS,
        STARVE_DEATH
    }

    private static final EntityDataAccessor<String> DATA_BREED =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<String> DATA_ANIM_STATE =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.STRING);
    private static final EntityDataAccessor<Boolean> DATA_IS_MALE =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Integer> DATA_MENTALLY =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_THE_LIMIT =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Integer> DATA_FEATHER_STAGE =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT); // 0 = فرخ، 1..10 = الريشة 1 إلى 10
    private static final EntityDataAccessor<Integer> DATA_SQUAB_DAY =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT); // 0 = بالغ، 1..5 = أيام الفرخ قبل الريشة الأولى
    private static final EntityDataAccessor<Integer> DATA_CLIPPED_FEATHERS =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT); // 0..10 عدد الريشات المقصوصة بالمقص
    private static final EntityDataAccessor<Integer> DATA_LEG_RING_COLOR =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT); // -1 = بدون حلقة افتراضياً، 0..19 = لون الحلقة
    private static final EntityDataAccessor<Integer> DATA_HYBRID_SKIN_VARIANT =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.INT); // تنوع ألوان الهجين
    private static final EntityDataAccessor<BlockPos> DATA_HOME_ROOF =
            SynchedEntityData.defineId(ArgonPigeonEntity.class, EntityDataSerializers.BLOCK_POS);

    
    // المتغيرات الزمنية والبيولوجية (اليوم الماينكرافتي = 24000 تيك)
    private int ageTicks = 24000 * 6; // يبدأ الطير المشترى بعمر الريشة 1 (اليوم السادس)
    private int roofMemorizedTicks = 0; // يحسب فقط عندما يكون الطير خارج البرج على السطح تحت السماء!
    private int ticksWithoutFood = 0;  // يموت الطير إذا وصل إلى 3 أيام ماينكرافتية (72000 تيك) بدون أكل m7!
    private int visitedNewRegionsCount = 0; // لحساب نسبة عودة الأحمر والكظماوي (80% إذا زار المنطقة مرتين سابقاً)
    private int actionAnimTimer = 0;
    private boolean flightActive = false;
    private int currentFlightTicks = 0;
    private int targetFlightDurationTicks = 2000;

    public ArgonPigeonEntity(EntityType<? extends ShoulderRidingEntity> type, Level level) {
        super(type, level);
        this.moveControl = new FlyingMoveControl(this, 20, false);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return ShoulderRidingEntity.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 14.0D)
                .add(Attributes.FLYING_SPEED, 1.15D)
                .add(Attributes.MOVEMENT_SPEED, 0.24D)
                .add(Attributes.FOLLOW_RANGE, 256.0D);
    }

    @Override
    protected PathNavigation createNavigation(Level level) {
        FlyingPathNavigation nav = new FlyingPathNavigation(this, level);
        nav.setCanOpenDoors(false);
        nav.setCanFloat(true);
        nav.setCanPassDoors(true);
        return nav;
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(DATA_BREED, Breed.ZAJIL.id);
        this.entityData.define(DATA_ANIM_STATE, AnimState.IDLE.name());
        this.entityData.define(DATA_IS_MALE, true);
        this.entityData.define(DATA_MENTALLY, 88);
        this.entityData.define(DATA_THE_LIMIT, 0);
        this.entityData.define(DATA_FEATHER_STAGE, 1);
        this.entityData.define(DATA_SQUAB_DAY, 0);
        this.entityData.define(DATA_CLIPPED_FEATHERS, 0);
        this.entityData.define(DATA_LEG_RING_COLOR, -1); // لا يولد أي طير بحلقة تلقائية!
        this.entityData.define(DATA_HYBRID_SKIN_VARIANT, 0);
        this.entityData.define(DATA_HOME_ROOF, BlockPos.ZERO);
    }

    /**
     * توليد الإحصائيات الوراثية الدقيقة (Mentally & The Limit) حسب جدول التعليمات
     */
    public void rollStatsForBreed(Breed breed) {
        this.setBreed(breed);
        this.setMale(this.random.nextBoolean());
        this.setLegRingColorIndex(-1); // مخفي افتراضياً بدون حلقة

        switch (breed) {
            case ZAJIL -> {
                // 75% ذكاء عالٍ (85-100)، 25% متوسط (65-84)
                int m = (this.random.nextFloat() < 0.75F) ? (85 + this.random.nextInt(16)) : (65 + this.random.nextInt(20));
                this.setMentally(m);
                this.setTheLimit(0);
            }
            case RED -> {
                // يعتمد على قوة الدم والتحمل
                this.setMentally(70 + this.random.nextInt(28));
                this.setTheLimit(0);
            }
            case TEDDY, GOLDEN -> {
                // الذكاء 90+ دائماً؛ الحدة 60-100 (أغلبها 85-100 أو 75-84)
                this.setMentally(90 + this.random.nextInt(11));
                float r = this.random.nextFloat();
                int limit;
                if (r < 0.65F) {
                    limit = 85 + this.random.nextInt(16); // 85-100
                } else if (r < 0.90F) {
                    limit = 75 + this.random.nextInt(10); // 75-84
                } else {
                    limit = 60 + this.random.nextInt(15); // 60-74
                }
                this.setTheLimit(limit);
            }
            case KADHMAWI -> {
                // ذكي وبارد الدم
                this.setMentally(86 + this.random.nextInt(13));
                this.setTheLimit(0);
            }
            case HYBRID_TEDDY_KADHMAWI -> {
                // ذكاء خارق ودم بارد (يكسر الكظماوي حدة التيدي)
                this.setMentally(94 + this.random.nextInt(7));
                this.setTheLimit(65 + this.random.nextInt(18)); // حدة مكسورة متوازنة
                this.entityData.set(DATA_HYBRID_SKIN_VARIANT, this.random.nextInt(3)); // أبيض، تيدي، أو متداخلة
            }
            case HYBRID_KADHMAWI_GOLDEN -> {
                // يجمع ذكاء الكظماوي وقوة الكولدن
                this.setMentally(92 + this.random.nextInt(9));
                this.setTheLimit(78 + this.random.nextInt(14));
            }
            case HYBRID_TEDDY_GOLDEN -> {
                // يرث Mentally و The Limit
                this.setMentally(92 + this.random.nextInt(9));
                this.setTheLimit(82 + this.random.nextInt(18));
                this.entityData.set(DATA_HYBRID_SKIN_VARIANT, this.random.nextInt(2)); // شكلان مطعمان
            }
        }
    }

    /**
     * حساب عدد أيام حفظ السطح المطلوبة لكل سلالة أو هجين حسب الجدول بالحرف الواحد
     */
    public int getRequiredRoofDays() {
        return switch (this.getBreed()) {
            case ZAJIL -> 15;
            case RED -> 8;
            case TEDDY -> (this.getTheLimit() >= 85) ? 15 : 20; // 15 يوماً للحاد / 19-20 يوماً لأقل من 84
            case KADHMAWI -> 10;
            case GOLDEN -> 20;
            case HYBRID_TEDDY_KADHMAWI -> 12;
            case HYBRID_KADHMAWI_GOLDEN -> 15;
            case HYBRID_TEDDY_GOLDEN -> 25;
        };
    }

    public int getMemorizedRoofDays() {
        return this.roofMemorizedTicks / 24000;
    }

    public boolean hasCompletedRoofMemory() {
        return getMemorizedRoofDays() >= getRequiredRoofDays();
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new PigeonMasterFlightGoal(this));
        this.goalSelector.addGoal(2, new RoofExploreAndMemorizeGoal(this));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0F));
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level().isClientSide) return;

        // 1. تقدم العمر والريش (من الفرخ 1-5 أيام ثم الريشة 1 إلى الريشة 10)
        this.ageTicks++;
        int totalDays = this.ageTicks / 24000;
        if (totalDays < 6) {
            this.setSquabDay(Math.max(1, totalDays));
            this.setFeatherStage(0);
        } else {
            this.setSquabDay(0);
            int feather = Math.min(10, 1 + ((totalDays - 6) / 3));
            this.setFeatherStage(feather);
        }

        // 2. نظام الجوع: يموت الطير إذا بقي بدون أكل m7 لمدة 3 أيام ماينكرافتية (72,000 تيك)
        this.ticksWithoutFood++;
        if (this.ticksWithoutFood >= 72000) {
            this.setAnimState(AnimState.STARVE_DEATH);
            this.hurt(this.damageSources().starve(), 100.0F);
            return;
        }

        // البحث التلقائي عن حب m7 المرمي على أرضية البرج أو السطح
        if (this.onGround() && !this.flightActive && this.tickCount % 20 == 0) {
            List<ItemEntity> m7Drops = this.level().getEntitiesOfClass(
                    ItemEntity.class,
                    this.getBoundingBox().inflate(5.0D),
                    item -> item.getItem().is(ArgonLoftPigeonsMod.M7_GRAIN_HANDFUL.get())
            );
            if (!m7Drops.isEmpty()) {
                ItemEntity drop = m7Drops.get(0);
                this.getNavigation().moveTo(drop, 1.0D);
                if (this.distanceToSqr(drop) < 2.0D) {
                    drop.getItem().shrink(1);
                    this.feedM7();
                }
            }
        }

        // 3. شرط حفظ السطح الفعلي: حبس الطير داخل البرج (تحت سقف) لا يُحسب!
        // يجب أن يكون على السطح تحت السماء المفتوحة (`canSeeSky`) ليحفظ المعالم
        if (this.onGround() && !this.flightActive && this.level().canSeeSky(this.blockPosition())) {
            this.roofMemorizedTicks += 20; // تسريع متوازن أثناء استكشاف السطح
            if (this.getHomeRoof().equals(BlockPos.ZERO)) {
                this.setHomeRoof(this.blockPosition());
            }
        }

        if (this.actionAnimTimer > 0) {
            this.actionAnimTimer--;
            if (this.actionAnimTimer == 0 && !this.flightActive) {
                this.setAnimState(AnimState.IDLE);
            }
        }
    }

    public void feedM7() {
        this.ticksWithoutFood = 0;
        this.heal(4.0F);
        this.actionAnimTimer = 50;
        this.setAnimState(AnimState.EAT_M7);
    }

    /**
     * تطيير الطير (بالقماشة السوداء أو عند إطلاقه) مع حساب مدة الطيران واحتمالية الضياع حسب الجدول
     */
    public void launchPigeonFlight(@Nullable Player player) {
        // إذا كان الجناح مقصوصاً بالمقص (أكثر من 3 ريشات) لا يستطيع الطيران!
        if (this.getClippedFeathers() >= 3) {
            if (player != null && !this.level().isClientSide) {
                player.displayClientMessage(Component.literal("§c[مقصوص الجناح] §fهذا الطير مقصوص منه " + this.getClippedFeathers() + " ريشات ولا يستطيع الطيران!"), true);
            }
            return;
        }
        if (this.getSquabDay() > 0) return; // الفرخ الصغير لا يطير قبل الريشة الأولى

        if (this.getHomeRoof().equals(BlockPos.ZERO)) {
            this.setHomeRoof(this.blockPosition());
        }

        this.flightActive = true;
        this.currentFlightTicks = 0;

        // حساب مدة الطيران بالساعات (كل ساعة ماينكرافت = 1000 تيك) حسب جدول السلالات
        int hours = switch (this.getBreed()) {
            case ZAJIL -> (this.getMentally() >= 85) ? (1 + this.random.nextInt(3)) : 1; // 0.5-1 أو 1-3 ساعات
            case RED -> (this.getMentally() >= 80) ? 2 : 1; // ضعيف الدم يتعب وينزل سريعاً
            case TEDDY -> (this.getTheLimit() >= 85) ? (13 + this.random.nextInt(2)) : (7 + this.random.nextInt(6)); // 7-12 ساعة، وحاد 85+ يطير 13+ ساعة
            case KADHMAWI -> 4 + this.random.nextInt(6); // 4-9 ساعات
            case GOLDEN -> 10 + this.random.nextInt(4); // 10-13 ساعة
            case HYBRID_TEDDY_KADHMAWI -> 6 + this.random.nextInt(3); // أقصى طيران 8 ساعات
            case HYBRID_KADHMAWI_GOLDEN -> 11 + this.random.nextInt(3); // حوالي 12 ساعة
            case HYBRID_TEDDY_GOLDEN -> 15; // 15 ساعة
        };
        this.targetFlightDurationTicks = hours * 1000;
    }

    /**
     * فحص احتمالية ضياع الطير أثناء الطيران بناءً على قواعد الجدول (حفظ السطح، الحدة، والريشة 10)
     */
    public boolean checkShouldGetLost(@Nullable Player owner) {
        Breed b = this.getBreed();
        // 1. الزاجل لا يضيع أبداً حتى لو أُطلق من مناطق بعيدة لم يزرها!
        if (b == Breed.ZAJIL) {
            return false;
        }

        // 2. شرط إتمام أيام حفظ السطح لجميع السلالات غير الزاجل
        if (!this.hasCompletedRoofMemory()) {
            notifyOwner(owner, "§c[ضياع طير!] §fطار " + b.arabicName + " قبل إتمام أيام حفظ السطح (" + getMemorizedRoofDays() + "/" + getRequiredRoofDays() + " يوم) وضاع!");
            return true;
        }

        // 3. حساب ضياع المناطق الجديدة للأحمر والكظماوي (يعود بنسبة 80% إذا زار المنطقة مرتين سابقاً)
        double distFromRoof = Math.sqrt(this.blockPosition().distSqr(this.getHomeRoof()));
        if ((b == Breed.RED || b == Breed.KADHMAWI) && distFromRoof > 120.0D) {
            if (this.visitedNewRegionsCount < 2) {
                this.visitedNewRegionsCount++;
                if (this.random.nextFloat() > 0.35F) {
                    notifyOwner(owner, "§c[ضياع في منطقة جديدة!] §fضاع " + b.arabicName + " لأنه لم يزر هذه المنطقة مرتين سابقاً!");
                    return true;
                }
            } else {
                // زارها مرتين سابقاً -> يعود بنسبة 80%
                if (this.random.nextFloat() > 0.80F) {
                    notifyOwner(owner, "§c[ضياع!] §fلم يتمكن " + b.arabicName + " من العودة (احتمال الـ 20%).");
                    return true;
                }
            }
        }

        // 4. حساب الحدة (The Limit) وطفرة الجينات الحادة للتيدي والكولدن (تختفي عند الريشة 10!)
        if (b == Breed.TEDDY) {
            if (this.getTheLimit() >= 85) {
                notifyOwner(owner, "§c[حدة عالية 85+!] §fطار التيدي 13+ ساعة بسبب حدته (" + getTheLimit() + "%) وأرهق وضاع في البند!");
                return true;
            }
            // حدة 84 وتحت: احتمال 45% لتفعيل جينات حادة تضيعه (تختفي عند الريشة 10!)
            if (this.getFeatherStage() < 10 && this.random.nextFloat() < 0.45F) {
                notifyOwner(owner, "§c[جينات حادة!] §fتفعلت طفرة الحدة في التيدي (قبل الريشة 10) فواصل الطيران وضاع!");
                return true;
            }
        } else if (b == Breed.GOLDEN) {
            // الكولدن: نسبة ظهور طفرة الحدة 70% وتختفي عند الريشة 10 فأكبر!
            if (this.getFeatherStage() < 10 && this.getTheLimit() >= 85 && this.random.nextFloat() < 0.70F) {
                notifyOwner(owner, "§c[طفرة حدة الكولدن!] §fتفعلت طفرة الحدة في الكولدن (قبل الريشة 10) وضاع في الغيم!");
                return true;
            }
        }

        return false;
    }

    private void notifyOwner(@Nullable Player owner, String msg) {
        if (owner != null && !this.level().isClientSide) {
            owner.sendSystemMessage(Component.literal(msg));
        }
    }

    /**
     * حساب سلالة الفرخ الناتج عن تزاوج الأبوين (يدعم الهجائن الثلاثة بدقة)
     */
    public static Breed computeOffspringBreed(Breed parentA, Breed parentB) {
        if (parentA == parentB) return parentA;
        if ((parentA == Breed.TEDDY && parentB == Breed.KADHMAWI) || (parentA == Breed.KADHMAWI && parentB == Breed.TEDDY)) {
            return Breed.HYBRID_TEDDY_KADHMAWI;
        }
        if ((parentA == Breed.KADHMAWI && parentB == Breed.GOLDEN) || (parentA == Breed.GOLDEN && parentB == Breed.KADHMAWI)) {
            return Breed.HYBRID_KADHMAWI_GOLDEN;
        }
        if ((parentA == Breed.TEDDY && parentB == Breed.GOLDEN) || (parentA == Breed.GOLDEN && parentB == Breed.TEDDY)) {
            return Breed.HYBRID_TEDDY_GOLDEN;
        }
        return parentA;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "argon_v3_controller", 3, state -> {
            AnimState st = this.getAnimState();
            if (st == AnimState.STARVE_DEATH) {
                return state.setAndContinue(RawAnimation.begin().thenPlayAndHold("animation.argon_pigeon.starve_death"));
            }
            if (st == AnimState.INCUBATE_EGGS) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.incubate_eggs"));
            }
            if (st == AnimState.FEED_SQUAB_ZAQQ) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.feed_squab_zaqq"));
            }
            if (!this.onGround()) {
                if (st == AnimState.FLIGHT_WING_FLIP) {
                    return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.wing_flip_flight"));
                }
                if (st == AnimState.FLIGHT_BAND_CLIMB) {
                    return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.highflyer_band_climb"));
                }
                if (st == AnimState.LANDING_FAN_TAIL) {
                    return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.landing_fan_tail"));
                }
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.flight_flap"));
            }
            if (st == AnimState.EAT_M7) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.eat_m7"));
            }
            if (state.isMoving() || st == AnimState.ROOF_EXPLORE) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.roof_explore_look"));
            }
            return state.setAndContinue(RawAnimation.begin().thenLoop("animation.argon_pigeon.proud_idle"));
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }

    @Override
    public boolean isFlying() {
        return !this.onGround();
    }

    @Override
    public boolean causeFallDamage(float distance, float multiplier, DamageSource source) {
        return false;
    }

    // Getters & Setters
    public Breed getBreed() { return Breed.fromId(this.entityData.get(DATA_BREED)); }
    public void setBreed(Breed b) { this.entityData.set(DATA_BREED, b.id); }

    public AnimState getAnimState() {
        try { return AnimState.valueOf(this.entityData.get(DATA_ANIM_STATE)); }
        catch (Exception e) { return AnimState.IDLE; }
    }
    public void setAnimState(AnimState s) { this.entityData.set(DATA_ANIM_STATE, s.name()); }

    public boolean isMale() { return this.entityData.get(DATA_IS_MALE); }
    public void setMale(boolean male) { this.entityData.set(DATA_IS_MALE, male); }

    public int getMentally() { return this.entityData.get(DATA_MENTALLY); }
    public void setMentally(int m) { this.entityData.set(DATA_MENTALLY, m); }

    public int getTheLimit() { return this.entityData.get(DATA_THE_LIMIT); }
    public void setTheLimit(int l) { this.entityData.set(DATA_THE_LIMIT, l); }

    public int getFeatherStage() { return this.entityData.get(DATA_FEATHER_STAGE); }
    public void setFeatherStage(int f) { this.entityData.set(DATA_FEATHER_STAGE, f); }

    public int getSquabDay() { return this.entityData.get(DATA_SQUAB_DAY); }
    public void setSquabDay(int d) { this.entityData.set(DATA_SQUAB_DAY, d); }

    public int getClippedFeathers() { return this.entityData.get(DATA_CLIPPED_FEATHERS); }
    public void setClippedFeathers(int c) { this.entityData.set(DATA_CLIPPED_FEATHERS, Math.max(0, Math.min(10, c))); }

    public int getLegRingColorIndex() { return this.entityData.get(DATA_LEG_RING_COLOR); }
    public void setLegRingColorIndex(int idx) { this.entityData.set(DATA_LEG_RING_COLOR, idx); }

    public int getHybridSkinVariant() { return this.entityData.get(DATA_HYBRID_SKIN_VARIANT); }

    public BlockPos getHomeRoof() { return this.entityData.get(DATA_HOME_ROOF); }
    public void setHomeRoof(BlockPos pos) { this.entityData.set(DATA_HOME_ROOF, pos); }

    public boolean isFlightActive() { return this.flightActive; }
    public void setFlightActive(boolean active) { this.flightActive = active; }
    public int getCurrentFlightTicks() { return this.currentFlightTicks; }
    public void incrementFlightTicks() { this.currentFlightTicks++; }
    public int getTargetFlightDurationTicks() { return this.targetFlightDurationTicks; }
    public int getAgeMonths() { return Math.max(1, (this.ageTicks / 24000) / 3); }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob mate) {
        ArgonPigeonEntity child = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(level);
        if (child != null && mate instanceof ArgonPigeonEntity other) {
            Breed offspringBreed = computeOffspringBreed(this.getBreed(), other.getBreed());
            child.rollStatsForBreed(offspringBreed);
            if (offspringBreed == Breed.HYBRID_TEDDY_GOLDEN) {
                child.setMentally((this.getMentally() + other.getMentally()) / 2);
                child.setTheLimit((this.getTheLimit() + other.getTheLimit()) / 2);
            }
            child.ageTicks = 24000; // يبدأ كفرخ عمر يوم 1
            child.setSquabDay(1);
            child.setFeatherStage(0);
        }
        return child;
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putString("Breed", this.getBreed().id);
        tag.putBoolean("IsMale", this.isMale());
        tag.putInt("Mentally", this.getMentally());
        tag.putInt("TheLimit", this.getTheLimit());
        tag.putInt("FeatherStage", this.getFeatherStage());
        tag.putInt("SquabDay", this.getSquabDay());
        tag.putInt("ClippedFeathers", this.getClippedFeathers());
        tag.putInt("LegRingColor", this.getLegRingColorIndex());
        tag.putInt("HybridVariant", this.getHybridSkinVariant());
        tag.putInt("AgeTicks", this.ageTicks);
        tag.putInt("RoofMemorizedTicks", this.roofMemorizedTicks);
        tag.putInt("TicksWithoutFood", this.ticksWithoutFood);
        tag.putInt("VisitedRegions", this.visitedNewRegionsCount);
        tag.putInt("RoofX", this.getHomeRoof().getX());
        tag.putInt("RoofY", this.getHomeRoof().getY());
        tag.putInt("RoofZ", this.getHomeRoof().getZ());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        if (tag.contains("Breed")) this.setBreed(Breed.fromId(tag.getString("Breed")));
        if (tag.contains("IsMale")) this.setMale(tag.getBoolean("IsMale"));
        if (tag.contains("Mentally")) this.setMentally(tag.getInt("Mentally"));
        if (tag.contains("TheLimit")) this.setTheLimit(tag.getInt("TheLimit"));
        if (tag.contains("FeatherStage")) this.setFeatherStage(tag.getInt("FeatherStage"));
        if (tag.contains("SquabDay")) this.setSquabDay(tag.getInt("SquabDay"));
        if (tag.contains("ClippedFeathers")) this.setClippedFeathers(tag.getInt("ClippedFeathers"));
        if (tag.contains("LegRingColor")) this.setLegRingColorIndex(tag.getInt("LegRingColor"));
        if (tag.contains("HybridVariant")) this.entityData.set(DATA_HYBRID_SKIN_VARIANT, tag.getInt("HybridVariant"));
        this.ageTicks = tag.getInt("AgeTicks");
        this.roofMemorizedTicks = tag.getInt("RoofMemorizedTicks");
        this.ticksWithoutFood = tag.getInt("TicksWithoutFood");
        this.visitedNewRegionsCount = tag.getInt("VisitedRegions");
        if (tag.contains("RoofX")) {
            this.setHomeRoof(new BlockPos(tag.getInt("RoofX"), tag.getInt("RoofY"), tag.getInt("RoofZ")));
        }
    }
}
