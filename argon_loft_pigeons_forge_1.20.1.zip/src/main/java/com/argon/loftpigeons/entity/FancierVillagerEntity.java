package com.argon.loftpigeons.entity;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.AgeableMob;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.LookAtTradingPlayerGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.TradeWithPlayerGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.npc.AbstractVillager;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.trading.MerchantOffer;
import net.minecraft.world.item.trading.MerchantOffers;
import net.minecraft.world.level.Level;
import net.minecraftforge.registries.RegistryObject;
import org.jetbrains.annotations.Nullable;
import software.bernie.geckolib.animatable.GeoEntity;
import software.bernie.geckolib.core.animatable.instance.AnimatableInstanceCache;
import software.bernie.geckolib.core.animation.*;
import software.bernie.geckolib.util.GeckoLibUtil;

/**
 * قروي الطيور الخاص (Fancier Villager):
 * - مجسم 3D مميز يشبه قرويي ماينكرافت مع حمامة على كتفه ورداء الجناي.
 * - يتواجد في جميع بايومات القرى.
 * - يبيع الدخن بـ 1 دينمي، وبيوض الطيور حسب قوتها (المتوسطة بدينمي أقل، والقوية بدينمي أكثر)، وكل مستلزمات الطيور.
 */
public class FancierVillagerEntity extends AbstractVillager implements GeoEntity {
    private final AnimatableInstanceCache cache = GeckoLibUtil.createInstanceCache(this);

    public FancierVillagerEntity(EntityType<? extends AbstractVillager> type, Level level) {
        super(type, level);
    }

    public static AttributeSupplier.Builder createAttributes() {
        return AbstractVillager.createMobAttributes()
                .add(Attributes.MAX_HEALTH, 20.0D)
                .add(Attributes.MOVEMENT_SPEED, 0.30D)
                .add(Attributes.FOLLOW_RANGE, 48.0D);
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new TradeWithPlayerGoal(this));
        this.goalSelector.addGoal(1, new LookAtTradingPlayerGoal(this));
        this.goalSelector.addGoal(2, new WaterAvoidingRandomStrollGoal(this, 0.6D));
        this.goalSelector.addGoal(3, new LookAtPlayerGoal(this, Player.class, 8.0F));
        this.goalSelector.addGoal(4, new RandomLookAroundGoal(this));
    }

    @Override
    public Component getDisplayName() {
        return Component.literal("§bقروي ومربي الطيور (تاجر الدينمي)");
    }

    @Override
    public InteractionResult mobInteract(Player player, InteractionHand hand) {
        if (this.isAlive() && !this.isTrading() && !this.isBaby()) {
            if (!this.level().isClientSide) {
                if (this.getOffers().isEmpty()) {
                    this.updateTrades();
                }
                this.setTradingPlayer(player);
                this.openTradingScreen(player, this.getDisplayName(), 1);
            }
            return InteractionResult.sidedSuccess(this.level().isClientSide);
        }
        return super.mobInteract(player, hand);
    }

    @Override
    protected void updateTrades() {
        MerchantOffers offers = this.getOffers();
        Item dynami = ArgonLoftPigeonsMod.RAW_PIGEON_GEM.get(); // معدن الدينمي

        // 1. طعام الطيور (الدخن): بـ 1 دينمي فقط!
        offers.add(new MerchantOffer(
                new ItemStack(dynami, 1),
                new ItemStack(ArgonLoftPigeonsMod.M7_GRAIN_HANDFUL.get(), 8),
                64, 2, 0.02F));
        offers.add(new MerchantOffer(
                new ItemStack(dynami, 1),
                new ItemStack(ArgonLoftPigeonsMod.M7_FEED_BAG.get(), 2),
                32, 2, 0.02F));

        // 2. بيوض الطيور المتوسطة أو تحت المتوسطة (دينمي أقل: 2 إلى 3 دينمي)
        offers.add(new MerchantOffer(
                new ItemStack(dynami, 2),
                new ItemStack(ArgonLoftPigeonsMod.RED_EGG.get(), 1),
                16, 5, 0.05F));
        offers.add(new MerchantOffer(
                new ItemStack(dynami, 3),
                new ItemStack(ArgonLoftPigeonsMod.KADHMAWI_EGG.get(), 1),
                16, 5, 0.05F));

        // 3. بيضة الزاجل الرياضي (متوسط-قوي: 5 دينمي)
        offers.add(new MerchantOffer(
                new ItemStack(dynami, 5),
                new ItemStack(ArgonLoftPigeonsMod.ZAJIL_EGG.get(), 1),
                16, 8, 0.05F));

        // 4. بيوض الطيور القوية والعالية (التيدي والكولدن: دينمي أكثر 8 إلى 10 دينمي)
        offers.add(new MerchantOffer(
                new ItemStack(dynami, 8),
                new ItemStack(ArgonLoftPigeonsMod.TEDDY_EGG.get(), 1),
                12, 12, 0.05F));
        offers.add(new MerchantOffer(
                new ItemStack(dynami, 10),
                new ItemStack(ArgonLoftPigeonsMod.GOLDEN_EGG.get(), 1),
                12, 15, 0.05F));

        // 5. بيوض الهجائن القوية والنادرة (12 إلى 16 دينمي)
        offers.add(new MerchantOffer(
                new ItemStack(dynami, 12),
                new ItemStack(ArgonLoftPigeonsMod.HYBRID_TEDDY_KADHMAWI_EGG.get(), 1),
                8, 20, 0.05F));
        offers.add(new MerchantOffer(
                new ItemStack(dynami, 14),
                new ItemStack(ArgonLoftPigeonsMod.HYBRID_KADHMAWI_GOLDEN_EGG.get(), 1),
                8, 20, 0.05F));
        offers.add(new MerchantOffer(
                new ItemStack(dynami, 16),
                new ItemStack(ArgonLoftPigeonsMod.HYBRID_TEDDY_GOLDEN_EGG.get(), 1),
                8, 25, 0.05F));

        // 6. جميع مستلزمات الطيور (العش 3D، خانة التزاوج، المعلف، البطاقة، المقص، الشبكة، القماشة السوداء، البرج، والحلقات)
        offers.add(new MerchantOffer(new ItemStack(dynami, 2), new ItemStack(ArgonLoftPigeonsMod.COPPER_NEST_BOWL_ITEM.get(), 1), 16, 4, 0.02F));
        offers.add(new MerchantOffer(new ItemStack(dynami, 2), new ItemStack(ArgonLoftPigeonsMod.PIGEON_FEEDER_ITEM.get(), 1), 16, 4, 0.02F));
        offers.add(new MerchantOffer(new ItemStack(dynami, 4), new ItemStack(ArgonLoftPigeonsMod.BREEDING_BOX_ITEM.get(), 1), 12, 6, 0.02F));
        offers.add(new MerchantOffer(new ItemStack(dynami, 1), new ItemStack(ArgonLoftPigeonsMod.CERTIFICATE_ITEM.get(), 2), 24, 2, 0.02F));
        offers.add(new MerchantOffer(new ItemStack(dynami, 2), new ItemStack(ArgonLoftPigeonsMod.PIGEON_SCISSORS.get(), 1), 12, 4, 0.02F));
        offers.add(new MerchantOffer(new ItemStack(dynami, 2), new ItemStack(ArgonLoftPigeonsMod.CATCH_NET.get(), 1), 12, 4, 0.02F));
        offers.add(new MerchantOffer(new ItemStack(dynami, 1), new ItemStack(ArgonLoftPigeonsMod.BLACK_CLOTH.get(), 1), 12, 4, 0.02F));
        offers.add(new MerchantOffer(new ItemStack(ArgonLoftPigeonsMod.DYNAMI_BLOCK_ITEM.get(), 1), new ItemStack(ArgonLoftPigeonsMod.LOFT_BUILDER_20X10.get(), 1), 8, 15, 0.05F));

        for (RegistryObject<Item> ringObj : ArgonLoftPigeonsMod.LEG_RINGS) {
            offers.add(new MerchantOffer(new ItemStack(dynami, 1), new ItemStack(ringObj.get(), 4), 32, 1, 0.02F));
        }
    }

    @Override
    protected void rewardTradeXp(MerchantOffer offer) {
    }

    @Nullable
    @Override
    public AgeableMob getBreedOffspring(ServerLevel level, AgeableMob other) {
        return null;
    }

    @Override
    protected SoundEvent getAmbientSound() {
        return SoundEvents.VILLAGER_AMBIENT;
    }

    @Override
    public void registerControllers(AnimatableManager.ControllerRegistrar controllers) {
        controllers.add(new AnimationController<>(this, "villager_controller", 4, state -> {
            if (state.isMoving()) {
                return state.setAndContinue(RawAnimation.begin().thenLoop("animation.fancier_villager.walk"));
            }
            return state.setAndContinue(RawAnimation.begin().thenLoop("animation.fancier_villager.idle"));
        }));
    }

    @Override
    public AnimatableInstanceCache getAnimatableInstanceCache() {
        return this.cache;
    }
}
