package com.argon.loftpigeons.entity.ai;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * ذكاء اصطناعي مخصص وعالي الأولوية لأكل الدخن 3D والمعالف:
 * يضمن أنه بمجرد أن ينثر اللاعب الدخن على الأرض (أو يراه الطير في أي مكان)،
 * يهرول الطير نحوه مباشرة، ينقر الحبوب بأنيميشن الأكل الواقعي، ويستهلكها.
 */
public class EatDukhnGoal extends Goal {
    private final ArgonPigeonEntity pigeon;
    private BlockPos targetDukhnPos = null;
    private int peckTicks = 0;

    public EatDukhnGoal(ArgonPigeonEntity pigeon) {
        this.pigeon = pigeon;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (pigeon.isFlightActive()) return false;
        if (pigeon.tickCount % 8 != 0 && targetDukhnPos == null) return false;
        this.targetDukhnPos = findNearestDukhnOrFeeder(12);
        return this.targetDukhnPos != null;
    }

    @Override
    public boolean canContinueToUse() {
        if (pigeon.isFlightActive() || this.targetDukhnPos == null) return false;
        BlockState st = pigeon.level().getBlockState(this.targetDukhnPos);
        boolean stillValid = st.is(ArgonLoftPigeonsMod.DUKHN_PILE.get()) || st.is(ArgonLoftPigeonsMod.PIGEON_FEEDER.get());
        return stillValid && this.peckTicks < 55;
    }

    @Override
    public void start() {
        this.peckTicks = 0;
        if (this.targetDukhnPos != null) {
            pigeon.getNavigation().moveTo(
                    this.targetDukhnPos.getX() + 0.5D,
                    this.targetDukhnPos.getY(),
                    this.targetDukhnPos.getZ() + 0.5D,
                    1.05D
            );
        }
    }

    @Override
    public void tick() {
        if (this.targetDukhnPos == null) return;

        Vec3 targetCenter = new Vec3(
                this.targetDukhnPos.getX() + 0.5D,
                this.targetDukhnPos.getY() + 0.1D,
                this.targetDukhnPos.getZ() + 0.5D
        );
        pigeon.getLookControl().setLookAt(targetCenter.x, targetCenter.y, targetCenter.z);

        double distSq = pigeon.position().distanceToSqr(targetCenter);
        if (distSq > 1.65D) {
            // تحريك أرضي مباشر + مسار الملاحة لضمان عدم توقف الطير أبداً في منتصف الطريق
            pigeon.getNavigation().moveTo(targetCenter.x, targetCenter.y, targetCenter.z, 1.05D);
            Vec3 step = targetCenter.subtract(pigeon.position()).normalize().scale(0.14D);
            pigeon.setDeltaMovement(step.x, pigeon.onGround() ? 0.0D : pigeon.getDeltaMovement().y, step.z);
            float yaw = (float) (Math.atan2(step.z, step.x) * (180.0D / Math.PI)) - 90.0F;
            pigeon.setYRot(yaw);
            pigeon.yBodyRot = yaw;
            pigeon.setAnimState(ArgonPigeonEntity.AnimState.ROOF_EXPLORE);
        } else {
            // وصل إلى الدخن -> يبدأ نقر وأكل حبيبات الدخن 3D!
            pigeon.getNavigation().stop();
            pigeon.setDeltaMovement(0.0D, pigeon.getDeltaMovement().y, 0.0D);
            pigeon.setAnimState(ArgonPigeonEntity.AnimState.EAT_M7);
            this.peckTicks++;

            if (this.peckTicks % 10 == 0) {
                pigeon.level().playSound(null, this.targetDukhnPos, SoundEvents.PARROT_EAT, SoundSource.NEUTRAL, 0.8F, 1.2F);
                if (pigeon.level() instanceof ServerLevel serverLevel) {
                    serverLevel.sendParticles(
                            new BlockParticleOption(ParticleTypes.BLOCK, Blocks.HAY_BLOCK.defaultBlockState()),
                            targetCenter.x, targetCenter.y + 0.15D, targetCenter.z,
                            6, 0.15D, 0.08D, 0.15D, 0.03D
                    );
                }
            }

            if (this.peckTicks >= 40) {
                pigeon.feedM7();
                if (pigeon.level() instanceof ServerLevel serverLevel) {
                    serverLevel.sendParticles(
                            ParticleTypes.HAPPY_VILLAGER,
                            pigeon.getX(), pigeon.getY() + 0.4D, pigeon.getZ(),
                            5, 0.2D, 0.2D, 0.2D, 0.02D
                    );
                }
                if (pigeon.level().getBlockState(this.targetDukhnPos).is(ArgonLoftPigeonsMod.DUKHN_PILE.get())) {
                    pigeon.level().removeBlock(this.targetDukhnPos, false);
                }
                this.targetDukhnPos = null;
            }
        }
    }

    @Override
    public void stop() {
        this.targetDukhnPos = null;
        this.peckTicks = 0;
        if (!pigeon.isFlightActive()) {
            pigeon.setAnimState(ArgonPigeonEntity.AnimState.IDLE);
        }
    }

    private BlockPos findNearestDukhnOrFeeder(int radius) {
        BlockPos origin = pigeon.blockPosition();
        BlockPos best = null;
        double bestDist = Double.MAX_VALUE;

        for (int dx = -radius; dx <= radius; dx++) {
            for (int dy = -2; dy <= 2; dy++) {
                for (int dz = -radius; dz <= radius; dz++) {
                    BlockPos p = origin.offset(dx, dy, dz);
                    BlockState st = pigeon.level().getBlockState(p);
                    if (st.is(ArgonLoftPigeonsMod.DUKHN_PILE.get())) {
                        double d = origin.distSqr(p);
                        if (d < bestDist) {
                            bestDist = d;
                            best = p;
                        }
                    } else if (st.is(ArgonLoftPigeonsMod.PIGEON_FEEDER.get()) && pigeon.getTicksWithoutFood() > 1200) {
                        double d = origin.distSqr(p) + 16.0D;
                        if (d < bestDist) {
                            bestDist = d;
                            best = p;
                        }
                    }
                }
            }
        }
        return best;
    }
}
