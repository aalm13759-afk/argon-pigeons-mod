package com.argon.loftpigeons.entity.ai;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * الذكاء الاصطناعي لحياة الطير داخل بناية البرج (20×10×5):
 * يربط سلوك كل طير بتصميم البناية (الوسط، الغرفة اليسرى والركزات، الغرفة اليمنى وخانات التزاوج، وحبيبات الدخن)
 * مع بصمة شخصية مستقلة لكل طير حتى لا تتشابه حركات الطيور داخل البرج أبداً!
 */
public class LoftIndoorLifeGoal extends Goal {
    private final ArgonPigeonEntity pigeon;
    private final int personalitySeed;
    private int actionTimer = 0;
    private BlockPos targetIndoorPos = null;
    private IndoorActivity currentActivity = IndoorActivity.STROLL_LEFT_TO_CENTER;

    private enum IndoorActivity {
        PERCH_ON_RAKZAH,        // القفز والوقوف على الركزات (السبعات) في الجهة اليسرى
        STROLL_LEFT_TO_CENTER,  // التمشي بحرية بين الغرفة اليسرى والبهو الأوسط عبر الباب المفتوح
        EAT_DUKHN_PARTICLES,    // الذهاب لأكل جزيئات الدخن 3D أو المعلف في الوسط
        INSPECT_BREEDING_BOXES, // اقتراب الفحول والأزواج من خانات التزاوج الـ 8 في الجهة اليمنى
        PREEN_AND_LOOK_AROUND   // التوقف لتفلي الريش والالتفات بزوايا وسرعات مختلفة لكل طير
    }

    public LoftIndoorLifeGoal(ArgonPigeonEntity pigeon) {
        this.pigeon = pigeon;
        this.personalitySeed = Math.abs(pigeon.getUUID().hashCode());
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (pigeon.isFlightActive() || pigeon.getSquabDay() > 0) return false;
        // يعمل عندما يكون الطير داخل بناية البرج (تحت سقف البرج أو بالقرب من المعالف والركزات)
        return !pigeon.level().canSeeSky(pigeon.blockPosition());
    }

    @Override
    public boolean canContinueToUse() {
        return canUse() && this.actionTimer > 0;
    }

    @Override
    public void start() {
        // مدة ونوع النشاط يختلفان من طير لآخر حسب بصمته الشخصية (personalitySeed)
        this.actionTimer = 40 + (this.personalitySeed % 60) + pigeon.getRandom().nextInt(60);
        pickNextIndividualActivity();
    }

    private void pickNextIndividualActivity() {
        BlockPos origin = pigeon.blockPosition();

        // 1. فحص وجود جزيئات الدخن 3D على الأرض أولاً
        BlockPos dukhnPos = findNearbyBlock(origin, 8, state -> state.is(ArgonLoftPigeonsMod.DUKHN_PILE.get()));
        if (dukhnPos != null && pigeon.getRandom().nextFloat() < 0.55F) {
            this.currentActivity = IndoorActivity.EAT_DUKHN_PARTICLES;
            this.targetIndoorPos = dukhnPos;
            pigeon.getNavigation().moveTo(dukhnPos.getX() + 0.5D, dukhnPos.getY(), dukhnPos.getZ() + 0.5D, 0.95D);
            return;
        }

        int roll = (pigeon.tickCount + this.personalitySeed) % 100;

        // 2. إذا كان الطير غير مقصوص الجناح، يحب القفز على الركزات (السبعات) في الغرفة اليسرى
        if (pigeon.getClippedFeathers() < 3 && roll < 30) {
            BlockPos perchPos = findNearbyBlock(origin, 10, state -> state.getBlock() instanceof StairBlock);
            if (perchPos != null) {
                this.currentActivity = IndoorActivity.PERCH_ON_RAKZAH;
                this.targetIndoorPos = perchPos;
                // يرفرف قفزة قصيرة ليحط فوق الركزة!
                Vec3 jumpVel = Vec3.atCenterOf(perchPos.above()).subtract(pigeon.position()).normalize().scale(0.32D);
                pigeon.setDeltaMovement(jumpVel.x, 0.36D, jumpVel.z);
                return;
            }
        }

        // 3. العبور عبر الباب المفتوح بين الجهة اليسرى والبهو الأوسط
        if (roll < 65) {
            this.currentActivity = IndoorActivity.STROLL_LEFT_TO_CENTER;
            BlockPos openDoor = findNearbyBlock(origin, 9, state ->
                    state.getBlock() instanceof DoorBlock && state.getValue(DoorBlock.OPEN));
            if (openDoor != null && pigeon.getRandom().nextBoolean()) {
                int sideStep = pigeon.getRandom().nextBoolean() ? 3 : -3;
                this.targetIndoorPos = openDoor.offset(sideStep, 0, pigeon.getRandom().nextInt(3) - 1);
            } else {
                this.targetIndoorPos = origin.offset(
                        pigeon.getRandom().nextInt(9) - 4,
                        0,
                        pigeon.getRandom().nextInt(7) - 3
                );
            }
            double individualSpeed = 0.70D + ((this.personalitySeed % 35) * 0.01D);
            pigeon.getNavigation().moveTo(targetIndoorPos.getX() + 0.5D, targetIndoorPos.getY(), targetIndoorPos.getZ() + 0.5D, individualSpeed);
            pigeon.setAnimState(ArgonPigeonEntity.AnimState.ROOF_EXPLORE);
            return;
        }

        // 4. تفقد خانات التزاوج الثمانية في الغرفة اليمنى
        if (roll < 85) {
            BlockPos boxPos = findNearbyBlock(origin, 10, state -> state.is(ArgonLoftPigeonsMod.BREEDING_BOX.get()));
            if (boxPos != null) {
                this.currentActivity = IndoorActivity.INSPECT_BREEDING_BOXES;
                this.targetIndoorPos = boxPos.north();
                pigeon.getNavigation().moveTo(targetIndoorPos.getX() + 0.5D, targetIndoorPos.getY(), targetIndoorPos.getZ() + 0.5D, 0.85D);
                return;
            }
        }

        // 5. وقفة استرخاء وتفلي ريش والتفات مستقل
        this.currentActivity = IndoorActivity.PREEN_AND_LOOK_AROUND;
        this.targetIndoorPos = null;
        pigeon.setAnimState(ArgonPigeonEntity.AnimState.IDLE);
    }

    @Override
    public void tick() {
        this.actionTimer--;

        if (this.currentActivity == IndoorActivity.EAT_DUKHN_PARTICLES && this.targetIndoorPos != null) {
            pigeon.getLookControl().setLookAt(Vec3.atCenterOf(this.targetIndoorPos));
            if (pigeon.blockPosition().distSqr(this.targetIndoorPos) < 2.2D) {
                pigeon.feedM7();
                if (pigeon.level().getBlockState(this.targetIndoorPos).is(ArgonLoftPigeonsMod.DUKHN_PILE.get())
                        && pigeon.getRandom().nextInt(25) == 0) {
                    pigeon.level().removeBlock(this.targetIndoorPos, false);
                }
            }
        } else if (this.currentActivity == IndoorActivity.PREEN_AND_LOOK_AROUND) {
            // كل طير يلتفت بزاوية وتوقيت خاص به حتى لا تتشابه حركاتهم أبداً
            if ((pigeon.tickCount + this.personalitySeed) % 18 == 0) {
                double yawOffset = ((this.personalitySeed % 7) - 3) * 1.5D;
                pigeon.getLookControl().setLookAt(
                        pigeon.getX() + Math.cos(pigeon.tickCount * 0.1D + yawOffset) * 4.0D,
                        pigeon.getY() + 0.6D,
                        pigeon.getZ() + Math.sin(pigeon.tickCount * 0.1D + yawOffset) * 4.0D
                );
            }
        }
    }

    private BlockPos findNearbyBlock(BlockPos center, int radius, java.util.function.Predicate<BlockState> predicate) {
        for (int i = 0; i < 16; i++) {
            int dx = pigeon.getRandom().nextInt(radius * 2 + 1) - radius;
            int dy = pigeon.getRandom().nextInt(5) - 1;
            int dz = pigeon.getRandom().nextInt(radius * 2 + 1) - radius;
            BlockPos check = center.offset(dx, dy, dz);
            if (predicate.test(pigeon.level().getBlockState(check))) {
                return check;
            }
        }
        return null;
    }
}
