package com.argon.loftpigeons.entity.ai;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.List;

/**
 * محرك الطيران المتكامل للسلالات الخمس والهجائن الثلاثة:
 * - يطبق طبيعة طيران كل سلالة (خطي مع قلب الجناح للزاجل، 5-7 دوائر وقلب جناح للأحمر، صعود للبند للتيدي والكولدن والهجائن، طيران متجدد للكظماوي).
 * - يحافظ على مسافات واقعية بين الطيور في السماء لمنع التداخل (Anti-Bunching Separation).
 * - يطبق احتمالات الضياع والعودة بدقة حسب الجدول.
 */
public class PigeonMasterFlightGoal extends Goal {
    private final ArgonPigeonEntity pigeon;
    private double angleRad = 0.0D;
    private double dynamicRadius = 16.0D;
    private double personalSpeedVar = 1.0D;

    public PigeonMasterFlightGoal(ArgonPigeonEntity pigeon) {
        this.pigeon = pigeon;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return pigeon.isFlightActive() && pigeon.getClippedFeathers() < 3 && pigeon.getSquabDay() == 0;
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        pigeon.setNoGravity(true);
        // تنوع المسار في كل تطييرة حتى لا تكرر الطيور نفس الحركة بشكل آلي
        this.angleRad = pigeon.getRandom().nextDouble() * Math.PI * 2.0D;
        this.dynamicRadius = 14.0D + pigeon.getRandom().nextDouble() * 12.0D;
        this.personalSpeedVar = 0.90D + pigeon.getRandom().nextDouble() * 0.25D;
    }

    @Override
    public void tick() {
        pigeon.incrementFlightTicks();
        int ticks = pigeon.getCurrentFlightTicks();
        int maxTicks = pigeon.getTargetFlightDurationTicks();

        BlockPos roof = pigeon.getHomeRoof().equals(BlockPos.ZERO) ? pigeon.blockPosition() : pigeon.getHomeRoof();
        Vec3 roofVec = Vec3.atCenterOf(roof);
        Player owner = (pigeon.getOwner() instanceof Player p) ? p : null;

        // فحص احتمالية الضياع عند منتصف الرحلة
        if (ticks == maxTicks / 2) {
            if (pigeon.checkShouldGetLost(owner)) {
                pigeon.discard();
                return;
            }
        }

        // إذا لم ينتهِ وقت الطيران بعد -> طيران حسب طبيعة السلالة
        if (ticks < maxTicks) {
            executeBreedFlightPattern(roofVec, ticks);
        } else {
            // انتهى الوقت -> نزول وحطّة على السطح
            pigeon.setAnimState(ArgonPigeonEntity.AnimState.LANDING_FAN_TAIL);
            Vec3 landTarget = new Vec3(roofVec.x, roofVec.y + 1.0D, roofVec.z);
            moveWithSeparation(landTarget, 0.30D);
            if (pigeon.position().distanceTo(landTarget) < 2.2D || pigeon.onGround()) {
                pigeon.setNoGravity(false);
                pigeon.setFlightActive(false);
                pigeon.setAnimState(ArgonPigeonEntity.AnimState.IDLE);
            }
        }
    }

    private void executeBreedFlightPattern(Vec3 roofVec, int ticks) {
        ArgonPigeonEntity.Breed breed = pigeon.getBreed();

        switch (breed) {
            case ZAJIL -> {
                // الزاجل: طيران خطي سريع للأمام مع قلب الجناح يميناً ويساراً والعودة فرادى أو مجموعات
                pigeon.setAnimState(ArgonPigeonEntity.AnimState.FLIGHT_WING_FLIP);
                this.angleRad += 0.08D * this.personalSpeedVar;
                double forwardSweep = Math.sin(this.angleRad * 0.5D) * 45.0D;
                double sideWeave = Math.cos(this.angleRad) * 18.0D;
                Vec3 target = new Vec3(roofVec.x + forwardSweep, roofVec.y + 12.0D, roofVec.z + sideWeave);
                moveWithSeparation(target, 0.52D * this.personalSpeedVar);
            }
            case RED -> {
                // الأحمر: يحوم 5-7 دوائر فوق السطح ثم يقلب جناحه لمنطقة قريبة ويعود ليحوم
                double circlesDone = this.angleRad / (Math.PI * 2.0D);
                this.angleRad += 0.065D * this.personalSpeedVar;
                if (circlesDone < 6.0D || (int) (circlesDone / 6.0D) % 2 == 0) {
                    pigeon.setAnimState(ArgonPigeonEntity.AnimState.FLIGHT_NORMAL);
                    double tx = roofVec.x + Math.cos(this.angleRad) * this.dynamicRadius;
                    double tz = roofVec.z + Math.sin(this.angleRad) * this.dynamicRadius;
                    moveWithSeparation(new Vec3(tx, roofVec.y + 24.0D, tz), 0.38D);
                } else {
                    // يقلب جناحه لمنطقة قريبة ثم يعود
                    pigeon.setAnimState(ArgonPigeonEntity.AnimState.FLIGHT_WING_FLIP);
                    double tx = roofVec.x + 65.0D + Math.cos(this.angleRad) * 25.0D;
                    double tz = roofVec.z + 65.0D + Math.sin(this.angleRad) * 25.0D;
                    moveWithSeparation(new Vec3(tx, roofVec.y + 28.0D, tz), 0.44D);
                }
            }
            case KADHMAWI -> {
                // الأبيض الكظماوي: يصعد أحياناً فوق الغيم (دون البند) وأحياناً بمستوى النظر بطيران متجدد
                pigeon.setAnimState(ArgonPigeonEntity.AnimState.FLIGHT_NORMAL);
                this.angleRad += 0.055D * this.personalSpeedVar;
                double waveAlt = (Math.sin(ticks * 0.01D) > 0.2D) ? 195.0D : (roofVec.y + 22.0D);
                double r = this.dynamicRadius + Math.sin(ticks * 0.03D) * 8.0D;
                double tx = roofVec.x + Math.cos(this.angleRad) * r;
                double tz = roofVec.z + Math.sin(this.angleRad) * r;
                moveWithSeparation(new Vec3(tx, waveAlt, tz), 0.36D);
            }
            case TEDDY, GOLDEN, HYBRID_TEDDY_KADHMAWI, HYBRID_KADHMAWI_GOLDEN, HYBRID_TEDDY_GOLDEN -> {
                // يحوم ثم يصعد فوق الغيوم لمرحلة "البند" (Y = 235) بمسارات متغيرة الشكل كل مرة
                pigeon.setAnimState(ArgonPigeonEntity.AnimState.FLIGHT_BAND_CLIMB);
                this.angleRad += 0.09D * this.personalSpeedVar;
                double targetY = Math.min(235.0D, pigeon.getY() + 1.2D);
                if (ticks < 300) {
                    targetY = roofVec.y + 16.0D; // دوائر الإحماء الأولى فوق السطح
                }
                double variedRadius = 9.0D + Math.sin(ticks * 0.02D) * 6.0D;
                double tx = roofVec.x + Math.cos(this.angleRad) * variedRadius;
                double tz = roofVec.z + Math.sin(this.angleRad) * variedRadius;
                moveWithSeparation(new Vec3(tx, targetY, tz), 0.42D);
            }
        }
    }

    /**
     * يحرك الطير نحو الهدف مع ترك مسافات واقعية بين الطيور الطائرة حتى لا تتداخل ببعضها!
     */
    private void moveWithSeparation(Vec3 target, double speed) {
        Vec3 separation = Vec3.ZERO;
        List<ArgonPigeonEntity> nearby = pigeon.level().getEntitiesOfClass(
                ArgonPigeonEntity.class,
                pigeon.getBoundingBox().inflate(3.5D),
                other -> other != pigeon && !other.onGround()
        );
        for (ArgonPigeonEntity other : nearby) {
            Vec3 away = pigeon.position().subtract(other.position());
            double d = Math.max(0.2D, away.length());
            separation = separation.add(away.normalize().scale(1.2D / d));
        }

        Vec3 desired = target.subtract(pigeon.position()).normalize().scale(speed).add(separation.scale(0.12D));
        pigeon.setDeltaMovement(desired);
        float yaw = (float) (Math.atan2(desired.z, desired.x) * (180D / Math.PI)) - 90.0F;
        pigeon.setYRot(yaw);
        pigeon.yBodyRot = yaw;
    }
}
