package com.argon.loftpigeons.entity.ai;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.List;

/**
 * محرك الطيران الجماعي المتقدم (Flocking Boids AI + 20 Flight Mechanics للأحمر والزاجل):
 * 1. القوانين البرمجية الثلاثة (Boids):
 *    - التماسك (Cohesion): ينجذب الطير إلى مركز تجمع الطيور القريبة ليطيروا ككتلة واحدة (طائف).
 *    - المحاذاة (Alignment): يتجه الطير بنفس زاوية وسرعة الطيور التي بجانبه بسلاسة.
 *    - التجنب (Separation): يحافظ على مسافة أمان (0.5 - 1.0 بلوكة) لمنع تداخل المجسمات.
 * 2. مسار الدوامات التصاعدية (Looping & Thermal Soaring):
 *    - يدور حول نقطة الـ Home Anchor بنصف قطر يتسع تدريجياً من 15 إلى 40 بلوكة.
 *    - يرتفع بمعدل (Y + 0.1 لكل تيك) حتى يصل لارتفاع شاهق (100+ بلوكة فوق البرج) ثم يتحول إلى الحوم (Gliding).
 * 3. ميكانيكية النزول والرجوع (The Landing / Trapping Mechanic - الخشّاش):
 *    - عند إطلاق اللاعب إشارة النزول أو رؤية طير على الأرض/اليد، ينزل الطائف بهبوط حلزوني (Spiral Descent).
 *    - تزداد سرعة الهبوط كلما اقترب من البرج، وفي آخر 3 بلوكات يفتح أجنحته بالكامل كمظلة (LANDING_FAN_TAIL) ويبطئ ليحط بسلاسة.
 * 4. ميكانيكية الصيد والمناوشة (The Merge & Straying - المشيور):
 *    - عند التقاء مجموعتين في السماء، تندمجان في دائرة واحدة كبيرة (The Merge).
 *    - عند النزول، توجد احتمالية أن يتبع طير من اللاعب الأول مجموعة اللاعب الثاني وينزل في برجه (مشيور / صيد)!
 * 5. 20 ميكانيكية طيران متغيرة يومياً للأحمر والزاجل حتى لا يطير الطير نفس الطيران كل يوم!
 */
public class PigeonMasterFlightGoal extends Goal {
    private final ArgonPigeonEntity pigeon;
    private double orbitAngle = 0.0D;
    private double currentOrbitRadius = 15.0D;
    private double currentAltitudeOffset = 4.0D;
    private double spiralDescentRadius = 28.0D;

    public PigeonMasterFlightGoal(ArgonPigeonEntity pigeon) {
        this.pigeon = pigeon;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return pigeon.isFlightActive() && pigeon.getClippedFeathers() < 3 && pigeon.getSquabDay() == 0;
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        pigeon.setNoGravity(true);
        this.orbitAngle = pigeon.getRandom().nextDouble() * Math.PI * 2.0D;
        this.currentOrbitRadius = 15.0D;
        this.currentAltitudeOffset = 3.0D;
        this.spiralDescentRadius = 30.0D;
    }

    @Override
    public void tick() {
        pigeon.incrementFlightTicks();
        int ticks = pigeon.getCurrentFlightTicks();
        int maxTicks = pigeon.getTargetFlightDurationTicks();

        BlockPos homeAnchorPos = pigeon.getHomeRoof().equals(BlockPos.ZERO) ? pigeon.blockPosition() : pigeon.getHomeRoof();
        Vec3 homeAnchor = Vec3.atCenterOf(homeAnchorPos);
        Player owner = (pigeon.getOwner() instanceof Player p) ? p : null;

        // فحص الضياع في منتصف وقت الطيران
        if (ticks == maxTicks / 2 && !pigeon.isRecallDescending()) {
            if (pigeon.checkShouldGetLost(owner)) {
                pigeon.discard();
                return;
            }
        }

        // تفعيل الهبوط الحلزوني تلقائياً عند انتهاء مدة الطيران أو عند إصدار اللاعب إشارة النزول/الخشّاش
        if (ticks >= maxTicks && !pigeon.isRecallDescending()) {
            pigeon.setRecallDescending(true);
            this.spiralDescentRadius = Math.max(12.0D, this.currentOrbitRadius);
        }

        if (pigeon.isRecallDescending()) {
            executeSpiralDescentAndParachuteLanding(homeAnchor);
        } else {
            executeFlockFlightAndMechanics(homeAnchor, ticks);
        }
    }

    /**
     * 4. ميكانيكية النزول والرجوع (الهبوط الحلزوني Spiral Descent + فتح الأجنحة كمظلة في آخر 3 بلوكات)
     */
    private void executeSpiralDescentAndParachuteLanding(Vec3 homeAnchor) {
        double distY = Math.max(0.0D, pigeon.getY() - (homeAnchor.y + 1.0D));
        double flatDist = Math.hypot(pigeon.getX() - homeAnchor.x, pigeon.getZ() - homeAnchor.z);

        // في آخر 3 بلوكات: يفتح أجنحته وذيله بالكامل كـ "مظلة" ويبطئ سرعته تماماً ليحط بسلاسة!
        if (distY <= 3.0D && flatDist <= 6.0D) {
            pigeon.setAnimState(ArgonPigeonEntity.AnimState.LANDING_FAN_TAIL);
            Vec3 touchDown = new Vec3(homeAnchor.x, homeAnchor.y + 0.8D, homeAnchor.z);
            Vec3 gentleStep = touchDown.subtract(pigeon.position()).normalize().scale(0.11D);
            pigeon.setDeltaMovement(gentleStep.x, -0.07D, gentleStep.z);

            float yaw = (float) (Math.atan2(gentleStep.z, gentleStep.x) * (180.0D / Math.PI)) - 90.0F;
            pigeon.setYRot(yaw);
            pigeon.yBodyRot = yaw;

            if (pigeon.position().distanceTo(touchDown) < 1.35D || pigeon.onGround()) {
                pigeon.setNoGravity(false);
                pigeon.setFlightActive(false);
                pigeon.setRecallDescending(false);
                pigeon.setAnimState(ArgonPigeonEntity.AnimState.IDLE);
            }
            return;
        }

        // الهبوط الحلزوني (Spiral Descent): دوائر لولبية هابطة بأنيميشن الانحدار الحلزوني (SPIRAL_DIVE)!
        pigeon.setAnimState(ArgonPigeonEntity.AnimState.SPIRAL_DIVE);
        this.spiralDescentRadius = Math.max(2.5D, this.spiralDescentRadius - 0.08D);
        double closenessBoost = 1.0D + Math.max(0.0D, (100.0D - distY) / 100.0D) * 0.65D;
        this.orbitAngle += 0.095D * closenessBoost;

        double targetX = homeAnchor.x + Math.cos(this.orbitAngle) * this.spiralDescentRadius;
        double targetZ = homeAnchor.z + Math.sin(this.orbitAngle) * this.spiralDescentRadius;
        double descentRate = Math.min(0.42D, 0.14D * closenessBoost);
        double targetY = Math.max(homeAnchor.y + 1.5D, pigeon.getY() - descentRate);

        Vec3 spiralTarget = new Vec3(targetX, targetY, targetZ);
        applyBoidsMovement(spiralTarget, 0.42D * closenessBoost);
    }

    /**
     * تنفيذ مسار الطيران حسب السلالة + الدوامات التصاعدية + الـ 20 ميكانيكية للأحمر والزاجل + المزيج (The Merge)
     */
    private void executeFlockFlightAndMechanics(Vec3 homeAnchor, int ticks) {
        ArgonPigeonEntity.Breed breed = pigeon.getBreed();

        // 5. ميكانيكية المزيج (The Merge): إذا التقت مجموعتان من برجين مختلفين في السماء، تندمجان في دائرة واحدة كبيرة!
        Vec3 effectiveAnchor = checkSkyFlockMerge(homeAnchor);

        if (breed == ArgonPigeonEntity.Breed.RED || breed == ArgonPigeonEntity.Breed.ZAJIL) {
            executeRedAndZajil20Mechanics(effectiveAnchor, ticks);
        } else if (breed == ArgonPigeonEntity.Breed.KADHMAWI) {
            pigeon.setAnimState(ArgonPigeonEntity.AnimState.FLIGHT_NORMAL);
            this.orbitAngle += 0.06D;
            this.currentOrbitRadius = 18.0D + Math.sin(ticks * 0.025D) * 10.0D;
            double targetY = (Math.sin(ticks * 0.008D) > 0.15D)
                    ? Math.min(effectiveAnchor.y + 85.0D, pigeon.getY() + 0.1D)
                    : (effectiveAnchor.y + 24.0D);
            Vec3 target = new Vec3(
                    effectiveAnchor.x + Math.cos(this.orbitAngle) * this.currentOrbitRadius,
                    targetY,
                    effectiveAnchor.z + Math.sin(this.orbitAngle) * this.currentOrbitRadius
            );
            applyBoidsMovement(target, 0.39D);
        } else {
            // التيدي والكولدن والهجائن: صعود للبند العالي فوق الغيوم
            pigeon.setAnimState(ArgonPigeonEntity.AnimState.FLIGHT_BAND_CLIMB);
            this.orbitAngle += 0.075D;
            this.currentOrbitRadius = 15.0D + Math.min(20.0D, ticks * 0.02D);
            this.currentAltitudeOffset = Math.min(125.0D, this.currentAltitudeOffset + 0.1D);
            Vec3 target = new Vec3(
                    effectiveAnchor.x + Math.cos(this.orbitAngle) * this.currentOrbitRadius,
                    effectiveAnchor.y + this.currentAltitudeOffset,
                    effectiveAnchor.z + Math.sin(this.orbitAngle) * this.currentOrbitRadius
            );
            applyBoidsMovement(target, 0.43D);
        }
    }

    /**
     * تنفيذ الدوامات التصاعدية (15 -> 40 بلوكة، ارتفاع Y + 0.1 لكل تيك حتى 100 بلوكة، ثم الحوم Gliding)
     * مع تنويع المسار وفق إحدى الـ 20 ميكانيكية طيران المخصصة للأحمر والزاجل!
     */
    private void executeRedAndZajil20Mechanics(Vec3 anchor, int ticks) {
        int mech = pigeon.getFlightMechanicId();

        // 1. اتساع نصف القطر تدريجياً من 15 بلوكة إلى 40 بلوكة
        this.currentOrbitRadius = Math.min(40.0D, 15.0D + (ticks * 0.025D));

        // 2. الارتفاع التدريجي بمعدل Y + 0.1 لكل تيك حتى يصل إلى ارتفاع شاهق (100 بلوكة فوق البرج)
        this.currentAltitudeOffset = Math.min(100.0D, this.currentAltitudeOffset + 0.1D);
        boolean atHighThermalCeiling = (this.currentAltitudeOffset >= 99.0D);

        // 3. عند الوصول للارتفاع الأقصى يتحول الطيران إلى "حوم" (Gliding) بحركة أجنحة هادئة
        double baseSpeed = atHighThermalCeiling ? 0.34D : 0.44D;
        this.orbitAngle += (mech % 2 == 0 ? 1.0D : -1.0D) * 0.068D;

        double rx = this.currentOrbitRadius;
        double rz = this.currentOrbitRadius;
        double yMod = 0.0D;
        double xOffset = 0.0D;
        double zOffset = 0.0D;

        // تطبيق البصمة الخاصة لكل ميكانيكية من الـ 20 ميكانيكية للأحمر والزاجل
        switch (mech) {
            case 0 -> { /* الدوامة التصاعدية الكلاسيكية 15 -> 40 */ }
            case 1 -> {
                // الطوق الضيق ثم التوسع المفاجئ
                double burst = (ticks % 400 < 200) ? 0.55D : 1.25D;
                rx *= burst; rz *= burst;
            }
            case 2 -> {
                // الدوران المزدوج على شكل رقم 8 (Figure-8)
                xOffset = Math.sin(this.orbitAngle) * rx;
                zOffset = Math.sin(this.orbitAngle * 2.0D) * (rz * 0.65D);
            }
            case 3 -> {
                // السهم الخطي مع قلب الجناح المزدوج
                pigeon.setAnimState(ArgonPigeonEntity.AnimState.FLIGHT_WING_FLIP);
                xOffset = Math.sin(this.orbitAngle * 0.5D) * (rx * 1.4D);
                zOffset = Math.cos(this.orbitAngle) * 14.0D;
            }
            case 4 -> {
                // الصعود اللولبي العكسي السريع
                rx = 18.0D + (ticks % 300) * 0.07D;
            }
            case 5 -> {
                // الغطسة الهوائية ثم التعلية
                yMod = Math.sin(ticks * 0.04D) * 8.0D;
            }
            case 6 -> {
                // الحوم العالي الثابت فوق التيارات
                rx = 36.0D; rz = 36.0D;
            }
            case 7 -> {
                // المراوغة الجانبية المتزامنة للطائف
                pigeon.setAnimState(ArgonPigeonEntity.AnimState.FLIGHT_WING_FLIP);
                rx += Math.sin(ticks * 0.1D) * 7.0D;
            }
            case 8 -> {
                // الاستطلاع البعيد والرجوع الخاطف
                double recon = (ticks % 600 > 350) ? 55.0D : 0.0D;
                xOffset = recon; zOffset = recon * 0.5D;
            }
            case 9 -> {
                // الدوائر المتداخلة الثلاثية (Cloverleaf)
                double clover = 1.0D + 0.35D * Math.cos(3.0D * this.orbitAngle);
                rx *= clover; rz *= clover;
            }
            case 10 -> {
                // خفقان سريع متقطع مع انزلاق
                baseSpeed = (ticks % 80 < 40) ? 0.52D : 0.30D;
            }
            case 11 -> {
                // طيران المطاردة والالتفاف الحاد
                baseSpeed = 0.50D;
                rx *= 0.85D;
            }
            case 12 -> {
                // التعلية العمودية المتدرجة (3 طبقات)
                int tier = (ticks / 300) % 3;
                this.currentAltitudeOffset = 35.0D + tier * 32.0D;
            }
            case 13 -> {
                // المسح البيضاوي الواسع للسطوح
                rx = 42.0D; rz = 22.0D;
            }
            case 14 -> {
                // الانقضاض المموه والارتفاع المفاجئ
                yMod = (ticks % 360 > 260) ? -12.0D : 4.0D;
            }
            case 15 -> {
                // طيران النسق المثلثي المتماسك
                rx = 28.0D; rz = 28.0D;
            }
            case 16 -> {
                // قلب الجناح اليميني واليساري المتناوب
                pigeon.setAnimState((ticks / 30) % 2 == 0
                        ? ArgonPigeonEntity.AnimState.FLIGHT_WING_FLIP
                        : ArgonPigeonEntity.AnimState.FLIGHT_NORMAL);
            }
            case 17 -> {
                // الطواف الحلزوني الواسع مع التيارات
                xOffset = Math.cos(ticks * 0.005D) * 18.0D;
                zOffset = Math.sin(ticks * 0.005D) * 18.0D;
            }
            case 18 -> {
                // مناورة المناوشة والاندماج العالي
                rx = 38.0D; rz = 38.0D;
                baseSpeed = 0.48D;
            }
            default -> {
                // 19: الطيران الاستعراضي المتموج
                yMod = Math.sin(this.orbitAngle * 4.0D) * 5.0D;
            }
        }

        if (mech != 3 && mech != 7 && mech != 16) {
            pigeon.setAnimState(atHighThermalCeiling
                    ? ArgonPigeonEntity.AnimState.THERMAL_GLIDE
                    : ArgonPigeonEntity.AnimState.FLIGHT_NORMAL);
        }

        double targetX = anchor.x + (xOffset != 0.0D ? xOffset : Math.cos(this.orbitAngle) * rx);
        double targetZ = anchor.z + (zOffset != 0.0D ? zOffset : Math.sin(this.orbitAngle) * rz);
        double targetY = anchor.y + this.currentAltitudeOffset + yMod;

        applyBoidsMovement(new Vec3(targetX, targetY, targetZ), baseSpeed);
    }

    /**
     * فحص التقاء مجموعتين من برجين مختلفين في السماء (المزيج - The Merge)
     */
    private Vec3 checkSkyFlockMerge(Vec3 myAnchor) {
        List<ArgonPigeonEntity> skyBirds = pigeon.level().getEntitiesOfClass(
                ArgonPigeonEntity.class,
                pigeon.getBoundingBox().inflate(36.0D),
                other -> other != pigeon && other.isFlightActive() && !other.getHomeRoof().equals(pigeon.getHomeRoof())
        );
        if (!skyBirds.isEmpty()) {
            ArgonPigeonEntity other = skyBirds.get(0);
            Vec3 otherAnchor = Vec3.atCenterOf(other.getHomeRoof());
            // تندمج المجموعتان وتطيران معاً في دائرة واحدة كبيرة بالمنتصف!
            return myAnchor.add(otherAnchor).scale(0.5D);
        }
        return myAnchor;
    }

    /**
     * تطبيق قوانين الطيران الجماعي الثلاثة (Boids Flocking AI):
     * 1. التماسك (Cohesion): الانجذاب لمركز تجمع الطيور القريبة.
     * 2. المحاذاة (Alignment): التوجه بنفس زاوية وسرعة الطيور المجاورة.
     * 3. التجنب (Separation): مسافة أمان (0.5 - 1.0 بلوكة) لمنع تداخل المجسمات.
     */
    private void applyBoidsMovement(Vec3 primaryTarget, double speed) {
        List<ArgonPigeonEntity> flockmates = pigeon.level().getEntitiesOfClass(
                ArgonPigeonEntity.class,
                pigeon.getBoundingBox().inflate(24.0D),
                other -> other != pigeon && !other.onGround()
        );

        Vec3 cohesionSum = Vec3.ZERO;
        Vec3 alignmentSum = Vec3.ZERO;
        Vec3 separationForce = Vec3.ZERO;
        int count = 0;

        for (ArgonPigeonEntity mate : flockmates) {
            double dist = pigeon.position().distanceTo(mate.position());
            cohesionSum = cohesionSum.add(mate.position());
            alignmentSum = alignmentSum.add(mate.getDeltaMovement());
            count++;

            // قانون التجنب (Separation): مسافة أمان لا تقل عن 0.5 إلى 1.1 بلوكة لمنع تداخل المجسمات
            if (dist < 1.25D) {
                Vec3 pushAway = pigeon.position().subtract(mate.position());
                double safeDist = Math.max(0.25D, dist);
                separationForce = separationForce.add(pushAway.normalize().scale(0.95D / safeDist));
            }
        }

        Vec3 toTarget = primaryTarget.subtract(pigeon.position()).normalize().scale(speed);
        Vec3 boidsSteer = toTarget;

        if (count > 0) {
            // قانون التماسك (Cohesion)
            Vec3 centerOfMass = cohesionSum.scale(1.0D / count);
            Vec3 cohesionVec = centerOfMass.subtract(pigeon.position()).normalize().scale(speed * 0.28D);

            // قانون المحاذاة (Alignment)
            Vec3 avgVelocity = alignmentSum.scale(1.0D / count);
            Vec3 alignmentVec = avgVelocity.scale(0.32D);

            boidsSteer = toTarget.scale(0.65D)
                    .add(cohesionVec)
                    .add(alignmentVec)
                    .add(separationForce.scale(0.22D));
        }

        if (boidsSteer.lengthSqr() > 0.0001D) {
            Vec3 finalVel = boidsSteer.normalize().scale(speed);
            pigeon.setDeltaMovement(finalVel);
            float yaw = (float) (Math.atan2(finalVel.z, finalVel.x) * (180.0D / Math.PI)) - 90.0F;
            pigeon.setYRot(yaw);
            pigeon.yBodyRot = yaw;
        }
    }
}
