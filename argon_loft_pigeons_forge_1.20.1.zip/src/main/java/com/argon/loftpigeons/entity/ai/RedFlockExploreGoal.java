package com.argon.loftpigeons.entity.ai;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.List;

public class RedFlockExploreGoal extends Goal {
    private final ArgonPigeonEntity pigeon;
    private double circleRadians = 0.0D;
    private int targetWarmupCircles = 3;
    private Vec3 exploreWaypoint = null;
    private static final int EXPLORATION_DURATION_TICKS = 1200;

    public RedFlockExploreGoal(ArgonPigeonEntity pigeon) {
        this.pigeon = pigeon;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        return pigeon.getBreed() == ArgonPigeonEntity.Breed.RED_AGHAR && pigeon.isLaunchedByOwner();
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        pigeon.setNoGravity(true);
        this.circleRadians = 0.0D;
        this.targetWarmupCircles = 2 + pigeon.getRandom().nextInt(2);
        pigeon.setPhase(ArgonPigeonEntity.FlightPhase.WARMUP_CIRCLES);

        BlockPos home = getHomePos();
        ArgonPigeonEntity leader = findFlockLeader();
        if (leader != null && leader != pigeon && leader.exploreWaypointShared != null) {
            this.exploreWaypoint = leader.exploreWaypointShared;
        } else {
            double angle = pigeon.getRandom().nextDouble() * Math.PI * 2.0D;
            double dist = 140.0D + pigeon.getRandom().nextDouble() * 80.0D;
            double ex = home.getX() + Math.cos(angle) * dist;
            double ez = home.getZ() + Math.sin(angle) * dist;
            int ey = pigeon.level().getHeight(Heightmap.Types.MOTION_BLOCKING, (int) ex, (int) ez) + 32;
            this.exploreWaypoint = new Vec3(ex, ey, ez);
            pigeon.exploreWaypointShared = this.exploreWaypoint;
        }
    }

    @Override
    public void tick() {
        BlockPos home = getHomePos();
        Vec3 homeVec = Vec3.atCenterOf(home);
        double mediumAltY = homeVec.y + 30.0D;
        double totalWarmupRadians = this.targetWarmupCircles * (Math.PI * 2.0D);

        if (this.circleRadians < totalWarmupRadians) {
            pigeon.setPhase(ArgonPigeonEntity.FlightPhase.WARMUP_CIRCLES);
            this.circleRadians += 0.065D;
            double radius = 16.0D;
            double tx = homeVec.x + Math.cos(this.circleRadians) * radius;
            double tz = homeVec.z + Math.sin(this.circleRadians) * radius;
            steerFlockMember(new Vec3(tx, mediumAltY, tz), 0.36D);
            return;
        }

        if (pigeon.getFlightTicks() < EXPLORATION_DURATION_TICKS && this.exploreWaypoint != null) {
            pigeon.setPhase(ArgonPigeonEntity.FlightPhase.RED_FLock_EXPLORING);
            double distToExplore = pigeon.position().distanceTo(this.exploreWaypoint);
            if (distToExplore > 18.0D) {
                steerFlockMember(this.exploreWaypoint, 0.40D);
            } else {
                this.circleRadians += 0.05D;
                double rx = this.exploreWaypoint.x + Math.cos(this.circleRadians) * 22.0D;
                double rz = this.exploreWaypoint.z + Math.sin(this.circleRadians) * 22.0D;
                steerFlockMember(new Vec3(rx, this.exploreWaypoint.y, rz), 0.35D);
            }
            return;
        }

        pigeon.setPhase(ArgonPigeonEntity.FlightPhase.DESCENDING_TO_OWNER);
        double distToHome = Math.hypot(homeVec.x - pigeon.getX(), homeVec.z - pigeon.getZ());
        if (distToHome > 6.0D) {
            steerFlockMember(new Vec3(homeVec.x, mediumAltY, homeVec.z), 0.40D);
        } else {
            steerFlockMember(new Vec3(homeVec.x, homeVec.y + 0.5D, homeVec.z), 0.25D);
            if (pigeon.position().distanceTo(homeVec) < 2.2D || pigeon.onGround()) {
                pigeon.setNoGravity(false);
                pigeon.setLaunchedByOwner(false);
                pigeon.setPhase(ArgonPigeonEntity.FlightPhase.GROUND_IDLE);
            }
        }
    }

    private BlockPos getHomePos() {
        if (!pigeon.getHomeLoft().equals(BlockPos.ZERO)) return pigeon.getHomeLoft();
        LivingEntity owner = pigeon.getOwner();
        return owner != null ? owner.blockPosition() : pigeon.blockPosition();
    }

    private ArgonPigeonEntity findFlockLeader() {
        List<ArgonPigeonEntity> flock = pigeon.level().getEntitiesOfClass(
                ArgonPigeonEntity.class,
                pigeon.getBoundingBox().inflate(24.0D),
                p -> p.getBreed() == ArgonPigeonEntity.Breed.RED_AGHAR
        );
        return flock.isEmpty() ? null : flock.get(0);
    }

    private void steerFlockMember(Vec3 target, double speed) {
        Vec3 delta = target.subtract(pigeon.position());
        if (delta.lengthSqr() > 0.01D) {
            Vec3 vel = delta.normalize().scale(speed);
            pigeon.setDeltaMovement(vel);
            float yaw = (float) (Math.atan2(vel.z, vel.x) * (180D / Math.PI)) - 90.0F;
            pigeon.setYRot(yaw);
            pigeon.yBodyRot = yaw;
        }
    }
}
