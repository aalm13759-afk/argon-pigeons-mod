package com.argon.loftpigeons.entity.ai;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;

/**
 * ذكاء السطح وحفظ المعالم:
 * - يتحرك الطير على السطح باستقلالية ضمن نطاق أقصاه 10 بلوكات.
 * - يصعد تلقائياً على أعلى بلوكة مبنية ليحفظ المعالم المحيطة.
 * - يمشي على حواف البلوكات دون أن ينزل إلى الأرض إذا كان البرج مبنياً فوق سطح منزل.
 */
public class RoofExploreAndMemorizeGoal extends Goal {
    private final ArgonPigeonEntity pigeon;
    private BlockPos targetRoofPos = null;
    private int cooldown = 0;

    public RoofExploreAndMemorizeGoal(ArgonPigeonEntity pigeon) {
        this.pigeon = pigeon;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (!pigeon.onGround() || pigeon.isFlightActive() || pigeon.getSquabDay() > 0) return false;
        if (this.cooldown > 0) {
            this.cooldown--;
            return false;
        }
        this.targetRoofPos = findBestRoofBlockWithin10();
        return this.targetRoofPos != null;
    }

    @Override
    public void start() {
        pigeon.setAnimState(ArgonPigeonEntity.AnimState.ROOF_EXPLORE);
        if (this.targetRoofPos != null) {
            pigeon.getNavigation().moveTo(
                    targetRoofPos.getX() + 0.5D,
                    targetRoofPos.getY() + 1.0D,
                    targetRoofPos.getZ() + 0.5D,
                    0.85D
            );
        }
    }

    @Override
    public void tick() {
        if (this.targetRoofPos == null) return;
        // يلتفت بنظره عشوائياً يميناً ويساراً وللأعلى لحفظ معالم السطح
        if (pigeon.getRandom().nextInt(15) == 0) {
            double lookX = pigeon.getX() + (pigeon.getRandom().nextDouble() - 0.5D) * 12.0D;
            double lookY = pigeon.getY() + 1.5D + pigeon.getRandom().nextDouble() * 6.0D;
            double lookZ = pigeon.getZ() + (pigeon.getRandom().nextDouble() - 0.5D) * 12.0D;
            pigeon.getLookControl().setLookAt(lookX, lookY, lookZ);
        }
        if (pigeon.blockPosition().distSqr(this.targetRoofPos) < 2.2D) {
            this.cooldown = 30 + pigeon.getRandom().nextInt(50);
            this.targetRoofPos = null;
        }
    }

    private BlockPos findBestRoofBlockWithin10() {
        BlockPos center = pigeon.getHomeRoof().equals(BlockPos.ZERO) ? pigeon.blockPosition() : pigeon.getHomeRoof();
        BlockPos bestPos = null;
        int highestY = center.getY() - 1;

        for (int i = 0; i < 12; i++) {
            int dx = pigeon.getRandom().nextInt(21) - 10; // نطاق أقصاه 10 بلوكات
            int dz = pigeon.getRandom().nextInt(21) - 10;
            for (int dy = 4; dy >= -1; dy--) {
                BlockPos check = center.offset(dx, dy, dz);
                // لا ينزل إلى الأرض تحت مستوى السطح!
                if (check.getY() < center.getY() - 1) continue;
                if (!pigeon.level().getBlockState(check).isAir() && pigeon.level().getBlockState(check.above()).isAir()) {
                    if (check.getY() >= highestY || pigeon.getRandom().nextFloat() < 0.35F) {
                        highestY = check.getY();
                        bestPos = check;
                    }
                }
            }
        }
        return bestPos;
    }
}
