package com.argon.loftpigeons.entity.ai;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.level.levelgen.Heightmap;
import net.minecraft.world.phys.Vec3;

import java.util.EnumSet;
import java.util.List;

public class ZajilHomingRaceGoal extends Goal {
    private final ArgonPigeonEntity pigeon;
    private double orbitAngle = 0;

    public ZajilHomingRaceGoal(ArgonPigeonEntity pigeon) {
        this.pigeon = pigeon;
        this.setFlags(EnumSet.of(Flag.MOVE, Flag.LOOK));
    }

    @Override
    public boolean canUse() {
        if (pigeon.getBreed() != ArgonPigeonEntity.Breed.ZAJIL_HOMER) return false;
        BlockPos home = getTargetHomePos();
        if (home.equals(BlockPos.ZERO)) return false;
        double distSqr = pigeon.blockPosition().distSqr(home);
        return pigeon.isLaunchedByOwner() || distSqr > 576.0D;
    }

    @Override
    public boolean canContinueToUse() {
        return canUse();
    }

    @Override
    public void start() {
        pigeon.setNoGravity(true);
        pigeon.setPhase(ArgonPigeonEntity.FlightPhase.ZAJIL_LOW_SPRINT);
        this.orbitAngle = 0;
    }

    @Override
    public void tick() {
        BlockPos home = getTargetHomePos();
        Vec3 currentPos = pigeon.position();
        Vec3 homeVec = Vec3.atCenterOf(home);
        double horizDist = Math.hypot(homeVec.x - currentPos.x, homeVec.z - currentPos.z);

        if (horizDist <= 16.0D && pigeon.getFlightTicks() < 240 && pigeon.isLaunchedByOwner()) {
            orbitAngle += 0.14D;
            int groundY = pigeon.level().getHeight(Heightmap.Types.MOTION_BLOCKING, (int) currentPos.x, (int) currentPos.z);
            double lowAltitudeY = groundY + 9.0D;
            double targetX = homeVec.x + Math.cos(orbitAngle) * 14.0D;
            double targetZ = homeVec.z + Math.sin(orbitAngle) * 14.0D;
            moveFastTowards(new Vec3(targetX, lowAltitudeY, targetZ), 1.25D);
            return;
        }

        if (horizDist > 4.5D) {
            pigeon.setPhase(ArgonPigeonEntity.FlightPhase.ZAJIL_LOW_SPRINT);
            Vec3 dir = new Vec3(homeVec.x - currentPos.x, 0, homeVec.z - currentPos.z).normalize();
            Vec3 flockOffset = computeFlockAlignment();
            double nextX = currentPos.x + dir.x * 8.0D + flockOffset.x;
            double nextZ = currentPos.z + dir.z * 8.0D + flockOffset.z;
            int terrainY = pigeon.level().getHeight(Heightmap.Types.MOTION_BLOCKING, (int) nextX, (int) nextZ);
            double targetY = Math.max(terrainY + 9.0D, homeVec.y + 4.0D);
            moveFastTowards(new Vec3(nextX, targetY, nextZ), 1.35D);
        } else {
            pigeon.setPhase(ArgonPigeonEntity.FlightPhase.DESCENDING_TO_OWNER);
            moveFastTowards(new Vec3(homeVec.x, homeVec.y + 0.5D, homeVec.z), 0.65D);
            if (pigeon.position().distanceTo(homeVec) < 2.2D || pigeon.onGround()) {
                pigeon.setNoGravity(false);
                pigeon.setLaunchedByOwner(false);
                pigeon.setPhase(ArgonPigeonEntity.FlightPhase.GROUND_IDLE);
            }
        }
    }

    private BlockPos getTargetHomePos() {
        if (!pigeon.getHomeLoft().equals(BlockPos.ZERO)) return pigeon.getHomeLoft();
        LivingEntity owner = pigeon.getOwner();
        return owner != null ? owner.blockPosition() : BlockPos.ZERO;
    }

    private Vec3 computeFlockAlignment() {
        List<ArgonPigeonEntity> mates = pigeon.level().getEntitiesOfClass(
                ArgonPigeonEntity.class,
                pigeon.getBoundingBox().inflate(10.0D),
                p -> p != pigeon && p.getBreed() == ArgonPigeonEntity.Breed.ZAJIL_HOMER && !p.onGround()
        );
        if (mates.isEmpty()) return Vec3.ZERO;
        double avgX = 0, avgZ = 0;
        for (ArgonPigeonEntity m : mates) {
            avgX += (m.getX() - pigeon.getX());
            avgZ += (m.getZ() - pigeon.getZ());
        }
        return new Vec3(avgX / mates.size() * 0.15D, 0, avgZ / mates.size() * 0.15D);
    }

    private void moveFastTowards(Vec3 target, double speedMultiplier) {
        Vec3 delta = target.subtract(pigeon.position());
        if (delta.lengthSqr() > 0.01D) {
            Vec3 velocity = delta.normalize().scale(0.42D * speedMultiplier);
            pigeon.setDeltaMovement(velocity);
            float yaw = (float) (Math.atan2(velocity.z, velocity.x) * (180D / Math.PI)) - 90.0F;
            pigeon.setYRot(yaw);
            pigeon.yBodyRot = yaw;
        }
    }
}
