package com.argon.loftpigeons.item;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;

import java.util.List;

/**
 * قطعة القماش السوداء (Black Cloth): تُصنع من 2 صوف أسود.
 * بالضغط كلك يمين يلوّح اللاعب بها وتطير جميع الطيور الموجودة على السطح دفعة واحدة!
 */
public class BlackClothItem extends Item {
    public BlackClothItem(Properties props) {
        super(props);
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BOW;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        player.swing(hand, true); // حركة التلويح بالقماشة السوداء
        if (!level.isClientSide) {
            List<ArgonPigeonEntity> roofPigeons = level.getEntitiesOfClass(
                    ArgonPigeonEntity.class,
                    player.getBoundingBox().inflate(24.0D),
                    p -> p.onGround() && p.getClippedFeathers() < 3
            );
            for (ArgonPigeonEntity p : roofPigeons) {
                p.launchPigeonFlight(player);
            }
            player.displayClientMessage(Component.literal("§8[القماشة السوداء] §fلوّحت بالقماشة السوداء وطار §e" + roofPigeons.size() + " طير §fمن السطح دفعة واحدة!"), true);
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }
}
