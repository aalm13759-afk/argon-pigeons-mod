package com.argon.loftpigeons.item;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.UseAnim;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * القماشة السوداء / راية الإشارة والخشّاش (Black Cloth & Signal Flag):
 * 1- التلويحة الأولى (والطيور على السطح): تطير الطيور في طائف جماعي (Boids Flock) وتعلن ميكانيكية الطيران اليومية (من أصل 20 ميكانيكية).
 * 2- التلويحة الثانية (والطيور في السماء): تعمل كـ "محفز النزول والرجوع (الخشّاش / الإشارة)"، فينزل الطائف بهبوط حلزوني (Spiral Descent) ويفتح مظلة الأجنحة في آخر 3 بلوكات!
 * 3- ميكانيكية الصيد والمناوشة (المشيور): إذا كانت هناك طيور للاعب آخر مندمجة مع طائفك في السماء، فهناك احتمالية أن تنجرف مع حمامك وتنزل في برجك كـ (صيد / مشيور)!
 */
public class BlackClothItem extends Item {
    public BlackClothItem(Properties props) {
        super(props);
    }

    @Override
    public UseAnim getUseAnimation(ItemStack stack) {
        return UseAnim.BOW;
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        player.swing(hand, true);
        if (!level.isClientSide) {
            BlockPos playerRoof = player.blockPosition();

            // فحص ما إذا كانت هناك طيور تطير في السماء حالياً (تفعيل محفز النزول الحلزوني + الصيد/المشيور!)
            List<ArgonPigeonEntity> flyingPigeons = level.getEntitiesOfClass(
                    ArgonPigeonEntity.class,
                    player.getBoundingBox().inflate(180.0D),
                    p -> p.isFlightActive() && !p.isRecallDescending() && p.getCurrentFlightTicks() > 60
            );

            if (!flyingPigeons.isEmpty()) {
                int recalledCount = 0;
                int capturedMashyoorCount = 0;

                // إذا كان اللاعب يحمل بيضة أو شبكة فيها طير في يده الأخرى (الخشّاش)، تزداد قوة الجذب والصيد!
                ItemStack offhand = player.getOffhandItem();
                boolean hasDecoyKhashash = (offhand.getItem() instanceof BreedEggItem) || CatchNetItem.hasCapturedPigeon(offhand);

                for (ArgonPigeonEntity p : flyingPigeons) {
                    boolean isMyBird = p.isOwnedBy(player) || p.getHomeRoof().closerThan(playerRoof, 28.0D);
                    if (isMyBird) {
                        p.triggerRecallSpiralDescent(playerRoof);
                        recalledCount++;
                    } else {
                        // ميكانيكية الصيد والمناوشة (المشيور - The Catch):
                        // احتمالية انجراف طير اللاعب الآخر مع طائفك ونزوله في برجك!
                        float catchChance = hasDecoyKhashash ? 0.55F : 0.35F;
                        if (p.getMentally() < 85) catchChance += 0.20F;
                        if (level.random.nextFloat() < catchChance) {
                            p.tame(player);
                            p.triggerRecallSpiralDescent(playerRoof);
                            capturedMashyoorCount++;
                        }
                    }
                }

                level.playSound(null, playerRoof, SoundEvents.NOTE_BLOCK_FLUTE.value(), SoundSource.PLAYERS, 1.0F, 1.4F);
                player.sendSystemMessage(Component.literal("§b§l[إشارة النزول / الخشّاش] §fأطلقت إشارة النزول! بدأ §e" + recalledCount + " طير §fبالهبوط الحلزوني (Spiral Descent) وفتح المظلة نحو برجك!"));
                if (capturedMashyoorCount > 0) {
                    player.sendSystemMessage(Component.literal("§6§l[صيد / مشيور!] §eاندمج " + capturedMashyoorCount + " طير من الأبراج المجاورة مع طائفك ونزل في برجك كصيد (مشيور)!"));
                }
                return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
            }

            // إذا كانت الطيور على السطح -> إطلاق الطائف في السماء!
            List<ArgonPigeonEntity> roofPigeons = level.getEntitiesOfClass(
                    ArgonPigeonEntity.class,
                    player.getBoundingBox().inflate(26.0D),
                    p -> !p.isFlightActive() && p.getClippedFeathers() < 3
            );

            int sharedDailyMech = (int) (((level.getDayTime() / 24000L) * 7L + level.random.nextInt(20)) % 20);
            for (ArgonPigeonEntity p : roofPigeons) {
                p.launchPigeonFlight(player);
                p.setFlightMechanicId(sharedDailyMech);
            }

            if (!roofPigeons.isEmpty()) {
                String mechName = ArgonPigeonEntity.RED_ZAJIL_20_MECHANICS[sharedDailyMech];
                player.sendSystemMessage(Component.literal("§8§l[إطلاق الطائف] §fطار §e" + roofPigeons.size() + " طير §fككتلة واحدة (Flocking AI)!"));
                player.sendSystemMessage(Component.literal("§6• ميكانيكية طيران اليوم: §f" + mechName));
                player.sendSystemMessage(Component.literal("§7(لوّح بالقماشة مرة ثانية في أي وقت لإعطاء إشارة الهبوط الحلزوني والخشّاش)"));
            } else {
                player.displayClientMessage(Component.literal("§c[تنبيه] §fلا توجد طيور بالغة غير مقصوصة قريبة على السطح لتطييرها!"), true);
            }
        }
        return InteractionResultHolder.sidedSuccess(player.getItemInHand(hand), level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§eالتلويحة 1: §fإطلاق حمام السطح في طائف جماعي (20 ميكانيكية طيران)."));
        tooltip.add(Component.literal("§bالتلويحة 2: §fإشارة النزول والخشّاش (هبوط حلزوني + صيد المشيور)."));
    }
}
