package com.argon.loftpigeons.item;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * بيضة الطير ثلاثية الأبعاد:
 * - عند وضعها على الأرض (كلك يمين) أو رميها على الأرض تفقس وتنكسر من وحدها!
 * - يخرج منها الفرخ حديث الولادة (اليوم 1) ويكبر شكله وحجمه كل يوم على مدار 5 أيام ماينكرافتية!
 */
public class BreedEggItem extends Item {
    private final ArgonPigeonEntity.Breed breed;
    public final int primaryColor;
    public final int secondaryColor;

    public BreedEggItem(ArgonPigeonEntity.Breed breed, int primaryColor, int secondaryColor, Properties props) {
        super(props);
        this.breed = breed;
        this.primaryColor = primaryColor;
        this.secondaryColor = secondaryColor;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (!level.isClientSide) {
            BlockPos spawnPos = ctx.getClickedPos().relative(ctx.getClickedFace());
            crackAndHatchEgg(level, spawnPos.getX() + 0.5D, spawnPos.getY(), spawnPos.getZ() + 0.5D, ctx.getItemInHand(), ctx.getPlayer());
            if (ctx.getPlayer() == null || !ctx.getPlayer().getAbilities().instabuild) {
                ctx.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /**
     * إذا رمى اللاعب البيضة على الأرض، تفقس وتنكسر وحدها تلقائياً بعد ثانيتين على الأرض!
     */
    @Override
    public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
        if (!entity.level().isClientSide && entity.onGround() && entity.getAge() >= 40) {
            Player nearest = entity.level().getNearestPlayer(entity, 16.0D);
            for (int i = 0; i < stack.getCount(); i++) {
                crackAndHatchEgg(entity.level(), entity.getX(), entity.getY(), entity.getZ(), stack, nearest);
            }
            entity.discard();
            return true;
        }
        return super.onEntityItemUpdate(stack, entity);
    }

    public void spawnPigeonAt(Level level, BlockPos pos, @Nullable Player player) {
        crackAndHatchEgg(level, pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D, new ItemStack(this), player);
    }

    public void crackAndHatchEgg(Level level, double x, double y, double z, ItemStack visualStack, @Nullable Player player) {
        // مؤثرات انكسار قشر البيضة وصوت الفقس الواقعي
        level.playSound(null, BlockPos.containing(x, y, z), SoundEvents.TURTLE_EGG_CRACK, SoundSource.NEUTRAL, 1.0F, 1.2F);
        level.playSound(null, BlockPos.containing(x, y, z), SoundEvents.TURTLE_EGG_HATCH, SoundSource.NEUTRAL, 1.0F, 1.0F);
        if (level instanceof ServerLevel sl) {
            sl.sendParticles(
                    new ItemParticleOption(ParticleTypes.ITEM, visualStack.isEmpty() ? new ItemStack(this) : visualStack.copy()),
                    x, y + 0.25D, z,
                    24, 0.2D, 0.2D, 0.2D, 0.08D
            );
        }

        ArgonPigeonEntity pigeon = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(level);
        if (pigeon != null) {
            pigeon.rollStatsForBreed(this.breed);
            pigeon.startAsNewbornSquab(); // يفقس كفرخ يوم 1 ويكبر على مدار 5 أيام ماينكرافتية!
            pigeon.setPos(x, y, z);
            pigeon.setHomeRoof(BlockPos.containing(x, y, z));
            if (player != null) {
                pigeon.tame(player);
                player.displayClientMessage(Component.literal("§a§l[فقس البيضة!] §fانكسرت البيضة على الأرض وخرج فرخ §e" + this.breed.arabicName + " §f(سيكبر كل يوم لمدة 5 أيام ماينكرافتية)!"), true);
            }
            level.addFreshEntity(pigeon);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§eالسلالة: §f" + this.breed.arabicName));
        tooltip.add(Component.literal("§aضع البيضة أو ارمها على الأرض لتنكسر وتفقس وحدها!"));
        tooltip.add(Component.literal("§7يكبر الطير تدريجياً كل يوم على مدار 5 أيام ماينكرافتية."));
    }
}
