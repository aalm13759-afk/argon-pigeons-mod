package com.argon.loftpigeons.item;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ItemParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class BreedEggItem extends Item {
    private final ArgonPigeonEntity.Breed breed;
    public final int primaryColor;
    public final int secondaryColor;

    public BreedEggItem(ArgonPigeonEntity.Breed breed, int primaryColor, int secondaryColor, Properties props) {
        super(props);
        this.breed = breed;
        this.primaryColor = primaryColor;
        this.secondaryColor = secondaryColor;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (!level.isClientSide) {
            BlockPos spawnPos = ctx.getClickedPos().relative(ctx.getClickedFace());
            // عند وضع البيضة باليد على السطح أو الأرض: يرسبن الطير جاهزاً للطيران بشكله الأصلي الكامل!
            spawnPigeonAt(level, spawnPos, ctx.getPlayer());
            if (ctx.getPlayer() == null || !ctx.getPlayer().getAbilities().instabuild) {
                ctx.getItemInHand().shrink(1);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    /**
     * عندما يخرج اللاعب البيضة من العش ويرميها على الأرض (Q)، تفقس وتنكسر وحدها ويخرج منها الفرخ الذي يكبر كل يوم على مدار 5 أيام!
     */
    @Override
    public boolean onEntityItemUpdate(ItemStack stack, ItemEntity entity) {
        if (!entity.level().isClientSide && entity.onGround() && entity.getAge() >= 35) {
            Player nearest = entity.level().getNearestPlayer(entity, 16.0D);
            for (int i = 0; i < stack.getCount(); i++) {
                crackAndHatchSquabOnGround(entity.level(), entity.getX(), entity.getY(), entity.getZ(), stack, nearest);
            }
            entity.discard();
            return true;
        }
        return super.onEntityItemUpdate(stack, entity);
    }

    public void spawnPigeonAt(Level level, BlockPos pos, @Nullable Player player) {
        ArgonPigeonEntity pigeon = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(level);
        if (pigeon != null) {
            pigeon.rollStatsForBreed(this.breed);
            pigeon.setSquabDay(0); // بالغ وجاهز للطيران فوراً!
            pigeon.setFeatherStage(1);
            pigeon.setPos(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
            pigeon.setHomeRoof(pos);
            if (player != null) {
                pigeon.tame(player);
            }
            level.addFreshEntity(pigeon);
        }
    }

    public void crackAndHatchSquabOnGround(Level level, double x, double y, double z, ItemStack visualStack, @Nullable Player player) {
        level.playSound(null, BlockPos.containing(x, y, z), SoundEvents.TURTLE_EGG_CRACK, SoundSource.NEUTRAL, 1.0F, 1.2F);
        level.playSound(null, BlockPos.containing(x, y, z), SoundEvents.TURTLE_EGG_HATCH, SoundSource.NEUTRAL, 1.0F, 1.0F);
        if (level instanceof ServerLevel sl) {
            sl.sendParticles(
                    new ItemParticleOption(ParticleTypes.ITEM, visualStack.isEmpty() ? new ItemStack(this) : visualStack.copy()),
                    x, y + 0.25D, z,
                    24, 0.2D, 0.2D, 0.2D, 0.08D
            );
        }

        ArgonPigeonEntity pigeon = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(level);
        if (pigeon != null) {
            pigeon.rollStatsForBreed(this.breed);
            pigeon.startAsNewbornSquab(); // يبدأ من اليوم 1 ويكبر حجمه كل يوم لمدة 5 أيام ماينكرافتية!
            pigeon.setPos(x, y, z);
            pigeon.setHomeRoof(BlockPos.containing(x, y, z));
            if (player != null) {
                pigeon.tame(player);
                player.displayClientMessage(Component.literal("§a§l[فقس البيضة!] §fانكسرت البيضة على الأرض وخرج فرخ §e" + this.breed.arabicName + " §f(يكبر كل يوم لمدة 5 أيام)!"), true);
            }
            level.addFreshEntity(pigeon);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§eالسلالة: §f" + this.breed.arabicName));
        tooltip.add(Component.literal("§aكلك يمين على الأرض: §fيرسبن الطير البالغ الجاهز للطيران."));
        tooltip.add(Component.literal("§bرمي البيضة على الأرض (Q): §fتنكسر وتفقس وحدها لفرخ يكبر خلال 5 أيام."));
    }
}
