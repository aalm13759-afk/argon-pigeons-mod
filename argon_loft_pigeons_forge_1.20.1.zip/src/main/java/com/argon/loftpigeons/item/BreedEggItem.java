package com.argon.loftpigeons.item;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class BreedEggItem extends Item {
    private final ArgonPigeonEntity.Breed breed;
    public final int primaryColor;
    public final int secondaryColor;

    public BreedEggItem(ArgonPigeonEntity.Breed breed, int primaryColor, int secondaryColor, Properties props) {
        super(props);
        this.breed = breed;
        this.primaryColor = primaryColor;
        this.secondaryColor = secondaryColor;
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (!level.isClientSide) {
            BlockPos spawnPos = ctx.getClickedPos().relative(ctx.getClickedFace());
            spawnPigeonAt(level, spawnPos, ctx.getPlayer());
            ctx.getItemInHand().shrink(1);
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    public void spawnPigeonAt(Level level, BlockPos pos, @Nullable Player player) {
        ArgonPigeonEntity pigeon = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(level);
        if (pigeon != null) {
            pigeon.rollStatsForBreed(this.breed);
            pigeon.setPos(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
            pigeon.setHomeRoof(pos);
            if (player != null) {
                pigeon.tame(player);
            }
            level.addFreshEntity(pigeon);
        }
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§eالسلالة: §f" + this.breed.arabicName));
        tooltip.add(Component.literal("§7ضع البيضة في القفص/الخانة أو على السطح لفقس الطير."));
    }
}
