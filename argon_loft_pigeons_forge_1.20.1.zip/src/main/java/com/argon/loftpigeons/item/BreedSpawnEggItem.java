package com.argon.loftpigeons.item;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraftforge.common.ForgeSpawnEggItem;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.function.Supplier;

/**
 * بيضة رسمنة مخصصة لكل سلالة (الكولدن برنس، الأحمر الأغر، والزاجل الرياضي)
 * تضمن ظهور السلالة المحددة فوراً مع ترويضها وربطها بموقع اللاعب.
 */
public class BreedSpawnEggItem extends ForgeSpawnEggItem {
    private final ArgonPigeonEntity.Breed targetBreed;

    public BreedSpawnEggItem(Supplier<? extends EntityType<? extends ArgonPigeonEntity>> type,
                             ArgonPigeonEntity.Breed targetBreed,
                             int backgroundColor,
                             int highlightColor,
                             Properties props) {
        super(type, backgroundColor, highlightColor, props);
        this.targetBreed = targetBreed;
    }

    @Override
    public InteractionResult useOn(UseOnContext context) {
        Level level = context.getLevel();
        if (!(level instanceof ServerLevel serverLevel)) {
            return InteractionResult.SUCCESS;
        }

        ItemStack stack = context.getItemInHand();
        BlockPos pos = context.getClickedPos();
        Direction dir = context.getClickedFace();
        BlockState state = level.getBlockState(pos);
        BlockPos spawnPos = state.getCollisionShape(level, pos).isEmpty() ? pos : pos.relative(dir);

        EntityType<?> entityType = this.getType(stack.getTag());
        var spawned = entityType.create(serverLevel, stack.getTag(), null, spawnPos, MobSpawnType.SPAWN_EGG, true, false);
        if (spawned instanceof ArgonPigeonEntity pigeon) {
            pigeon.setBreed(this.targetBreed);
            Player player = context.getPlayer();
            if (player != null) {
                pigeon.tame(player);
                pigeon.setHomeLoft(spawnPos);
            }
            serverLevel.addFreshEntityWithPassengers(pigeon);
            stack.shrink(1);
            return InteractionResult.CONSUME;
        }

        return super.useOn(context);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        switch (this.targetBreed) {
            case GOLDEN_PRINCE -> tooltip.add(Component.literal("§eسلالة الكولدن برنس: §7ثوب أبيض ناصع ورقبة منقطة بالأسود والذهبي، يطير فوق الغيوم 10 ساعات."));
            case RED_AGHAR -> tooltip.add(Component.literal("§cالطير الأحمر الأغر المسرول: §7غرة بيضاء وسروال ريشي، يدور 3 دوائر ويستكشف بمجموعات."));
            case ZAJIL_HOMER -> tooltip.add(Component.literal("§bالحمام الزاجل الرياضي: §7طير سباقات ذكي يعود لراعيه من أي منطقة بطيران ناصي وسريع."));
        }
    }
}
