package com.argon.loftpigeons.item;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.block.BreedingBoxBlockEntity;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.phys.Vec3;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * الشبكة (Catch Net) المطورة:
 * - تمسك الطير وتخزنه بأمان داخل الشبكة (حتى في طور الإبداعي Creative Mode دون ضياع البيانات).
 * - تتوهج الشبكة عندما يكون بداخلها طير.
 * - كلك يمين على الأرض أو في الهواء يرسبن الطير فوراً بكامل إحصائياته ولون حلقته وعمره!
 * - كلك يمين على العش الكبير أو خانة الكوارتز يدخل الطير للتزاوج (مع فحص خطأ ذكر × ذكر).
 */
public class CatchNetItem extends Item {
    public CatchNetItem(Properties props) {
        super(props);
    }

    public static boolean hasCapturedPigeon(ItemStack stack) {
        return stack.hasTag() && stack.getTag().contains("CapturedPigeon");
    }

    public static void clearCapturedPigeon(ItemStack stack) {
        if (stack.hasTag()) {
            stack.getTag().remove("CapturedPigeon");
            stack.getTag().remove("CapturedDesc");
        }
    }

    public static InteractionResult capturePigeonIntoStack(ItemStack stack, Player player, ArgonPigeonEntity pigeon, InteractionHand hand) {
        if (hasCapturedPigeon(stack)) {
            if (!player.level().isClientSide) {
                player.displayClientMessage(Component.literal("§c[الشبكة ممتلئة!] §fيوجد طير داخل الشبكة بالفعل! اضغط كلك يمين على الأرض لإخراجه أولاً."), true);
            }
            return InteractionResult.FAIL;
        }
        if (!player.level().isClientSide) {
            CompoundTag data = new CompoundTag();
            pigeon.addAdditionalSaveData(data);
            stack.getOrCreateTag().put("CapturedPigeon", data);
            String desc = pigeon.getBreed().arabicName + " (" + (pigeon.isMale() ? "فحل ♂" : "أنثى ♀") + ")";
            stack.getOrCreateTag().putString("CapturedDesc", desc);

            // تثبيت الـ ItemStack في يد اللاعب صراحةً لمنع Creative Mode من مسح الـ NBT!
            player.setItemInHand(hand, stack);
            player.inventoryMenu.broadcastChanges();

            pigeon.discard();
            player.level().playSound(null, player.blockPosition(), SoundEvents.ARMOR_EQUIP_LEATHER, SoundSource.PLAYERS, 1.0F, 1.1F);
            player.displayClientMessage(Component.literal("§a[الشبكة] §fأمسكت §e" + desc + " §fداخل الشبكة! اضغط كلك يمين على الأرض أو العش لإخراجه."), true);
        }
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (target instanceof ArgonPigeonEntity pigeon) {
            return capturePigeonIntoStack(stack, player, pigeon, hand);
        }
        return super.interactLivingEntity(stack, player, target, hand);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        ItemStack stack = ctx.getItemInHand();
        Player player = ctx.getPlayer();
        BlockPos clickedPos = ctx.getClickedPos();

        // إذا ضغط بالشبكة على العش أو خانة التزاوج الكوارتزية -> يدخل الطير في العش مباشرة!
        BlockEntity be = level.getBlockEntity(clickedPos);
        if (be instanceof BreedingBoxBlockEntity nest && player != null && hasCapturedPigeon(stack)) {
            if (!level.isClientSide) {
                return nest.handleRightClick(player, stack, ctx.getHand());
            }
            return InteractionResult.SUCCESS;
        }

        if (hasCapturedPigeon(stack)) {
            if (!level.isClientSide) {
                BlockPos spawnPos = clickedPos.relative(ctx.getClickedFace());
                releaseCapturedPigeon(level, stack, player, ctx.getHand(), spawnPos.getX() + 0.5D, spawnPos.getY(), spawnPos.getZ() + 0.5D);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return super.useOn(ctx);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (hasCapturedPigeon(stack)) {
            if (!level.isClientSide) {
                Vec3 look = player.getLookAngle();
                double sx = player.getX() + look.x * 1.8D;
                double sy = player.getY() + 0.5D;
                double sz = player.getZ() + look.z * 1.8D;
                releaseCapturedPigeon(level, stack, player, hand, sx, sy, sz);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
        }
        return super.use(level, player, hand);
    }

    private void releaseCapturedPigeon(Level level, ItemStack stack, @Nullable Player player, InteractionHand hand, double x, double y, double z) {
        ArgonPigeonEntity pigeon = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(level);
        if (pigeon != null && stack.hasTag()) {
            String desc = stack.getTag().getString("CapturedDesc");
            pigeon.readAdditionalSaveData(stack.getTag().getCompound("CapturedPigeon"));
            pigeon.setPos(x, y, z);
            if (player != null) {
                pigeon.tame(player);
            }
            level.addFreshEntity(pigeon);
            level.playSound(null, BlockPos.containing(x, y, z), SoundEvents.PARROT_FLY, SoundSource.NEUTRAL, 1.0F, 1.0F);
            clearCapturedPigeon(stack);
            if (player != null) {
                player.setItemInHand(hand, stack);
                player.inventoryMenu.broadcastChanges();
                player.displayClientMessage(Component.literal("§b[الشبكة] §fتم إخراج ورسبنة الطير بنجاح: §e" + desc), true);
            }
        }
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return hasCapturedPigeon(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (hasCapturedPigeon(stack)) {
            tooltip.add(Component.literal("§aالطير داخل الشبكة: §e" + stack.getTag().getString("CapturedDesc")));
            tooltip.add(Component.literal("§bاضغط كلك يمين على الأرض أو العش لإخراجه ورسبنته فوراً."));
        } else {
            tooltip.add(Component.literal("§7اضغط كلك يمين على أي طير لإمساكه داخل الشبكة ونقله."));
        }
    }
}
