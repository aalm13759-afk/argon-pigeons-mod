package com.argon.loftpigeons.item;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * الشبكة (Catch Net): تُصنع من خشب + خيوط عنكبوت.
 * تُستخدم لمسك الطير (كلك يمين) ووضعه في الإنفنتوري أو نقله لخانة التزاوج أو السطح.
 */
public class CatchNetItem extends Item {
    public CatchNetItem(Properties props) {
        super(props);
    }

    public static boolean hasCapturedPigeon(ItemStack stack) {
        return stack.hasTag() && stack.getTag().contains("CapturedPigeon");
    }

    public static void clearCapturedPigeon(ItemStack stack) {
        if (stack.hasTag()) {
            stack.getTag().remove("CapturedPigeon");
            stack.getTag().remove("CapturedDesc");
        }
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (target instanceof ArgonPigeonEntity pigeon && !player.level().isClientSide && !hasCapturedPigeon(stack)) {
            CompoundTag data = new CompoundTag();
            pigeon.addAdditionalSaveData(data);
            stack.getOrCreateTag().put("CapturedPigeon", data);
            String desc = pigeon.getBreed().arabicName + " (" + (pigeon.isMale() ? "فحل ♂" : "أنثى ♀") + ")";
            stack.getOrCreateTag().putString("CapturedDesc", desc);
            pigeon.discard();
            player.displayClientMessage(Component.literal("§a[الشبكة] §fتم مسك " + desc + " ووضعه في الإنفنتوري!"), true);
            return InteractionResult.SUCCESS;
        }
        return super.interactLivingEntity(stack, player, target, hand);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        ItemStack stack = ctx.getItemInHand();
        if (!level.isClientSide && hasCapturedPigeon(stack)) {
            BlockPos pos = ctx.getClickedPos().relative(ctx.getClickedFace());
            ArgonPigeonEntity pigeon = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(level);
            if (pigeon != null) {
                pigeon.readAdditionalSaveData(stack.getTag().getCompound("CapturedPigeon"));
                pigeon.setPos(pos.getX() + 0.5D, pos.getY(), pos.getZ() + 0.5D);
                level.addFreshEntity(pigeon);
                clearCapturedPigeon(stack);
                if (ctx.getPlayer() != null) {
                    ctx.getPlayer().displayClientMessage(Component.literal("§b[الشبكة] §fتم إخراج الطير على السطح."), true);
                }
                return InteractionResult.SUCCESS;
            }
        }
        return super.useOn(ctx);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (hasCapturedPigeon(stack)) {
            tooltip.add(Component.literal("§aالطير الممسوك: §f" + stack.getTag().getString("CapturedDesc")));
            tooltip.add(Component.literal("§7اضغط كلك يمين على خانة التزاوج لإدخاله أو على السطح لإطلاقه."));
        } else {
            tooltip.add(Component.literal("§7اضغط كلك يمين على أي طير لمسكه ووضعه في الإنفنتوري."));
        }
    }
}
