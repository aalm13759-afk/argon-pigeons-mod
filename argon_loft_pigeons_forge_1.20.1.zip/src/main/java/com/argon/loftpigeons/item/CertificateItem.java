package com.argon.loftpigeons.item;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * بطاقة المعلومات (Certificate): تُصنع من 2 أيرون + 1 خشب.
 * بالضغط كلك يمين على الطير تُحفظ بطاقة دائمة باسمه تعرض:
 * الجنس (فحل/أنثى)، العمر بالأشهر والسنين، العمر بالريش (1-10)، نسبة الذكاء (Mentally)، ونسبة الحدة (The Limit).
 */
public class CertificateItem extends Item {
    public CertificateItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (target instanceof ArgonPigeonEntity pigeon && !player.level().isClientSide) {
            CompoundTag tag = stack.getOrCreateTag();
            tag.putString("BreedName", pigeon.getBreed().arabicName);
            tag.putString("Gender", pigeon.isMale() ? "فحل ♂" : "أنثى ♀");
            tag.putInt("Months", pigeon.getAgeMonths());
            tag.putInt("FeatherStage", pigeon.getFeatherStage());
            tag.putInt("Mentally", pigeon.getMentally());
            tag.putInt("TheLimit", pigeon.getTheLimit());
            tag.putBoolean("HasLimit", pigeon.getBreed().hasLimitStat());
            tag.putInt("RoofDays", pigeon.getMemorizedRoofDays());
            tag.putInt("ReqRoofDays", pigeon.getRequiredRoofDays());

            stack.setHoverName(Component.literal("§6بطاقة طير: §f" + pigeon.getBreed().arabicName + " (" + (pigeon.isMale() ? "فحل" : "أنثى") + ")"));
            player.displayClientMessage(Component.literal(
                    "§6[شهادة الطير] §f" + pigeon.getBreed().arabicName +
                    " | الجنس: §b" + (pigeon.isMale() ? "فحل" : "أنثى") +
                    " §f| الريشة: §e" + pigeon.getFeatherStage() + "/10" +
                    " §f| الذكاء Mentally: §a" + pigeon.getMentally() + "%" +
                    (pigeon.getBreed().hasLimitStat() ? " §f| الحدة The Limit: §c" + pigeon.getTheLimit() + "%" : "") +
                    " §f| حفظ السطح: §e" + pigeon.getMemorizedRoofDays() + "/" + pigeon.getRequiredRoofDays() + " يوم"
            ), false);
            return InteractionResult.SUCCESS;
        }
        return super.interactLivingEntity(stack, player, target, hand);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (stack.hasTag() && stack.getTag().contains("BreedName")) {
            CompoundTag t = stack.getTag();
            int months = t.getInt("Months");
            int years = months / 12;
            int remMonths = months % 12;
            tooltip.add(Component.literal("§e• السلالة: §f" + t.getString("BreedName")));
            tooltip.add(Component.literal("§e• الجنس: §b" + t.getString("Gender")));
            tooltip.add(Component.literal("§e• العمر: §f" + years + " سنة و " + remMonths + " شهر"));
            tooltip.add(Component.literal("§e• العمر بالريش: §6الريشة " + t.getInt("FeatherStage") + " من 10"));
            tooltip.add(Component.literal("§e• الذكاء (Mentally): §a" + t.getInt("Mentally") + "%"));
            if (t.getBoolean("HasLimit")) {
                tooltip.add(Component.literal("§e• الحدة (The Limit): §c" + t.getInt("TheLimit") + "%"));
            }
            tooltip.add(Component.literal("§e• حفظ السطح: §f" + t.getInt("RoofDays") + " / " + t.getInt("ReqRoofDays") + " يوماً"));
        } else {
            tooltip.add(Component.literal("§7اضغط كلك يمين على أي طير لحفظ شهادته الكاملة."));
        }
    }
}
