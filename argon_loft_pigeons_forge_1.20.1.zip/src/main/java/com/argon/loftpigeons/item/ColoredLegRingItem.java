package com.argon.loftpigeons.item;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;

/**
 * حلقات الأرجل الملونة (20 لوناً): تُلبس للطير (كلك يمين) لتمييزه وتُظهر مجسم `leg_ring` حول ساقه.
 */
public class ColoredLegRingItem extends Item {
    public final int colorIndex;
    public final String arabicColorName;

    public ColoredLegRingItem(int colorIndex, String arabicColorName, Properties props) {
        super(props);
        this.colorIndex = colorIndex;
        this.arabicColorName = arabicColorName;
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (target instanceof ArgonPigeonEntity pigeon && !player.level().isClientSide) {
            pigeon.setLegRingColorIndex(this.colorIndex);
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.displayClientMessage(Component.literal("§a[حلقة الرجل] §fتم إلباس الطير حلقة رجل بلون: §e" + this.arabicColorName), true);
            return InteractionResult.SUCCESS;
        }
        return super.interactLivingEntity(stack, player, target, hand);
    }
}
