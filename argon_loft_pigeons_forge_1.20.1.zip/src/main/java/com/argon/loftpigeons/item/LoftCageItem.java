package com.argon.loftpigeons.item;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class LoftCageItem extends Item {
    public LoftCageItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (target instanceof ArgonPigeonEntity pigeon && !player.level().isClientSide) {
            CompoundTag pigeonData = new CompoundTag();
            pigeon.saveWithoutId(pigeonData);
            stack.getOrCreateTag().put("StoredPigeon", pigeonData);
            stack.getOrCreateTag().putString("StoredBreedName", pigeon.getBreed().arabicName);
            pigeon.discard();
            player.displayClientMessage(Component.literal("§b[قفص اللوفت] §fتم إدخال " + pigeon.getBreed().arabicName + " في القفص. اذهب لأي منطقة واضغط كليك يمين لفتحه وتطييره!"), true);
            return InteractionResult.SUCCESS;
        }
        return super.interactLivingEntity(stack, player, target, hand);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide && stack.hasTag() && stack.getTag().contains("StoredPigeon")) {
            ArgonPigeonEntity pigeon = ArgonLoftPigeonsMod.LOFT_PIGEON.get().create(level);
            if (pigeon != null) {
                pigeon.load(stack.getTag().getCompound("StoredPigeon"));
                pigeon.setPos(player.getX(), player.getY() + 1.2D, player.getZ());
                level.addFreshEntity(pigeon);
                pigeon.launchFlight(player);
                stack.getTag().remove("StoredPigeon");
                stack.getTag().remove("StoredBreedName");
                player.displayClientMessage(Component.literal("§a[فتح القفص] §fانطلق " + pigeon.getBreed().arabicName + " في السماء!"), true);
            }
            return InteractionResultHolder.success(stack);
        }
        return super.use(level, player, hand);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7اضغط كليك يمين على الطير لوضعه في القفص ونقله لأي منطقة."));
        if (stack.hasTag() && stack.getTag().contains("StoredBreedName")) {
            tooltip.add(Component.literal("§eالطير داخل القفص: §f" + stack.getTag().getString("StoredBreedName")));
        }
    }
}
