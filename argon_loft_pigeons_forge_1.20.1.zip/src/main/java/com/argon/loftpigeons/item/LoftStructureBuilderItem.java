package com.argon.loftpigeons.item;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.block.BreedingBoxBlock;
import com.argon.loftpigeons.block.BreedingBoxBlockEntity;
import com.argon.loftpigeons.block.PigeonFeederBlock;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.LanternBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.Half;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * أداة بناء برج الحمام المعماري الفخم (20 عرض × 10 عمق × 5 ارتفاع)
 * مبنية ببلوكات ماينكرافت الأصيلة: Stone Bricks, Polished Andesite, Stripped Spruce Logs, Oak Planks, Dark Oak Planks, Iron Bars
 *
 * التقسيم المعماري الدقيق (20×10×5):
 * - الوسط (X = 6..13): مدخل رئيسي بمنتصف الواجهة (X = 9, Z = 0)، ممر أنديزيت مصقول، معالف أرضية وحبيبات دخن 3D، مشارب مياه، وسلم خلفي لفتحة السطح (المطار).
 * - اليمين (X = 14..19): يفصله حاجز من الحجر المنحوت والخشب وقضبان الحديد (X = 14) يتوسطه باب (Z = 4)، وبداخله 8 خانات تزاوج جاهزة بالأعشاش والمعالف.
 * - اليسار (X = 0..5): يفصله حاجز من الحجر المنحوت والخشب وقضبان الحديد (X = 5) يتوسطه باب ينفتح وينغلق (Z = 4)، ومجهز بركزات حائطية (السبعات) للطيور المطيرة والمقصوصة.
 */
public class LoftStructureBuilderItem extends Item {
    public LoftStructureBuilderItem(Properties properties) {
        super(properties);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        BlockPos clicked = ctx.getClickedPos().above();
        Player player = ctx.getPlayer();

        if (!level.isClientSide()) {
            // نجعل منتصف المدخل الأمامي للبرج أمام اللاعب
            BlockPos origin = clicked.offset(-9, 0, 1);
            buildMinecraftArchitecturalLoft20x10x5(level, origin);

            level.playSound(null, clicked, SoundEvents.ANVIL_USE, SoundSource.BLOCKS, 0.9F, 1.1F);
            if (player != null) {
                player.displayClientMessage(
                        Component.literal("تم تشييد برج الحمام المعماري (20×10×5) من الحجر والخشب وقضبان الحديد مع الـ8 خانات تزاوج!")
                                .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD),
                        false);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide());
    }

    private void buildMinecraftArchitecturalLoft20x10x5(Level level, BlockPos origin) {
        int width = 20;  // X: 0 .. 19
        int depth = 10;  // Z: 0 .. 9
        int height = 5;  // Y: 0 .. 5

        // 0. تفريغ المساحة الداخلية بالكامل
        for (int x = 0; x < width; x++) {
            for (int z = 0; z < depth; z++) {
                for (int y = 0; y <= height + 1; y++) {
                    level.setBlock(origin.offset(x, y, z), Blocks.AIR.defaultBlockState(), 3);
                }
            }
        }

        // 1. الأساسات الحجرية والأرضية الهندسية (Y = 0)
        for (int x = 0; x < width; x++) {
            for (int z = 0; z < depth; z++) {
                BlockPos pos = origin.offset(x, 0, z);
                boolean isOuterBorder = (x == 0 || x == width - 1 || z == 0 || z == depth - 1);
                boolean isPartitionLine = (x == 5 || x == 14);
                boolean isCorner = (x == 0 || x == width - 1) && (z == 0 || z == depth - 1);

                if (isCorner) {
                    level.setBlock(pos, Blocks.CHISELED_STONE_BRICKS.defaultBlockState(), 3);
                } else if (isOuterBorder || isPartitionLine) {
                    level.setBlock(pos, Blocks.STONE_BRICKS.defaultBlockState(), 3);
                } else if (x >= 6 && x <= 13) {
                    // صالة الوسط: ممر حجر أنديزيت مصقول بالمنتصف مع أطراف خشب التنوب
                    if (x >= 8 && x <= 11) {
                        level.setBlock(pos, Blocks.POLISHED_ANDESITE.defaultBlockState(), 3);
                    } else {
                        level.setBlock(pos, Blocks.SPRUCE_PLANKS.defaultBlockState(), 3);
                    }
                } else if (x < 5) {
                    // غرفة اليسار (المطير والمقصوص): أرضية خشب بلوط وتنوب متناوب
                    level.setBlock(pos, ((x + z) % 2 == 0) ? Blocks.OAK_PLANKS.defaultBlockState() : Blocks.SPRUCE_PLANKS.defaultBlockState(), 3);
                } else {
                    // غرفة اليمين (التزاوج): أرضية خشب بلوط داكن وبلوط عادي
                    level.setBlock(pos, ((x + z) % 2 == 0) ? Blocks.DARK_OAK_PLANKS.defaultBlockState() : Blocks.OAK_PLANKS.defaultBlockState(), 3);
                }
            }
        }

        // 2. الجدران الخارجية (حزام سفلي Stone Bricks + أعمدة Spruce Logs + شبابيك قضبان حديد Iron Bars + إطار علوي)
        for (int y = 1; y <= height - 1; y++) {
            for (int x = 0; x < width; x++) {
                for (int z = 0; z < depth; z++) {
                    boolean isOuter = (x == 0 || x == width - 1 || z == 0 || z == depth - 1);
                    if (!isOuter) continue;

                    // فتحة باب الدخول الرئيسي في منتصف الواجهة الأمامية (X = 9, Z = 0, Y = 1..2)
                    if (z == 0 && x == 9 && (y == 1 || y == 2)) {
                        continue;
                    }

                    BlockPos pos = origin.offset(x, y, z);
                    boolean isPillar = (x == 0 || x == 5 || x == 8 || x == 10 || x == 14 || x == 19) && (z == 0 || z == depth - 1)
                            || (z == 4 && (x == 0 || x == width - 1));

                    if (isPillar) {
                        level.setBlock(pos, Blocks.STRIPPED_SPRUCE_LOG.defaultBlockState(), 3);
                    } else if (y == 1) {
                        // قاعدة الجدار من الطوب الحجري المتين (Stone Bricks)
                        level.setBlock(pos, (x + z) % 4 == 0 ? Blocks.CRACKED_STONE_BRICKS.defaultBlockState() : Blocks.STONE_BRICKS.defaultBlockState(), 3);
                    } else if (y == 4) {
                        // الجسر الخشبي العلوي (Dark Oak Planks)
                        level.setBlock(pos, Blocks.DARK_OAK_PLANKS.defaultBlockState(), 3);
                    } else {
                        // الطابق الأوسط (Y = 2..3): قضبان حديد (Iron Bars) في الواجهة الأمامية والجوانب للتهوية والضوء، وخشب بلوط بالخلف
                        if (z == 0 && (x != 8 && x != 10)) {
                            level.setBlock(pos, Blocks.IRON_BARS.defaultBlockState(), 3);
                        } else if ((x == 0 || x == width - 1) && (z >= 2 && z <= 7)) {
                            level.setBlock(pos, Blocks.IRON_BARS.defaultBlockState(), 3);
                        } else if (z == depth - 1 && (x >= 7 && x <= 12) && y == 3) {
                            level.setBlock(pos, Blocks.IRON_BARS.defaultBlockState(), 3);
                        } else {
                            level.setBlock(pos, Blocks.OAK_PLANKS.defaultBlockState(), 3);
                        }
                    }
                }
            }
        }

        // 3. الحاجز الأيسر (X = 5) والحاجز الأيمن (X = 14) من الحجر والخشب وقضبان الحديد مع باب في المنتصف (Z = 4)
        int[] partitionXs = {5, 14};
        for (int px : partitionXs) {
            for (int z = 1; z < depth - 1; z++) {
                for (int y = 1; y <= height - 1; y++) {
                    // ترك فتحة الباب بالوسط عند Z = 4 (Y = 1..2)
                    if (z == 4 && (y == 1 || y == 2)) continue;

                    BlockPos pos = origin.offset(px, y, z);
                    if (z == 3 || z == 5) {
                        // أعمدة إطار الباب الداخلي من جذوع التنوب المقشرة
                        level.setBlock(pos, Blocks.STRIPPED_SPRUCE_LOG.defaultBlockState(), 3);
                    } else if (y == 1) {
                        // قاعدة الحاجز من الطوب الحجري
                        level.setBlock(pos, Blocks.STONE_BRICKS.defaultBlockState(), 3);
                    } else if (y == 4) {
                        level.setBlock(pos, Blocks.DARK_OAK_PLANKS.defaultBlockState(), 3);
                    } else {
                        // قضبان حديدية (Iron Bars) تكشف الغرف الداخلية بأناقة
                        level.setBlock(pos, Blocks.IRON_BARS.defaultBlockState(), 3);
                    }
                }
            }
        }

        // تركيب الأبواب الثلاثة:
        // أ) باب الدخول الرئيسي بالوسط (X = 9, Z = 0)
        placeDoor(level, origin.offset(9, 1, 0), Blocks.SPRUCE_DOOR, Direction.SOUTH);
        // ب) باب حاجز اليسار لغرفة الطيور المطيرة والمقصوصة (X = 5, Z = 4)
        placeDoor(level, origin.offset(5, 1, 4), Blocks.OAK_DOOR, Direction.EAST);
        // ج) باب حاجز اليمين لغرفة التزاوج (X = 14, Z = 4)
        placeDoor(level, origin.offset(14, 1, 4), Blocks.OAK_DOOR, Direction.WEST);

        // عتبة حجرية أمام المدخل الرئيسي (X = 9, Z = -1)
        level.setBlock(origin.offset(9, 0, -1), Blocks.STONE_BRICK_STAIRS.defaultBlockState().setValue(StairBlock.FACING, Direction.SOUTH), 3);

        // 4. قسم اليمين (X = 14..19): تركيب 8 خانات تزاوج ببلوكات الكوارتز الماينكرافتية مربوطة بالعش الكبير 3D (طابقين × 4 أعمدة)
        int[] boxZs = {1, 3, 5, 7};
        int[] boxYs = {1, 3};
        for (int by : boxYs) {
            for (int bz : boxZs) {
                // أرضية ورفوف الخانة من الكوارتز الماينكرافتي الناعم وأعمدة الكوارتز
                level.setBlock(origin.offset(18, by - 1, bz), Blocks.QUARTZ_BLOCK.defaultBlockState(), 3);
                level.setBlock(origin.offset(17, by - 1, bz), Blocks.SMOOTH_QUARTZ_SLAB.defaultBlockState(), 3);
                if (bz + 1 < depth - 1) {
                    level.setBlock(origin.offset(18, by, bz + 1), Blocks.QUARTZ_PILLAR.defaultBlockState(), 3);
                    level.setBlock(origin.offset(17, by, bz + 1), Blocks.IRON_BARS.defaultBlockState(), 3);
                }

                // وضع خانة التزاوج الكوارتزية في (18, by, bz) والعش الكبير 3D المربوط بها أمامها في (17, by, bz)
                BlockPos boxPos = origin.offset(18, by, bz);
                level.setBlock(boxPos, ArgonLoftPigeonsMod.BREEDING_BOX.get().defaultBlockState(), 3);
                if (level.getBlockEntity(boxPos) instanceof BreedingBoxBlockEntity boxEntity) {
                    boxEntity.preEquipForLoft();
                }

                BlockPos nestPos = origin.offset(17, by, bz);
                level.setBlock(nestPos, ArgonLoftPigeonsMod.COPPER_NEST_BOWL.get().defaultBlockState(), 3);
                if (level.getBlockEntity(nestPos) instanceof BreedingBoxBlockEntity nestEntity) {
                    nestEntity.preEquipForLoft();
                }
            }
        }

        // 5. قسم اليسار (X = 0..5): تركيب الركزات الحائطية (السبعات V-Perches) للطيور المطيرة والمقصوصة
        int[] perchZs = {1, 3, 5, 7};
        int[] perchYs = {2, 3};
        for (int py : perchYs) {
            for (int pz : perchZs) {
                // ركزات على الجدار الأيسر (X = 1)
                level.setBlock(origin.offset(1, py, pz), Blocks.SPRUCE_TRAPDOOR.defaultBlockState()
                        .setValue(TrapDoorBlock.FACING, Direction.EAST)
                        .setValue(TrapDoorBlock.HALF, Half.TOP)
                        .setValue(TrapDoorBlock.OPEN, false), 3);
            }
        }
        // ركزات إضافية على الجدار الخلفي لقسم اليسار (Z = 8, X = 1..4)
        for (int px = 1; px <= 4; px++) {
            level.setBlock(origin.offset(px, 2, 8), Blocks.OAK_STAIRS.defaultBlockState()
                    .setValue(StairBlock.FACING, Direction.NORTH)
                    .setValue(StairBlock.HALF, Half.TOP), 3);
        }
        // معلف أرضي وحبيبات دخن 3D في قسم اليسار للطيور المقصوصة
        level.setBlock(origin.offset(2, 1, 2), ArgonLoftPigeonsMod.PIGEON_FEEDER.get().defaultBlockState(), 3);
        level.setBlock(origin.offset(3, 1, 5), ArgonLoftPigeonsMod.DUKHN_PILE.get().defaultBlockState(), 3);

        // 6. صالة الوسط (X = 6..13): المعالف الطويلة، جزيئات الدخن 3D، مشارب الماء، البراميل، وسلم السطح
        for (int z = 3; z <= 6; z++) {
            level.setBlock(origin.offset(7, 1, z), ArgonLoftPigeonsMod.PIGEON_FEEDER.get().defaultBlockState(), 3);
            level.setBlock(origin.offset(9, 1, z), ArgonLoftPigeonsMod.DUKHN_PILE.get().defaultBlockState(), 3);
        }
        level.setBlock(origin.offset(10, 1, 4), ArgonLoftPigeonsMod.DUKHN_PILE.get().defaultBlockState(), 3);
        level.setBlock(origin.offset(10, 1, 5), ArgonLoftPigeonsMod.DUKHN_PILE.get().defaultBlockState(), 3);

        // منصة الفحص الذكية: بلوكة مجسم الطير 3D لدراسة الحالة النفسية والجسدية في صالة الوسط فوق قاعدة كوارتز!
        level.setBlock(origin.offset(11, 0, 7), Blocks.CHISELED_QUARTZ_BLOCK.defaultBlockState(), 3);
        level.setBlock(origin.offset(11, 1, 7), ArgonLoftPigeonsMod.PIGEON_ANALYZER.get().defaultBlockState(), 3);

        // مشارب المياه (Water Cauldrons) على الجانب الأيمن من صالة الوسط
        level.setBlock(origin.offset(12, 1, 3), Blocks.WATER_CAULDRON.defaultBlockState(), 3);
        level.setBlock(origin.offset(12, 1, 6), Blocks.WATER_CAULDRON.defaultBlockState(), 3);

        // براميل تخزين العلف والحلقات في الزوايا الخلفية لصالة الوسط
        level.setBlock(origin.offset(6, 1, 8), Blocks.BARREL.defaultBlockState(), 3);
        level.setBlock(origin.offset(13, 1, 8), Blocks.BARREL.defaultBlockState(), 3);

        // عمود حجر منحوت وسلم الصعود للسطح (X = 10, Z = 8, Y = 1..5)
        for (int y = 1; y <= height - 1; y++) {
            level.setBlock(origin.offset(10, y, 9), Blocks.STONE_BRICKS.defaultBlockState(), 3);
            level.setBlock(origin.offset(10, y, 8), Blocks.LADDER.defaultBlockState()
                    .setValue(LadderBlock.FACING, Direction.NORTH), 3);
        }

        // 7. السقف المعماري (Y = 5) بإطار Stone Brick Stairs/Slabs وشبك حديدي علوي ومطار هبوط الطيور
        for (int x = 0; x < width; x++) {
            for (int z = 0; z < depth; z++) {
                BlockPos roofPos = origin.offset(x, height, z);
                boolean isOuterEdge = (x == 0 || x == width - 1 || z == 0 || z == depth - 1);

                if (x == 10 && z == 8) {
                    // بوابة الخروج للسطح فوق السلم
                    level.setBlock(roofPos, Blocks.SPRUCE_TRAPDOOR.defaultBlockState()
                            .setValue(TrapDoorBlock.FACING, Direction.SOUTH)
                            .setValue(TrapDoorBlock.HALF, Half.BOTTOM), 3);
                } else if (isOuterEdge) {
                    // إفريز السقف الحجري الفخم (Stone Brick Slab + Chiseled Corners)
                    if ((x == 0 || x == width - 1) && (z == 0 || z == depth - 1)) {
                        level.setBlock(roofPos, Blocks.CHISELED_STONE_BRICKS.defaultBlockState(), 3);
                        level.setBlock(roofPos.above(), Blocks.LANTERN.defaultBlockState(), 3);
                    } else {
                        level.setBlock(roofPos, Blocks.STONE_BRICKS.defaultBlockState(), 3);
                        level.setBlock(roofPos.above(), Blocks.IRON_BARS.defaultBlockState(), 3);
                    }
                } else if ((x >= 2 && x <= 3 && z >= 3 && z <= 6) || (x >= 16 && x <= 17 && z >= 3 && z <= 6)) {
                    // فتحات إضاءة وتهوية بقضبان حديد وزجاج فوق غرفتي اليسار واليمين
                    level.setBlock(roofPos, Blocks.TINTED_GLASS.defaultBlockState(), 3);
                } else if (x == 5 || x == 14) {
                    level.setBlock(roofPos, Blocks.STRIPPED_SPRUCE_LOG.defaultBlockState(), 3);
                } else {
                    level.setBlock(roofPos, Blocks.SPRUCE_PLANKS.defaultBlockState(), 3);
                }
            }
        }

        // منصة هبوط الحمام على السطح (المطار / الحطاطة الخشبية والحديدية فوق السقف عند Y = 6, X = 7..12, Z = 4..6)
        for (int x = 7; x <= 12; x++) {
            level.setBlock(origin.offset(x, height + 1, 5), Blocks.SPRUCE_FENCE.defaultBlockState(), 3);
            level.setBlock(origin.offset(x, height + 2, 5), Blocks.SPRUCE_TRAPDOOR.defaultBlockState(), 3);
        }

        // 8. الإضاءة المعمارية بالفوانيس المعلقة (Lanterns) داخل الغرف الثلاث
        BlockState hangingLantern = Blocks.LANTERN.defaultBlockState().setValue(LanternBlock.HANGING, true);
        level.setBlock(origin.offset(2, height - 1, 4), hangingLantern, 3);
        level.setBlock(origin.offset(9, height - 1, 2), hangingLantern, 3);
        level.setBlock(origin.offset(9, height - 1, 7), hangingLantern, 3);
        level.setBlock(origin.offset(16, height - 1, 4), hangingLantern, 3);
    }

    private void placeDoor(Level level, BlockPos bottomPos, net.minecraft.world.level.block.Block doorBlock, Direction facing) {
        BlockState lower = doorBlock.defaultBlockState()
                .setValue(DoorBlock.FACING, facing)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER)
                .setValue(DoorBlock.OPEN, true);
        BlockState upper = doorBlock.defaultBlockState()
                .setValue(DoorBlock.FACING, facing)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER)
                .setValue(DoorBlock.OPEN, true);
        level.setBlock(bottomPos, lower, 3);
        level.setBlock(bottomPos.above(), upper, 3);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("يشيد تلقائياً بناية برج حمام ماينكرافتية فخمة (20×10×5)").withStyle(ChatFormatting.GOLD));
        tooltip.add(Component.literal("مبنية من الطوب الحجري، جذوع التنوب، خشب البلوط، وقضبان الحديد").withStyle(ChatFormatting.GRAY));
        tooltip.add(Component.literal("• الوسط: مدخل رئيسي + ممر أنديزيت + معالف ودخن 3D + سلم للسطح").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.literal("• اليمين: قاطع حديدي وخشبي وباب بالمنتصف + 8 خانات تزاوج جاهزة").withStyle(ChatFormatting.GREEN));
        tooltip.add(Component.literal("• اليسار: قاطع حديدي وخشبي وباب يفتح ويغلق + ركزات للمطير والمقصوص").withStyle(ChatFormatting.YELLOW));
    }
}
