package com.argon.loftpigeons.item;

import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;

/**
 * برج الحمام (Loft 20x10): يُصنع من 3 حبات أيرون + 3 بلوكات أيرون.
 * يبني هيكل برج الحمام بحجم 20×10 بلوكات مع باب للدخول ومسك الطيور بالشبكة!
 */
public class LoftStructureBuilderItem extends Item {
    public LoftStructureBuilderItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (!level.isClientSide) {
            BlockPos origin = ctx.getClickedPos().above();
            int width = 20;
            int depth = 10;
            int height = 4;

            for (int x = 0; x < width; x++) {
                for (int z = 0; z < depth; z++) {
                    // أرضية خشبية وسقف شبكي/خشبي للبرج
                    level.setBlock(origin.offset(x, 0, z), Blocks.SPRUCE_PLANKS.defaultBlockState(), 3);
                    level.setBlock(origin.offset(x, height, z), Blocks.OAK_SLAB.defaultBlockState(), 3);

                    for (int y = 1; y < height; y++) {
                        boolean isWall = (x == 0 || x == width - 1 || z == 0 || z == depth - 1);
                        if (isWall) {
                            // مدخل الباب في منتصف الواجهة الأمامية
                            if (z == 0 && x == width / 2 && (y == 1 || y == 2)) {
                                level.setBlock(origin.offset(x, y, z), Blocks.AIR.defaultBlockState(), 3);
                            } else {
                                level.setBlock(origin.offset(x, y, z), Blocks.IRON_BARS.defaultBlockState(), 3);
                            }
                        } else {
                            level.setBlock(origin.offset(x, y, z), Blocks.AIR.defaultBlockState(), 3);
                        }
                    }
                }
            }

            // وضع باب خشبي متحرك يفتح ويغلق بالضغط عليه
            BlockPos doorPos = origin.offset(width / 2, 1, 0);
            level.setBlock(doorPos, Blocks.OAK_DOOR.defaultBlockState().setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER), 3);
            level.setBlock(doorPos.above(), Blocks.OAK_DOOR.defaultBlockState().setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER), 3);

            if (ctx.getPlayer() != null) {
                if (!ctx.getPlayer().getAbilities().instabuild) ctx.getItemInHand().shrink(1);
                ctx.getPlayer().displayClientMessage(Component.literal("§a[برج الحمام 20×10] §fتم بناء برج الحمام الكامل (20×10 بلوكات) مع باب الدخول!"), true);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
