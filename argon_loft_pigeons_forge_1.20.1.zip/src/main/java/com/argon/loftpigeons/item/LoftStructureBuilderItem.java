package com.argon.loftpigeons.item;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.block.BreedingBoxBlockEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.DoorBlock;
import net.minecraft.world.level.block.LadderBlock;
import net.minecraft.world.level.block.StairBlock;
import net.minecraft.world.level.block.TrapDoorBlock;
import net.minecraft.world.level.block.entity.BlockEntity;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.properties.DoubleBlockHalf;
import net.minecraft.world.level.block.state.properties.Half;

/**
 * باني برج الحمام النموذجي (20 عرض × 10 عمق × 5 ارتفاع):
 * - مطابق للصورة النموذجية:
 *   1. الدخول بالوسط (بهو المعالف والمشارب وسلّم السطح).
 *   2. على اليمين: حاجز بداخله باب بالوسط، ويحتوي على 8 خانات تزاوج جاهزة أول ما يترسبن البرج!
 *   3. على اليسار: حاجز بداخله باب ينفتح وينغلق، ومكان مخصص للطيور الطيارة أو المقصوصة مع الركزات (السبعات)، وتستطيع الطيور التمشي بين اليسار والوسط!
 */
public class LoftStructureBuilderItem extends Item {
    public LoftStructureBuilderItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (!level.isClientSide) {
            BlockPos origin = ctx.getClickedPos().above();
            int width = 20;  // العرض 20 بلوكة (X = 0..19)
            int depth = 10;  // العمق 10 بلوكات (Z = 0..9)
            int height = 5;  // الارتفاع 5 بلوكات (Y = 0..4)

            BlockState planks = Blocks.OAK_PLANKS.defaultBlockState();
            BlockState log = Blocks.SPRUCE_LOG.defaultBlockState();
            BlockState bars = Blocks.IRON_BARS.defaultBlockState();
            BlockState roofSlab = Blocks.OAK_SLAB.defaultBlockState();

            // 1. بناء الأرضية، السقف، والجدران الخارجية (20×10×5)
            for (int x = 0; x < width; x++) {
                for (int z = 0; z < depth; z++) {
                    // الأرضية الخشبية (Y = 0)
                    level.setBlock(origin.offset(x, 0, z), planks, 3);
                    // سقف البرج (Y = 5) لوقوف الطيور فوق السطح وحفظ المعالم
                    level.setBlock(origin.offset(x, height, z), planks, 3);

                    for (int y = 1; y < height; y++) {
                        boolean isOuterWall = (x == 0 || x == width - 1 || z == 0 || z == depth - 1);
                        boolean isCorner = (x == 0 || x == width - 1) && (z == 0 || z == depth - 1);

                        if (isCorner) {
                            level.setBlock(origin.offset(x, y, z), log, 3);
                        } else if (isOuterWall) {
                            // الجدار الخلفي خشب بالكامل لتثبيت الركزات وخانات التزاوج والسلّم
                            if (z == depth - 1) {
                                level.setBlock(origin.offset(x, y, z), planks, 3);
                            } else if (y >= 2 && y <= 3 && (x == 0 || x == width - 1 || (z == 0 && (x < 8 || x > 11)))) {
                                // شبابيك سيم حديد للتهوية والشمس على الجوانب والواجهة
                                level.setBlock(origin.offset(x, y, z), bars, 3);
                            } else {
                                level.setBlock(origin.offset(x, y, z), planks, 3);
                            }
                        } else {
                            level.setBlock(origin.offset(x, y, z), Blocks.AIR.defaultBlockState(), 3);
                        }
                    }
                }
            }

            // 2. باب الدخول الرئيسي في وسط الواجهة الأمامية (X = 9, Z = 0)
            placeDoor(level, origin.offset(9, 1, 0), Direction.SOUTH);

            // 3. الحاجز الأيمن (X = 14) مع باب في المنتصف (Z = 4) + 8 خانات تزاوج جاهزة داخل الغرفة اليمنى!
            for (int z = 1; z < depth - 1; z++) {
                for (int y = 1; y < height; y++) {
                    if (z == 4 && (y == 1 || y == 2)) {
                        continue; // فتحة الباب الأيمن في المنتصف
                    }
                    BlockState wallMat = (y >= 2 && z != 4) ? bars : planks;
                    level.setBlock(origin.offset(14, y, z), wallMat, 3);
                }
            }
            placeDoor(level, origin.offset(14, 1, 4), Direction.EAST);

            // وضع 8 خانات تزاوج أصلية (Breeding Boxes) في الغرفة اليمنى (4 على الجدار الخلفي + 4 على الجدار الأيمن)
            BlockState boxState = ArgonLoftPigeonsMod.BREEDING_BOX.get().defaultBlockState();
            int[][] boxCoords = {
                {15, 1, 8}, {16, 1, 8}, {17, 1, 8}, {18, 1, 8},
                {15, 2, 8}, {16, 2, 8}, {17, 2, 8}, {18, 2, 8}
            };
            for (int[] bc : boxCoords) {
                BlockPos bp = origin.offset(bc[0], bc[1], bc[2]);
                level.setBlock(bp, boxState, 3);
                BlockEntity be = level.getBlockEntity(bp);
                if (be instanceof BreedingBoxBlockEntity breedingBox) {
                    // تجهيز الخانات الثمانية تلقائياً بالفخار والمعلف وعلف الدخن!
                    breedingBox.handleRightClick(ctx.getPlayer(), new ItemStack(ArgonLoftPigeonsMod.COPPER_NEST_BOWL_ITEM.get()));
                    breedingBox.handleRightClick(ctx.getPlayer(), new ItemStack(ArgonLoftPigeonsMod.PIGEON_FEEDER_ITEM.get()));
                    breedingBox.handleRightClick(ctx.getPlayer(), new ItemStack(ArgonLoftPigeonsMod.M7_GRAIN_HANDFUL.get()));
                }
            }

            // 4. الحاجز الأيسر (X = 5) مع باب في المنتصف (Z = 4) ينفتح وينغلق + الركزات (السبعات) في الغرفة اليسرى!
            for (int z = 1; z < depth - 1; z++) {
                for (int y = 1; y < height; y++) {
                    if (z == 4 && (y == 1 || y == 2)) {
                        continue; // فتحة الباب الأيسر لتمشي الطيور بين اليسار والوسط
                    }
                    BlockState wallMat = (y >= 2 && z != 4) ? bars : planks;
                    level.setBlock(origin.offset(5, y, z), wallMat, 3);
                }
            }
            placeDoor(level, origin.offset(5, 1, 4), Direction.WEST);

            // تركيب الركزات / السبعات (V-Perches) على الجدار الخلفي للغرفة اليسرى (X = 1..4, Z = 7, Y = 2..3)
            BlockState perchStair = Blocks.OAK_STAIRS.defaultBlockState()
                    .setValue(StairBlock.FACING, Direction.NORTH)
                    .setValue(StairBlock.HALF, Half.TOP);
            for (int px = 1; px <= 4; px++) {
                level.setBlock(origin.offset(px, 2, 7), perchStair, 3);
                level.setBlock(origin.offset(px, 3, 7), perchStair, 3);
            }

            // 5. تجهيز البهو الأوسط (X = 6..13): المعالف الطويلة، جزيئات الدخن 3D، المشارب، وسلّم الصعود للسطح!
            for (int z = 3; z <= 6; z++) {
                level.setBlock(origin.offset(8, 1, z), ArgonLoftPigeonsMod.PIGEON_FEEDER.get().defaultBlockState(), 3);
                level.setBlock(origin.offset(11, 1, z), ArgonLoftPigeonsMod.PIGEON_FEEDER.get().defaultBlockState(), 3);
            }
            // نثر جزيئات الدخن 3D في البهو الأوسط وفي الغرفة اليسرى
            level.setBlock(origin.offset(9, 1, 4), ArgonLoftPigeonsMod.DUKHN_PILE.get().defaultBlockState(), 3);
            level.setBlock(origin.offset(10, 1, 5), ArgonLoftPigeonsMod.DUKHN_PILE.get().defaultBlockState(), 3);
            level.setBlock(origin.offset(2, 1, 4), ArgonLoftPigeonsMod.DUKHN_PILE.get().defaultBlockState(), 3);

            // مشارب الماء الأمامية وصناديق الخزين الخلفية
            level.setBlock(origin.offset(7, 1, 2), Blocks.WATER_CAULDRON.defaultBlockState(), 3);
            level.setBlock(origin.offset(12, 1, 2), Blocks.WATER_CAULDRON.defaultBlockState(), 3);
            level.setBlock(origin.offset(12, 1, 8), Blocks.BARREL.defaultBlockState(), 3);
            level.setBlock(origin.offset(13, 1, 8), Blocks.HAY_BLOCK.defaultBlockState(), 3);

            // سلّم الصعود للسطح على الجدار الخلفي الأوسط (X = 10, Z = 8, Y = 1..4) مع باب السطح
            BlockState ladder = Blocks.LADDER.defaultBlockState().setValue(LadderBlock.FACING, Direction.NORTH);
            for (int ly = 1; ly < height; ly++) {
                level.setBlock(origin.offset(10, ly, 8), ladder, 3);
            }
            level.setBlock(origin.offset(10, height, 8), Blocks.OAK_TRAPDOOR.defaultBlockState().setValue(TrapDoorBlock.OPEN, true), 3);

            if (ctx.getPlayer() != null) {
                if (!ctx.getPlayer().getAbilities().instabuild) ctx.getItemInHand().shrink(1);
                ctx.getPlayer().displayClientMessage(Component.literal(
                        "§a[برج الحمام النموذجي 20×10×5] §fتم بناء البرج الكامل: البهو الأوسط + يمين التزاوج (8 خانات جاهزة) + يسار الطيور والركزات!"), true);
            }
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }

    private void placeDoor(Level level, BlockPos bottomPos, Direction facing) {
        BlockState lower = Blocks.OAK_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, facing)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.LOWER)
                .setValue(DoorBlock.OPEN, true); // مفتوح افتراضياً لتمشي الطيور بحرية وتستطيع إغلاقه متى شئت
        BlockState upper = Blocks.OAK_DOOR.defaultBlockState()
                .setValue(DoorBlock.FACING, facing)
                .setValue(DoorBlock.HALF, DoubleBlockHalf.UPPER)
                .setValue(DoorBlock.OPEN, true);
        level.setBlock(bottomPos, lower, 3);
        level.setBlock(bottomPos.above(), upper, 3);
    }
}
