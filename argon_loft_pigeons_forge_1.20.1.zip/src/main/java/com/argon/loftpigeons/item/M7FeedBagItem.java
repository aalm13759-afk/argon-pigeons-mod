package com.argon.loftpigeons.item;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * كيس أكل الحمام (m7): عند الضغط عليه كلك يمين تأخذ كمية قليلة (حفنة m7) في الإنفنتوري لإطعام الطيور.
 */
public class M7FeedBagItem extends Item {
    public M7FeedBagItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            player.getInventory().placeItemBackInInventory(new ItemStack(ArgonLoftPigeonsMod.M7_GRAIN_HANDFUL.get(), 4));
            if (!player.getAbilities().instabuild) {
                stack.shrink(1);
            }
            player.displayClientMessage(Component.literal("§a[علف m7] §fأخذت 4 حفنات من خلطة علف m7 في الإنفنتوري."), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§7يُشترى من القروي مقابل الأيرون. اضغط كلك يمين لأخذ حفنة علف m7."));
    }
}
