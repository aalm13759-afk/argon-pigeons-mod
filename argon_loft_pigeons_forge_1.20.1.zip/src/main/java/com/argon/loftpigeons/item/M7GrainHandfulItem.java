package com.argon.loftpigeons.item;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Blocks;

/**
 * طعام الطيور "الدخن" (Dukhn 3D Grain Particles):
 * - ليس مربعاً، بل جزيئات صغيرة ثلاثية الأبعاد توضع على الأرض مع أنميشن رمي خاص من اللاعب، ويأتي الطير ليأكلها!
 */
public class M7GrainHandfulItem extends Item {
    public M7GrainHandfulItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        player.swing(hand, true);
        if (target instanceof ArgonPigeonEntity pigeon && !player.level().isClientSide) {
            pigeon.feedM7();
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.displayClientMessage(Component.literal("§a[إطعام الدخن] §fأكل " + pigeon.getBreed().arabicName + " حبيبات الدخن وشبع!"), true);
            return InteractionResult.SUCCESS;
        }
        return super.interactLivingEntity(stack, player, target, hand);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        Player player = ctx.getPlayer();
        if (player != null) {
            // أنميشن رمي ونثر الدخن بيد اللاعب
            player.swing(ctx.getHand(), true);
        }
        BlockPos placePos = ctx.getClickedPos().relative(ctx.getClickedFace());
        if (!level.isClientSide && level.getBlockState(placePos).isAir()) {
            level.setBlock(placePos, ArgonLoftPigeonsMod.DUKHN_PILE.get().defaultBlockState(), 3);
            level.playSound(null, placePos, SoundEvents.SAND_PLACE, SoundSource.BLOCKS, 0.8F, 1.4F);
            if (level instanceof ServerLevel serverLevel) {
                serverLevel.sendParticles(
                        new BlockParticleOption(ParticleTypes.BLOCK, Blocks.HAY_BLOCK.defaultBlockState()),
                        placePos.getX() + 0.5D, placePos.getY() + 0.3D, placePos.getZ() + 0.5D,
                        18, 0.25D, 0.15D, 0.25D, 0.05D
                );
            }
            if (player != null && !player.getAbilities().instabuild) {
                ctx.getItemInHand().shrink(1);
            }
            if (player != null) {
                player.displayClientMessage(Component.literal("§e[نثر الدخن 3D] §fنثرت حبيبات الدخن على الأرض؛ ستأتي الطيور القريبة لتأكلها!"), true);
            }
            return InteractionResult.SUCCESS;
        }
        return InteractionResult.sidedSuccess(level.isClientSide);
    }
}
