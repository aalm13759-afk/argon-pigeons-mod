package com.argon.loftpigeons.item;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.item.ItemEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;

/**
 * حفنة علف m7: تطعم الطير مباشرة أو تُرمى على أرضية البرج/السطح ليأكلها الحمام.
 */
public class M7GrainHandfulItem extends Item {
    public M7GrainHandfulItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (target instanceof ArgonPigeonEntity pigeon && !player.level().isClientSide) {
            pigeon.feedM7();
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.displayClientMessage(Component.literal("§a[إطعام m7] §fأكل " + pigeon.getBreed().arabicName + " وشبع لمدة 3 أيام قادمة!"), true);
            return InteractionResult.SUCCESS;
        }
        return super.interactLivingEntity(stack, player, target, hand);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            ItemStack single = stack.copyWithCount(1);
            ItemEntity drop = new ItemEntity(level, player.getX(), player.getY() + 0.5D, player.getZ(), single);
            drop.setPickUpDelay(40);
            level.addFreshEntity(drop);
            if (!player.getAbilities().instabuild) stack.shrink(1);
            player.displayClientMessage(Component.literal("§e[نثر علف m7] §fرميت حب m7 على الأرض للحمام."), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }
}
