package com.argon.loftpigeons.item;

import com.argon.loftpigeons.ArgonLoftPigeonsMod;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.fml.DistExecutor;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * كتاب "تعليمات مروان للطيور" باللون الأزرق الترقوازي:
 * يفتح واجهة كتاب متعددة الصفحات تشرح كل كبيرة وصغيرة في المود بالتفصيل.
 */
public class MarwanGuideBookItem extends Item {
    public MarwanGuideBookItem(Properties props) {
        super(props);
    }

    @Override
    public Component getName(ItemStack stack) {
        return Component.literal("§bتعليمات مروان للطيور");
    }

    public static void populatePagesIfNeeded(ItemStack stack) {
        CompoundTag tag = stack.getOrCreateTag();
        if (tag.contains("pages")) return;

        tag.putString("title", "تعليمات مروان للطيور");
        tag.putString("author", "مروان");
        tag.putBoolean("resolved", true);

        String[] rawPages = new String[]{
            "§3§lتعليمات مروان للطيور§r

" +
            "§0أهلاً بك في الدليل الشامل لمود حمام اللوفت الواقعي (إصدار 1.20.1).

" +
            "يحتوي هذا الكتاب على شرح كامل للسلالات الـ 5، الهجائن الـ 3، نظام حفظ السطح، الذكاء والحدة، التزاوج والفراخ، وجميع الأدوات.

" +
            "§8(اقلب الصفحة للمتابعة ⬅)",

            "§3§l1. الزاجل والأحمر§r

" +
            "§1• الزاجل:§0 ذكاء عالٍ (75% فوق 85%). يحتاج §415 يوماً§0 لحفظ السطح. يطير 0.5-3 ساعات بخط مستقيم سريع مع قلب الجناح يميناً ويساراً، ولا يضيع أبداً حتى من مناطق بعيدة.

" +
            "§4• الأحمر:§0 يحتاج §48 أيام§0 لحفظ السطح. يحوم 5-7 دوائر ثم يقلب جناحه لمنطقة قريبة ويعود. يعود بنسبة 80% إذا زار المنطقة مرتين.",

            "§3§l2. التيدي الباكستاني§r

" +
            "§0• الذكاء: §290%+ دائماً§0.
" +
            "• الحدة (The Limit): بين 60 و100.
" +
            "• حفظ السطح: §415 يوماً§0 للحاد (85+) و§419-20 يوماً§0 لأقل من 84.
" +
            "• الطيران: 4-14 ساعة (غالباً 7-12)، يصعد فوق الغيم لمرحلة §lالبند§r.
" +
            "• الحدة 85+ يطير 13+ ساعة ويضيع؛ وتحت 84 احتمال 45% طفرة حادة تختفي عند §2الريشة 10§0.",

            "§3§l3. الكظماوي والكولدن§r

" +
            "§1• الأبيض الكظماوي:§0 ذكي وبارد الدم، حفظ السطح §410 أيام§0، يطير 4-9 ساعات فوق الغيم (دون البند) أو بمستوى النظر، ويعود بنسبة 80% بعد زيارتين.

" +
            "§6• الكولدن:§0 حفظ السطح §420 يوماً§0، يطير 10-13 ساعة ويصعد للبند بحركات متغيرة. طفرة الحدة (70%) تختفي تماماً عند §2الريشة 10§0.",

            "§3§l4. الهجائن الثلاثة§r

" +
            "§2• تيدي × كظماوي:§0 ذكاء خارق ودم بارد يكسر حدة التيدي، حفظ §412 يوماً§0، أقصى طيران 8 ساعات وألوان متنوعة.

" +
            "§6• كظماوي × كولدن:§0 حفظ §415 يوماً§0، يطير ~12 ساعة للبند.

" +
            "§5• تيدي × كولدن:§0 يرث الذكاء والحدة، حفظ §425 يوماً§0، يطير 15 ساعة بأشكال مطعمة.",

            "§3§l5. شروط حفظ السطح§r

" +
            "§4• تنبيه مهم:§0 حبس الطير داخل البرج لا يُحسب من أيام الحفظ!

" +
            "• يجب إخراجه للسطح تحت السماء ليتجول (ضمن 10 بلوكات) ويصعد تلقائياً على أعلى بلوكة مبنية ويلتفت لحفظ المعالم.

" +
            "• إذا طار الطير قبل إتمام أيام حفظه يضيع فوراً.",

            "§3§l6. الخام والقروي وعلف m7§r

" +
            "§3• خام الحمام:§0 يتواجد في الكهوف بنفس ندرة الدايموند، وتشتري به بيض السلالات الـ 5 من القروي.

" +
            "§6• أكل الحمام (m7):§0 تشتريه من القروي مقابل الأيرون، وبكلك يمين تأخذ حفنات لإطعام الطيور.

" +
            "§4• نظام الجوع:§0 يموت الطير إذا بقي §43 أيام§0 بدون أكل m7!",

            "§3§l7. البطاقة والمقص§r

" +
            "§6• بطاقة المعلومات:§0 (2 أيرون + 1 خشب) كلك يمين على الطير لحفظ بطاقة دائمة تعرض: الجنس، العمر، الريشة (1-10)، الذكاء Mentally، والحدة The Limit.

" +
            "§8• المقص:§0 (3 أيرون) كلك يمين بالهواء لاختيار عدد الريش (1-10) وكلك يمين على الطير لقص جناحه وإخفاء الريش.",

            "§3§l8. الشبكة والقماشة والحلقات§r

" +
            "§2• الشبكة:§0 (خشب + خيوط) لمسك الطير كلك يمين ووضعه في الإنفنتوري.

" +
            "§0• القماشة السوداء:§0 (2 صوف أسود) كلك يمين للتلويح بها وتطيير كل طيور السطح دفعة واحدة.

" +
            "§d• حلقات الأرجل:§0 (صبغة + خشب) 20 لوناً، تُلبس للطير لتمييزه (لا يولد طير بحلقة تلقائية).",

            "§3§l9. خانة التزاوج والفقس§r

" +
            "§0• الخانة (3 خشب + 3 أيرون) تتسع لفحل وأنثى.
" +
            "• ضع داخلها §6الفخار النحاسي§0 (3 كوبر - لا تبيض الأنثى بدونه) و§6المعلف§0 (3 خشب + 1 أيرون) وعبئه بـ m7.
" +
            "• تبيض الأولى باليوم 1 والثانية باليوم 3، وترقد 5 أيام، ويزق الأبوان الفرخين 5 أيام حتى الريشة 1 باليوم 6.",

            "§3§l10. التحكم بالخانة والبرج§r

" +
            "§0• كلك يسار (ضربة واحدة) على خانة التزاوج يسحب الأبوين أو الفراخ أو المعلف للإنفنتوري.

" +
            "§8• برج الحمام (20×10):§0 يُصنع من (3 حبات أيرون + 3 بلوكات أيرون)، يبني البرج الكامل مع باب متحرك للدخول ومسك الطيور بالشبكة وإطعامها."
        };

        ListTag pagesList = new ListTag();
        for (String pageText : rawPages) {
            String jsonPage = Component.Serializer.toJson(Component.literal(pageText));
            pagesList.add(StringTag.valueOf(jsonPage));
        }
        tag.put("pages", pagesList);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        populatePagesIfNeeded(stack);
        if (level.isClientSide) {
            DistExecutor.unsafeRunWhenOn(Dist.CLIENT, () -> () -> ArgonLoftPigeonsMod.ClientModEvents.openMarwanGuideBook(stack));
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("§3كتاب تعليمات مروان الشامل لكل أسرار وطرق تربية حمام اللوفت."));
        tooltip.add(Component.literal("§bاضغط كلك يمين لفتح الكتاب وقراءة الصفحات."));
    }
}
