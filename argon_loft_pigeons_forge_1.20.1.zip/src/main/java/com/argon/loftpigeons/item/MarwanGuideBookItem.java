package com.argon.loftpigeons.item;

import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.ListTag;
import net.minecraft.nbt.StringTag;
import net.minecraft.network.chat.Component;
import net.minecraft.stats.Stats;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.WrittenBookItem;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

public class MarwanGuideBookItem extends WrittenBookItem {
    public MarwanGuideBookItem(Properties properties) {
        super(properties);
    }

    public static void ensureBookPages(ItemStack stack) {
        CompoundTag tag = stack.getOrCreateTag();
        if (tag.contains("pages")) return;

        tag.putString("title", "تعليمات مروان للطيور");
        tag.putString("author", "مروان (Argon Loft V4)");
        tag.putBoolean("resolved", true);

        ListTag pages = new ListTag();

        String[] rawPages = new String[]{
            "§3§lتعليمات مروان للطيور\n§0§lالإصدار الرابع (V4)\n==================\n\nمرحباً بك في الدليل الشامل لنظام اللوفت العراقي والباكستاني.\n\nيشرح هذا الكتاب:\n1. السلالات الـ5 والهجائن الـ3\n2. حفظ السطح والذكاء والحدة\n3. الدينمي وقروي الطيور والدخن\n4. برج الحمام (20×10×5) والذكاء الداخلي",
            "§1§l1. الزاجل والأحمر\n==================\n\n§0• §lالزاجل (Zajil):\n§0الذكاء 75% عالٍ (85+). يحفظ السطح بـ15 يوماً. يطير 0.5-3 ساعات بخط مستقيم وقلب جناح، ولا يضيع أبداً حتى من المناطق البعيدة.\n\n• §lالأحمر (Red Aghar):\n§0يحفظ السطح بـ8 أيام. يحوم 5-7 دوائر ثم يقلب جناحه لمنطقة قريبة ويعود بنسبة 80%.",
            "§2§l2. التيدي الباكستاني\n==================\n\n§0• §lالذكاء: §090+ دائماً.\n• §lالحدة (The Limit): §060-100 (90% بين 85-100).\n• §lحفظ السطح: §015 يوماً للحاد (85+) و19-20 يوماً لأقل من 84.\n• §lالطيران: §04-14 ساعة (غالباً 7-12 ساعة) ويصعد فوق الغيم لمرحلة (البند). حدة 85+ قد تطير 13+ ساعة وتضيع!",
            "§3§l3. الكظماوي والكولدن\n==================\n\n§0• §lالأبيض الكظماوي:\n§0ذكي وبارد الدم. يحفظ السطح بـ10 أيام ويطير 4-9 ساعات بتباين 45% دون بند.\n\n• §lالكولدن (Golden):\n§0يحفظ السطح بـ20 يوماً ويطير 10-13 ساعة في البند. احتمال 70% لطفرة الحدة قبل الريشة 10 (تختفي عند الريشة 10).",
            "§5§l4. الهجائن الثلاثة\n==================\n\n§0• §lتيدي × كظماوي:\n§0ذكاء خارق ودم بارد يكسر حدة التيدي. يحفظ بـ12 يوماً ويطير حتى 8 ساعات.\n• §lكظماوي × كولدن:\n§0يحفظ بـ15 يوماً ويطير ~12 ساعة بالبند.\n• §lتيدي × كولدن:\n§0يرث Mentally و The Limit، يحفظ بـ25 يوماً ويطير 15 ساعة!",
            "§6§l5. الدينمي وقروي الطيور\n==================\n\n§0• §lأور الدينمي (Dynami):\n§0يتواجد في الكهوف بندرة الألماس. كل 9 حبات دينمي تصنع بلوكة دينمي زرقاء بشخطات سماوية.\n\n• §lقروي الطيور الخاص:\n§0يتواجد في القرى ويبيع الدخن بـ1 دينمي، وبيض الطيور حسب قوة الطير، وجميع مستلزمات اللوفت.",
            "§4§l6. الدخن وحلقات الأرجل\n==================\n\n§0• §lالدخن 3D (طعام الطيور):\n§0كلك يمين على الأرض لنثر حبيبات الدخن ثلاثية الأبعاد، فيركض الحمام ليأكلها بنقرات واقعية.\n\n• §lحلقات الأرجل (20 لوناً):\n§0تفقس الطيور بدون حلقة في رجلها، ويمكنك تلبيس أي طير حلقة من 20 لوناً بضغطة كلك يمين.",
            "§2§l7. التزاوج ونمو الفرخ\n==================\n\n§0• §lالعش وخانة التزاوج:\n§0ضع فحلاً وأنثى مع العش ثلاثي الأبعاد والدخن والماء. بعد التزاوج تضع الأنثى بيضتين تفقسان بعد 5 أيام.\n• §lنمو الفرخ التدريجي:\n§0يخرج الفرخ بحجم صغير جداً (حديث الولادة) ويكبر تدريجياً كل يوم حتى الريشة 1 (اليوم 6) ثم يبدل ريشه حتى الريشة 10.",
            "§1§l8. برج الحمام (20×10×5)\n==================\n\n§0• §lالتصميم الهندسي:\n§0بضغطة كلك يمين بأداة بناء البرج تحصل على بناية 20×10 بارتفاع 5 بلوكات:\n- §lالوسط: §0مدخل رئيسي، معالف، دخن، ومشارب.\n- §lاليمين: §0حاجز وباب بالوسط وبداخله 8 خانات تزاوج جاهزة.\n- §lاليسار: §0حاجز وباب ينفتح وينغلق وركزات للطيور المطيرة والمقصوصة مع ذكاء اصطناعي مستقل لكل طير!"
        };

        for (String pageText : rawPages) {
            String jsonPage = Component.Serializer.toJson(Component.literal(pageText));
            pages.add(StringTag.valueOf(jsonPage));
        }

        tag.put("pages", pages);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack itemstack = player.getItemInHand(hand);
        ensureBookPages(itemstack);
        player.openItemGui(itemstack, hand);
        player.awardStat(Stats.ITEM_USED.get(this));
        return InteractionResultHolder.sidedSuccess(itemstack, level.isClientSide());
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.literal("الدليل الشامل للمود والسلالات والبرج (الإصدار الرابع V4)").withStyle(ChatFormatting.AQUA));
        tooltip.add(Component.literal("اضغط كلك يمين لقراءة تعليمات مروان بالتفصيل").withStyle(ChatFormatting.GRAY));
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }
}
