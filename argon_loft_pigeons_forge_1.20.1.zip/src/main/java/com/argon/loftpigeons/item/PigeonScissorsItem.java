package com.argon.loftpigeons.item;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.network.chat.Component;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * المقص (Scissors): يُصنع من 3 أيرون.
 * يختار اللاعب رقم الريشات المراد قصها (1 إلى 10) وعند الضغط كلك يمين على الطير يقص ذلك العدد من ريش الجناح ويخفيها من المجسم 3D!
 */
public class PigeonScissorsItem extends Item {
    public PigeonScissorsItem(Properties props) {
        super(props);
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        if (!level.isClientSide) {
            int current = stack.getOrCreateTag().getInt("ClipCount");
            int next = (current % 10) + 1; // يتنقل في قائمة الأرقام (1 إلى 10)
            if (player.isShiftKeyDown()) next = 0; // تسلل = إرجاع الريش كاملاً
            stack.getOrCreateTag().putInt("ClipCount", next);
            player.displayClientMessage(Component.literal("§e[قائمة المقص 1-10] §fعدد ريش الجناح المحدد للقص: §b" + next + " ريشات §7(اضغط على الطير للتطبيق)"), true);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide);
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (target instanceof ArgonPigeonEntity pigeon && !player.level().isClientSide) {
            int count = stack.getOrCreateTag().contains("ClipCount") ? stack.getOrCreateTag().getInt("ClipCount") : 5;
            pigeon.setClippedFeathers(count);
            player.displayClientMessage(Component.literal("§a[قص الجناح] §fتم قص §e" + count + " ريشات §fمن جناح " + pigeon.getBreed().arabicName + " وإخفاؤها من المجسم!"), true);
            return InteractionResult.SUCCESS;
        }
        return super.interactLivingEntity(stack, player, target, hand);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        int count = stack.hasTag() && stack.getTag().contains("ClipCount") ? stack.getTag().getInt("ClipCount") : 5;
        tooltip.add(Component.literal("§eالعدد المحدد حالياً: §b" + count + " ريشات (من 1 إلى 10)"));
        tooltip.add(Component.literal("§7كلك يمين في الهواء لاختيار الرقم (1-10)، وكلك يمين على الطير لقص جناحه."));
    }
}
