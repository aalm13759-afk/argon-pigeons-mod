package com.argon.loftpigeons.item;

import com.argon.loftpigeons.entity.ArgonPigeonEntity;
import net.minecraft.ChatFormatting;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;
import org.jetbrains.annotations.Nullable;

import java.util.List;

/**
 * البطاقة الحمراء (Red Diagnostic Card):
 * يوجهها اللاعب للطير (كلك يمين) لأخذ كافة معلوماته الحيوية والنفسية والجسدية ورغباته وهل يريد الطيران أم لا،
 * ثم يضعها في "بلوكة مجسم الطير (Pigeon Analyzer)" لتظهر البلوكة كل شيء بالتفصيل!
 */
public class RedDiagnosticCardItem extends Item {
    public RedDiagnosticCardItem(Properties props) {
        super(props);
    }

    public static boolean hasScannedPigeon(ItemStack stack) {
        return stack.hasTag() && stack.getTag().contains("BioScanData");
    }

    public static InteractionResult scanPigeonIntoRedCard(ItemStack stack, Player player, ArgonPigeonEntity pigeon, InteractionHand hand) {
        if (!player.level().isClientSide) {
            CompoundTag scan = buildCompleteBioPsychProfile(pigeon);
            stack.getOrCreateTag().put("BioScanData", scan);

            // تثبيت البيانات على البطاقة الحمراء في يد اللاعب (حتى في طور الإبداعي Creative Mode)
            player.setItemInHand(hand, stack);
            player.inventoryMenu.broadcastChanges();

            player.level().playSound(null, pigeon.blockPosition(), SoundEvents.EXPERIENCE_ORB_PICKUP, SoundSource.PLAYERS, 1.0F, 1.35F);
            player.sendSystemMessage(Component.literal("§c§l[البطاقة الحمراء 3D] §fتم أخذ البصمة النفسية والجسدية ورغبات الطير (§e" + pigeon.getBreed().arabicName + "§f)!"));
            player.sendSystemMessage(Component.literal("§7• توجه الآن إلى §b«بلوكة مجسم الطير للفحص» §7واضغط عليها بالبطاقة الحمراء لعرض الدراسة الكاملة!"));
        }
        return InteractionResult.sidedSuccess(player.level().isClientSide);
    }

    public static CompoundTag buildCompleteBioPsychProfile(ArgonPigeonEntity pigeon) {
        CompoundTag tag = new CompoundTag();
        pigeon.addAdditionalSaveData(tag);

        String breedName = pigeon.getBreed().arabicName;
        String genderStr = pigeon.isMale() ? "فحل (ذكر ♂)" : "طيرة (أنثى ♀)";
        int healthPct = Math.min(100, Math.round((pigeon.getHealth() / pigeon.getMaxHealth()) * 100.0F));
        int hungerTicks = pigeon.getTicksWithoutFood();
        int satietyPct = Math.max(0, Math.min(100, 100 - (hungerTicks * 100 / 72000)));
        int clipped = pigeon.getClippedFeathers();
        int roofDays = pigeon.getMemorizedRoofDays();
        int reqRoofDays = pigeon.getRequiredRoofDays();
        boolean roofDone = pigeon.hasCompletedRoofMemory();

        // 1. دراسة الحالة الجسدية (Physical Condition)
        String physicalStatus;
        if (healthPct >= 85 && satietyPct >= 65 && clipped == 0) {
            physicalStatus = "§aممتازة (عضلات صدر قوية " + healthPct + "% | شبع الحوصلة " + satietyPct + "% | الريش 10/10 مكتمل)";
        } else if (clipped >= 3) {
            physicalStatus = "§eسليمة بدنياً (" + healthPct + "%) لكن الجناح مقصوص (" + clipped + " ريشات مقصوصة)";
        } else if (satietyPct < 40) {
            physicalStatus = "§cضعيفة بسبب الجوع (شبع الحوصلة " + satietyPct + "% فقط - يحتاج للدخن فوراً!)";
        } else {
            physicalStatus = "§eجيدة (" + healthPct + "% صحة | " + satietyPct + "% شبع الحوصلة)";
        }

        // 2. دراسة الحالة النفسية والمزاجية (Psychological State)
        String psychStatus;
        if (satietyPct < 35) {
            psychStatus = "§cقلق ومتوتر بسبب الجوع ونقص الدخن";
        } else if (roofDone && satietyPct >= 70) {
            psychStatus = "§aمطمئن جداً، واثق، ومرتبط باللوفت (حفظ السطح مكتمل " + roofDays + "/" + reqRoofDays + " يوم)";
        } else if (!roofDone) {
            psychStatus = "§eحذر ويدرس معالم المنطقة (حفظ السطح: " + roofDays + " من " + reqRoofDays + " يوم)";
        } else {
            psychStatus = "§bهادئ ومستقر نفسياً داخل البرج";
        }

        // 3. دراسة رغبات الطير الحالية (Current Desires)
        String desireStatus;
        if (satietyPct < 60) {
            desireStatus = "§eيرغب بنقر وأكل حبيبات الدخن 3D وشرب الماء";
        } else if (!roofDone && clipped < 3) {
            desireStatus = "§bيرغب بالتمشي على السطح تحت الشمس لإتمام حفظ معالم البرج";
        } else if (pigeon.getSquabDay() == 0 && satietyPct >= 75 && (pigeon.tickCount % 2 == 0)) {
            desireStatus = "§dيرغب بدخول العش الكبير (في خانة الكوارتز) للتزاوج وتكوين زوج";
        } else {
            desireStatus = "§aيرغب بالتحليق في السماء ثم الاستراحة وتفلي ريشه على ركزات البرج";
        }

        // 4. هل يريد الطيران أم لا؟ (Flight Desire & Readiness Decision)
        String wantsToFly;
        boolean canAndWantsFly = false;
        if (pigeon.getSquabDay() > 0) {
            wantsToFly = "§c[لا يريد الطيران] §fلأنه فرخ صغير في مرحلة النمو (اليوم " + pigeon.getSquabDay() + " من 5)";
        } else if (clipped >= 3) {
            wantsToFly = "§c[لا يستطيع الطيران] §fيريد الطيران نفسياً لكن جناحه مقصوص بـ " + clipped + " ريشات بالمقص!";
        } else if (satietyPct < 30 || healthPct < 40) {
            wantsToFly = "§c[لا يريد الطيران حالياً] §fمرهق وجائع؛ أطعمه الدخن أولاً ليستعيد طاقته";
        } else if (!roofDone && pigeon.getBreed() != ArgonPigeonEntity.Breed.ZAJIL) {
            canAndWantsFly = true;
            wantsToFly = "§e[نعم يريد الطيران - مع تحذير!] §fمتحمس للطيران، لكنه لم يتم حفظ السطح (" + roofDays + "/" + reqRoofDays + " يوم) وقد يضيع!";
        } else {
            canAndWantsFly = true;
            wantsToFly = "§a§l[نعم! متشوق جداً للطيران] §fجاهز بدنياً ونفسياً 100% للتحليق والعودة للبرج!";
        }

        tag.putString("SummaryTitle", breedName + " - " + genderStr);
        tag.putString("StatsLine", "الذكاء (Mentally): " + pigeon.getMentally() + "% | الحدة (The Limit): " + pigeon.getTheLimit() + "% | الريشة: " + pigeon.getFeatherStage());
        tag.putString("PhysicalStatus", physicalStatus);
        tag.putString("PsychStatus", psychStatus);
        tag.putString("DesireStatus", desireStatus);
        tag.putString("WantsToFlyStatus", wantsToFly);
        tag.putBoolean("CanAndWantsFly", canAndWantsFly);
        return tag;
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack stack, Player player, LivingEntity target, InteractionHand hand) {
        if (target instanceof ArgonPigeonEntity pigeon) {
            return scanPigeonIntoRedCard(stack, player, pigeon, hand);
        }
        return super.interactLivingEntity(stack, player, target, hand);
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return hasScannedPigeon(stack);
    }

    @Override
    public void appendHoverText(ItemStack stack, @Nullable Level level, List<Component> tooltip, TooltipFlag flag) {
        if (hasScannedPigeon(stack)) {
            CompoundTag scan = stack.getTag().getCompound("BioScanData");
            tooltip.add(Component.literal("§c§lبيانات الطير المسجلة بالبطاقة الحمراء:"));
            tooltip.add(Component.literal("§f• الطير: §e" + scan.getString("SummaryTitle")));
            tooltip.add(Component.literal("§f• رغبة الطيران: " + scan.getString("WantsToFlyStatus")));
            tooltip.add(Component.literal("§bاضغط كلك يمين على «بلوكة مجسم الطير» لعرض الدراسة النفسية والجسدية الكاملة!"));
        } else {
            tooltip.add(Component.literal("§7اضغط كلك يمين على أي طير لأخذ معلوماته وحالته النفسية والجسدية.").withStyle(ChatFormatting.RED));
            tooltip.add(Component.literal("§7ثم ضعها في «بلوكة مجسم الطير» لإظهار التقرير الشامل.").withStyle(ChatFormatting.GRAY));
        }
    }
}
